"""EXODIA 엔진 압축 파일 생성 — 다운로드 폴더에 exodia-engine.zip 생성"""
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = Path.home() / "Downloads" / "exodia-engine.zip"

EXCLUDE_DIRS = {"__pycache__", ".pytest_cache", ".git", ".venv", "venv", ".mypy_cache", "node_modules"}
EXCLUDE_EXT = {".pyc", ".pyo"}


def main():
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(ROOT.rglob("*")):
            if not f.is_file():
                continue
            rel = f.relative_to(ROOT)
            if any(p in EXCLUDE_DIRS for p in rel.parts):
                continue
            if f.suffix.lower() in EXCLUDE_EXT:
                continue
            zf.write(f, rel)

    print(f"Created: {OUT}")
    print(f"Size: {OUT.stat().st_size / 1024:.1f} KB")


if __name__ == "__main__":
    main()
