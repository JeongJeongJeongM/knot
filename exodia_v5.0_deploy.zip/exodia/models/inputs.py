"""EXODIA v3.0 Input Schemas — Pydantic v2 models for pipeline inputs."""

from __future__ import annotations

from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel, Field


class TurnMetadata(BaseModel):
    language: str = "ko"
    timestamp: Optional[datetime] = None
    speaker: Literal["user", "partner", "system", "metadata"] = "user"
    reply_latency_ms: Optional[int] = None
    platform_flags: Optional[dict] = None


class RawTurn(BaseModel):
    turn_id: str
    raw_text: str
    metadata: TurnMetadata = Field(default_factory=TurnMetadata)


class ClientMessageSignals(BaseModel):
    message_id: str
    chars_per_second: Optional[float] = None
    paste_event: Optional[bool] = None
    backspace_ratio: Optional[float] = None
    paragraph_structure: Optional[float] = None
    edit_count: Optional[int] = None
    input_rhythm_variance: Optional[float] = None


class ClientSignals(BaseModel):
    messages: list[ClientMessageSignals] = Field(default_factory=list, alias="per_message")

    model_config = {"populate_by_name": True}

    @property
    def per_message(self) -> list[ClientMessageSignals]:
        """Legacy alias for messages (layers/integrity, tests)."""
        return self.messages


class ConversationSession(BaseModel):
    session_id: str
    user_id: str
    turns: list[RawTurn]
    client_signals: Optional[ClientSignals] = None
