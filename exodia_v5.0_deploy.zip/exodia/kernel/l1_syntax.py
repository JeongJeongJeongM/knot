"""EXODIA v3.0 — L1 Syntactic Analysis (Stanza + regex fallback).

100 % deterministic (torch.manual_seed(42), np.random.seed(42)).
Never raises; returns default SyntaxOutput on failure.
"""

from __future__ import annotations

import os
import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import stanza

from exodia.models.outputs import SyntaxOutput

# ═══════════ Deterministic seeds ═══════════

_SEED = 42

# ═══════════ Stanza lazy singleton ═══════════

_stanza_pipeline: "stanza.Pipeline | None" = None
_stanza_checked: bool = False


def _get_stanza() -> "stanza.Pipeline | None":
    """Lazy-load Korean Stanza pipeline.  Returns *None* on any failure.

    Stanza 모델은 Docker 빌드 시 pre-download 필수.
    런타임 download() 호출 금지 (E-08 결정론).
    """
    global _stanza_pipeline, _stanza_checked
    if _stanza_checked:
        return _stanza_pipeline
    _stanza_checked = True
    try:
        import numpy as np
        import torch
        torch.manual_seed(_SEED)
        np.random.seed(_SEED)

        import stanza as _stanza

        model_dir = os.environ.get("STANZA_MODEL_DIR", None)
        kwargs = {
            "lang": "ko",
            "processors": "tokenize,pos,lemma,depparse",
            "verbose": False,
            "use_gpu": False,
        }
        if model_dir:
            kwargs["dir"] = model_dir

        _stanza_pipeline = _stanza.Pipeline(**kwargs)
    except Exception:
        _stanza_pipeline = None
    return _stanza_pipeline


# ═══════════ Subordinate-clause deprels ═══════════

_SUBORDINATE_DEPRELS: frozenset[str] = frozenset({
    "advcl", "acl", "csubj", "ccomp", "xcomp",
    "advcl:relcl", "acl:relcl",
})

# ═══════════ Internal helpers ═══════════

def _tree_depth(words: list, id_to_head: dict[int, int]) -> int:
    """Max depth from root in a dependency tree."""
    memo: dict[int, int] = {}

    def _depth(wid: int) -> int:
        if wid in memo:
            return memo[wid]
        head = id_to_head.get(wid, 0)
        if head == 0 or head == wid:
            memo[wid] = 1
            return 1
        d = 1 + _depth(head)
        memo[wid] = d
        return d

    if not id_to_head:
        return 0
    return max((_depth(wid) for wid in id_to_head), default=0)


def _branching_factor(id_to_head: dict[int, int]) -> float:
    """Average children-per-non-leaf-node."""
    children_count: dict[int, int] = {}
    for wid, head in id_to_head.items():
        if head not in children_count:
            children_count[head] = 0
        children_count[head] += 1

    non_leaf = {h: c for h, c in children_count.items() if c > 0}
    if not non_leaf:
        return 0.0
    return sum(non_leaf.values()) / len(non_leaf)


# ═══════════ Stanza-based analysis ═══════════

def _analyse_with_stanza(text: str, nlp: "stanza.Pipeline") -> SyntaxOutput:
    try:
        import numpy as np
        import torch
        torch.manual_seed(_SEED)
        np.random.seed(_SEED)

        doc = nlp(text)
    except Exception:
        return _fallback_analysis(text)

    if doc is None or not doc.sentences:
        return _fallback_analysis(text)

    sentence_count = len(doc.sentences)
    total_words = 0
    length_sum = 0
    clause_count = 0
    depth_sum = 0.0
    branching_sum = 0.0
    modifier_count = 0
    dep_distance_sum = 0.0
    cc_count = 0
    subordinate_clause_count = 0

    for sent in doc.sentences:
        words = sent.words
        n = len(words)
        total_words += n
        length_sum += n

        id_to_head: dict[int, int] = {}
        for w in words:
            wid = w.id if isinstance(w.id, int) else int(w.id)
            head = w.head if isinstance(w.head, int) else int(w.head)
            id_to_head[wid] = head

            deprel = (w.deprel or "").lower()

            if deprel in _SUBORDINATE_DEPRELS:
                subordinate_clause_count += 1

            if deprel in ("amod", "advmod"):
                modifier_count += 1

            if deprel == "cc":
                cc_count += 1

            dep_distance_sum += abs(wid - head)

        depth_sum += _tree_depth(words, id_to_head)
        branching_sum += _branching_factor(id_to_head)

    clause_count = sentence_count + subordinate_clause_count

    avg_sentence_length = length_sum / max(1, sentence_count)
    avg_tree_depth = depth_sum / max(1, sentence_count)
    avg_branching = branching_sum / max(1, sentence_count)
    modifier_ratio = modifier_count / max(1, total_words)
    dep_distance = dep_distance_sum / max(1, total_words)
    conj_freq = cc_count / max(1, total_words)
    sub_ratio = (
        subordinate_clause_count / max(1, clause_count) if clause_count > 0 else 0.0
    )

    return SyntaxOutput(
        sentence_count=sentence_count,
        avg_sentence_length=round(avg_sentence_length, 6),
        clause_count=clause_count,
        avg_tree_depth=round(avg_tree_depth, 6),
        avg_branching_factor=round(avg_branching, 6),
        modifier_ratio=round(modifier_ratio, 6),
        dependency_distance=round(dep_distance, 6),
        conjunction_frequency=round(conj_freq, 6),
        subordination_ratio=round(sub_ratio, 6),
        stanza_available=True,
    )


# ═══════════ Fallback (regex) ═══════════

_SENT_SPLIT_RE = re.compile(r"[.?!。！？]+\s*")


def _fallback_analysis(text: str) -> SyntaxOutput:
    sentences = [s.strip() for s in _SENT_SPLIT_RE.split(text) if s.strip()]
    sentence_count = max(1, len(sentences))

    return SyntaxOutput(
        sentence_count=sentence_count,
        avg_sentence_length=0.0,
        clause_count=0,
        avg_tree_depth=0.0,
        avg_branching_factor=0.0,
        modifier_ratio=0.0,
        dependency_distance=0.0,
        conjunction_frequency=0.0,
        subordination_ratio=0.0,
        stanza_available=False,
    )


# ═══════════ Public API ═══════════

def process_syntax(normalized_text: str) -> SyntaxOutput:
    """Deterministic syntactic analysis.

    Returns *SyntaxOutput* — never raises.
    """
    if not normalized_text or not normalized_text.strip():
        return SyntaxOutput()

    text = normalized_text.strip()

    nlp = _get_stanza()
    if nlp is not None:
        return _analyse_with_stanza(text, nlp)

    return _fallback_analysis(text)
