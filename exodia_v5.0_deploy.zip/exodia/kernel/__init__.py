"""EXODIA v3.0 NLP Kernel — deterministic morphology / syntax / pragmatics."""

from exodia.kernel.l0_morphology import process_morphology
from exodia.kernel.l1_syntax import process_syntax
from exodia.kernel.l2_pragmatics import process_pragmatics

__all__ = ["process_morphology", "process_syntax", "process_pragmatics"]
