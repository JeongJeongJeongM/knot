"""EXODIA v3.0 — L2 Pragmatic Analysis (YAML-style regex patterns).

100 % deterministic.  Never raises; returns default PragmaticsOutput on failure.
"""

from __future__ import annotations

import re
from typing import Optional

from exodia.models.outputs import MorphologyOutput, PragmaticsOutput, SyntaxOutput

# ═══════════════════════════════════════════════════════════════
# Ending-pattern definitions — 11 types with formality contribution
# ═══════════════════════════════════════════════════════════════

ENDING_FORMALITY: dict[str, Optional[float]] = {
    "FORMAL_HIGH": 1.0,
    "POLITE": 0.8,
    "SEMI_FORMAL": 0.7,
    "SEMI_CASUAL": 0.5,
    "PLAIN": 0.3,
    "CASUAL": 0.2,
    "NOMINAL": 0.1,
    "JAMO": 0.0,
    "EMOJI": 0.0,
    "MIXED": None,      # weighted average — computed at runtime
    "UNKNOWN": None,
}

# Each pattern list is tried in order; first match wins.
# Patterns operate on the *last sentence* of the input.

_ENDING_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    # FORMAL_HIGH: 합쇼체 / 하십시오체
    ("FORMAL_HIGH", re.compile(
        r"(?:습니다|습니까|하십시오|십시오|옵니다|옵니까|하셨습니다|하셨습니까"
        r"|으십시오|주십시오|이십니다|이십니까|하겠습니다|하겠습니까)\s*[.?!]*\s*$"
    )),
    # POLITE: 해요체
    ("POLITE", re.compile(
        r"(?:[가-힣]+(?:요|세요|셔요|에요|이에요|인가요|나요|던가요|ㄹ까요"
        r"|할게요|줄게요|할래요|하죠|죠|네요|군요|거든요|잖아요|더라고요|래요))\s*[.?!]*\s*$"
    )),
    # SEMI_FORMAL: 하오체
    ("SEMI_FORMAL", re.compile(
        r"(?:하오|하시오|구려|소서|합시다|하겠소|하시게나)\s*[.?!]*\s*$"
    )),
    # SEMI_CASUAL: 하게체
    ("SEMI_CASUAL", re.compile(
        r"(?:하게|하세|하나|하네|하는가|하던가|하겠나|했나)\s*[.?!]*\s*$"
    )),
    # PLAIN: 해라체 / 반말 formal written
    ("PLAIN", re.compile(
        r"(?:한다|한다|간다|먹는다|이다|였다|하였다|했다|겠다|리라|하더라|으리라|것이다"
        r"|하라|하거라|해라|하느냐|하냐|인가|인지|인 것이다)\s*[.?!]*\s*$"
    )),
    # CASUAL: 해체 (반말)
    ("CASUAL", re.compile(
        r"(?:[가-힣]+(?:어|아|해|야|지|거든|잖아|네|군|걸|더라|래|ㄹ걸|ㄹ게|을게|할게"
        r"|이야|인데|거야|잔아|한다니까|는데|ㅋ+|ㅎ+|ㅠ+|ㅜ+))\s*[.?!]*\s*$"
    )),
    # NOMINAL: 명사형 종결
    ("NOMINAL", re.compile(
        r"(?:[가-힣]+(?:함|됨|임|것|수|중|뿐|바|데|점|편|줄|듯|셈|탓|리))\s*[.?]*\s*$"
    )),
    # JAMO: 자모만으로 끝남
    ("JAMO", re.compile(
        r"[ㄱ-ㅎㅏ-ㅣ]+\s*$"
    )),
    # EMOJI: 이모지로 끝남
    ("EMOJI", re.compile(
        "["
        "\U0001F600-\U0001F64F"
        "\U0001F300-\U0001F5FF"
        "\U0001F680-\U0001F6FF"
        "\U0001F1E0-\U0001F1FF"
        "\U00002702-\U000027B0"
        "\U0001F900-\U0001F9FF"
        "\U0001FA00-\U0001FA6F"
        "\U0001FA70-\U0001FAFF"
        "\U00002600-\U000026FF"
        r"]+\s*$",
        flags=re.UNICODE,
    )),
]

# ═══════════════════════════════════════════════════════════════
# Hedging patterns (10 markers)
# ═══════════════════════════════════════════════════════════════

_HEDGING_RE = re.compile(
    r"것\s*같|좀|혹시|아마|어쩌면|글쎄|모르겠|[가-힣]*듯(?:\s|$)|[가-힣]*정도|[가-힣]*수도"
)

# ═══════════════════════════════════════════════════════════════
# Intensifier patterns (17 markers)
# ═══════════════════════════════════════════════════════════════

_INTENSIFIER_RE = re.compile(
    r"진짜|완전|미친|개[가-힣]|존나|졸라|겁나|너무|정말|매우|엄청|되게|무척|아주|굉장히|극도로|레알|ㄹㅇ"
)

# ═══════════════════════════════════════════════════════════════
# Honorific detection
# ═══════════════════════════════════════════════════════════════

_HONORIFIC_VERBS_RE = re.compile(
    r"드리|뵙|여쭙|주무시|잡수시|말씀하|계시"
)
_HONORIFIC_SUFFIX_RE = re.compile(r"[가-힣]+시[가-힣]*")

# ═══════════════════════════════════════════════════════════════
# Negation detection
# ═══════════════════════════════════════════════════════════════

_NEG_SHORT_RE = re.compile(r"(?<![가-힣])(?:안|못)\s+[가-힣]")
_NEG_LONG_RE = re.compile(r"[가-힣]+지\s*(?:않|못)")

# ═══════════════════════════════════════════════════════════════
# Question-type detection
# ═══════════════════════════════════════════════════════════════

_WH_RE = re.compile(r"(?:누구|무엇|뭐|어디|언제|왜|어떻게|어떤|몇|얼마)")
_RHETORICAL_RE = re.compile(
    r"(?:아니\s*겠|할\s*수\s*있겠|는\s*거\s*아니|잖아|겠어\?|겠니\?|겠냐\?|말이야\?|란\s*말이)"
)

# ═══════════════════════════════════════════════════════════════
# Sentence-final mood detection
# ═══════════════════════════════════════════════════════════════

_IMPERATIVE_RE = re.compile(
    r"(?:하세요|하십시오|해라|하거라|해\s*줘|좀\s*해|하시오|하게|합시다"
    r"|하지\s*마|마세요|마라|마시오|마십시오)\s*[.!]*\s*$"
)
_EXCLAMATORY_RE = re.compile(
    r"(?:[가-힣]+(?:구나|구먼|로구나|네[!]+|다니[!]*|잖아[!]+|군[!]+|군요[!]+))\s*$"
    r"|!{2,}\s*$"
)

# ═══════════════════════════════════════════════════════════════
# Sentence splitter (lightweight)
# ═══════════════════════════════════════════════════════════════

_SENT_SPLIT_RE = re.compile(r"(?<=[.?!。！？])\s+")


# ═══════════════════════════════════════════════════════════════
# Internal helpers
# ═══════════════════════════════════════════════════════════════

def _detect_ending_pattern(text: str) -> str:
    sentences = [s.strip() for s in _SENT_SPLIT_RE.split(text) if s.strip()]
    if not sentences:
        return "UNKNOWN"

    if len(sentences) == 1:
        last = sentences[0]
        for name, pat in _ENDING_PATTERNS:
            if pat.search(last):
                return name
        return "UNKNOWN"

    patterns_found: list[str] = []
    for sent in sentences:
        matched = "UNKNOWN"
        for name, pat in _ENDING_PATTERNS:
            if pat.search(sent):
                matched = name
                break
        patterns_found.append(matched)

    unique = set(patterns_found) - {"UNKNOWN"}
    if len(unique) == 0:
        return "UNKNOWN"
    if len(unique) == 1:
        return unique.pop()
    return "MIXED"


def _compute_formality(ending: str, sentences: list[str]) -> Optional[float]:
    if ending == "UNKNOWN":
        return None
    if ending == "MIXED":
        weights: list[float] = []
        for sent in sentences:
            for name, pat in _ENDING_PATTERNS:
                if pat.search(sent):
                    val = ENDING_FORMALITY.get(name)
                    if val is not None:
                        weights.append(val)
                    break
        if not weights:
            return None
        return round(sum(weights) / len(weights), 6)
    return ENDING_FORMALITY.get(ending)


def _count_honorifics(text: str) -> int:
    count = len(_HONORIFIC_VERBS_RE.findall(text))
    count += len(_HONORIFIC_SUFFIX_RE.findall(text))
    return count


def _detect_negation(text: str) -> str:
    has_short = bool(_NEG_SHORT_RE.search(text))
    has_long = bool(_NEG_LONG_RE.search(text))
    if has_short and has_long:
        return "both"
    if has_short:
        return "short"
    if has_long:
        return "long"
    return "none"


def _detect_question_type(text: str) -> str:
    sentences = [s.strip() for s in _SENT_SPLIT_RE.split(text) if s.strip()]
    last = sentences[-1] if sentences else text

    is_question = last.rstrip().endswith("?") or last.rstrip().endswith("？")
    if not is_question:
        endings = re.search(
            r"(?:습니까|나요|ㄹ까요|인가요|하냐|하느냐|니|까|가요|던가요)\s*$", last
        )
        if not endings:
            return "none"

    if _RHETORICAL_RE.search(last):
        return "rhetorical"
    if _WH_RE.search(last):
        return "wh"
    return "yes_no"


def _detect_mood(text: str) -> str:
    sentences = [s.strip() for s in _SENT_SPLIT_RE.split(text) if s.strip()]
    last = sentences[-1] if sentences else text

    if _EXCLAMATORY_RE.search(last):
        return "exclamatory"

    is_question = last.rstrip().endswith("?") or last.rstrip().endswith("？")
    if not is_question:
        q_ending = re.search(
            r"(?:습니까|나요|ㄹ까요|인가요|하냐|하느냐|니$|까$|가요|던가요)\s*$", last
        )
        if q_ending:
            is_question = True
    if is_question:
        return "interrogative"

    if _IMPERATIVE_RE.search(last):
        return "imperative"

    return "declarative"


# ═══════════════════════════════════════════════════════════════
# Public API
# ═══════════════════════════════════════════════════════════════

def process_pragmatics(
    normalized_text: str,
    morph: Optional[MorphologyOutput] = None,
    syntax: Optional[SyntaxOutput] = None,
) -> PragmaticsOutput:
    """Deterministic pragmatic analysis.

    Returns *PragmaticsOutput* — never raises.
    """
    if not normalized_text or not normalized_text.strip():
        return PragmaticsOutput()

    text = normalized_text.strip()
    sentences = [s.strip() for s in _SENT_SPLIT_RE.split(text) if s.strip()]
    if not sentences:
        sentences = [text]

    try:
        ending_pattern = _detect_ending_pattern(text)
        formality_level = _compute_formality(ending_pattern, sentences)
        honorific_count = _count_honorifics(text)
        hedging_count = len(_HEDGING_RE.findall(text))
        intensifier_count = len(_INTENSIFIER_RE.findall(text))
        negation_type = _detect_negation(text)
        question_type = _detect_question_type(text)
        sentence_final_mood = _detect_mood(text)
    except Exception:
        return PragmaticsOutput()

    return PragmaticsOutput(
        ending_pattern=ending_pattern,
        formality_level=formality_level,
        honorific_count=honorific_count,
        hedging_count=hedging_count,
        intensifier_count=intensifier_count,
        negation_type=negation_type,
        question_type=question_type,
        sentence_final_mood=sentence_final_mood,
    )
