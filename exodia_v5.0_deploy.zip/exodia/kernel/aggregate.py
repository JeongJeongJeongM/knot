"""EXODIA v3.0 — NLP Session Aggregation (Phase 6).

Aggregate per-turn L0/L1/L2 NLP kernel outputs into session-level
NLPAggregate for Path A/C cross-validation.

100 % deterministic.  Never raises; returns default NLPAggregate on failure.
"""

from __future__ import annotations

from collections import Counter

from exodia.constants import EPSILON
from exodia.models.outputs import (
    MorphologyOutput,
    NLPAggregate,
    PragmaticsOutput,
    SyntaxOutput,
)

# ═══════════ Statistical helpers ═══════════


def _weighted_mean(values: list[float], weights: list[float]) -> float:
    """Weighted mean with EPSILON-safe denominator."""
    total_w = sum(weights)
    if total_w < EPSILON:
        return 0.0
    return sum(v * w for v, w in zip(values, weights)) / total_w


def _simple_mean(values: list[float]) -> float:
    if not values:
        return 0.0
    return sum(values) / len(values)


def _population_variance(values: list[float]) -> float:
    """Population variance (ddof=0)."""
    if not values:
        return 0.0
    mean = sum(values) / len(values)
    return sum((v - mean) ** 2 for v in values) / len(values)


def _linear_regression_slope(values: list[float]) -> float:
    """OLS slope of *values* over index 0..n-1."""
    n = len(values)
    if n < 2:
        return 0.0
    x_mean = (n - 1) / 2.0
    y_mean = sum(values) / n
    num = sum((i - x_mean) * (v - y_mean) for i, v in enumerate(values))
    den = sum((i - x_mean) ** 2 for i in range(n))
    if abs(den) < EPSILON:
        return 0.0
    return num / den


# ═══════════ NLP kernel version detection ═══════════


def _get_nlp_kernel_version() -> str:
    """Return '{mecab}_{stanza}_{yaml}' version string, or 'fallback_v1'."""
    try:
        mecab_ver: str | None = None
        try:
            import mecab as _mecab_mod  # type: ignore[import-untyped]

            mecab_ver = getattr(_mecab_mod, "__version__", "unknown")
        except ImportError:
            import MeCab as _MeCab_mod  # type: ignore[import-untyped]

            mecab_ver = getattr(_MeCab_mod, "VERSION", "unknown")

        import stanza  # type: ignore[import-untyped]

        stanza_ver = getattr(stanza, "__version__", "unknown")

        import yaml  # type: ignore[import-untyped]

        yaml_ver = getattr(yaml, "__version__", "unknown")

        return f"{mecab_ver}_{stanza_ver}_{yaml_ver}"
    except ImportError:
        return "fallback_v1"


# ═══════════ Public API ═══════════


def compute_nlp_aggregate(
    morphology_outputs: list[MorphologyOutput],
    syntax_outputs: list[SyntaxOutput],
    pragmatics_outputs: list[PragmaticsOutput],
) -> NLPAggregate:
    """Aggregate per-turn NLP kernel outputs into a session-level NLPAggregate."""
    version = _get_nlp_kernel_version()

    if not morphology_outputs:
        return NLPAggregate(nlp_kernel_version=version)

    n = len(morphology_outputs)

    # ═══════════ L0 Morphology Aggregation ═══════════

    token_counts = [float(m.token_count) for m in morphology_outputs]

    avg_function_content_ratio = _weighted_mean(
        [m.function_content_ratio for m in morphology_outputs],
        token_counts,
    )
    avg_unique_token_ratio = _weighted_mean(
        [m.unique_token_ratio for m in morphology_outputs],
        token_counts,
    )
    avg_oov_ratio = _simple_mean([m.oov_ratio for m in morphology_outputs])
    avg_repetition_score = _simple_mean(
        [m.repetition_score for m in morphology_outputs],
    )

    all_nnp: set[str] = set()
    for m in morphology_outputs:
        all_nnp.update(m.proper_noun_list)
    proper_noun_set = sorted(all_nnp)

    mid = n // 2
    first_half_nnp: set[str] = set()
    for m in morphology_outputs[:mid]:
        first_half_nnp.update(m.proper_noun_list)
    second_half_nnp: set[str] = set()
    for m in morphology_outputs[mid:]:
        second_half_nnp.update(m.proper_noun_list)

    overlap = first_half_nnp & second_half_nnp
    total_unique = len(all_nnp)
    proper_noun_consistency = len(overlap) / total_unique if total_unique > 0 else 0.0

    # ═══════════ L1 Syntax Aggregation ═══════════

    avg_tree_depth = (
        _simple_mean([s.avg_tree_depth for s in syntax_outputs])
        if syntax_outputs
        else 0.0
    )
    avg_modifier_ratio = (
        _simple_mean([s.modifier_ratio for s in syntax_outputs])
        if syntax_outputs
        else 0.0
    )
    avg_dependency_distance = (
        _simple_mean([s.dependency_distance for s in syntax_outputs])
        if syntax_outputs
        else 0.0
    )
    avg_sentence_length = (
        _simple_mean([s.avg_sentence_length for s in syntax_outputs])
        if syntax_outputs
        else 0.0
    )
    avg_clause_count = (
        _simple_mean([float(s.clause_count) for s in syntax_outputs])
        if syntax_outputs
        else 0.0
    )
    avg_subordination_ratio = (
        _simple_mean([s.subordination_ratio for s in syntax_outputs])
        if syntax_outputs
        else 0.0
    )

    # ═══════════ L2 Pragmatics Aggregation ═══════════

    formality_values = (
        [
            p.formality_level
            for p in pragmatics_outputs
            if p.formality_level is not None
        ]
        if pragmatics_outputs
        else []
    )

    avg_formality_level = _simple_mean(formality_values)
    formality_variance = _population_variance(formality_values)
    formality_trend = _linear_regression_slope(formality_values)

    total_hedging_count = (
        sum(p.hedging_count for p in pragmatics_outputs)
        if pragmatics_outputs
        else 0
    )
    total_intensifier_count = (
        sum(p.intensifier_count for p in pragmatics_outputs)
        if pragmatics_outputs
        else 0
    )
    total_honorific_count = (
        sum(p.honorific_count for p in pragmatics_outputs)
        if pragmatics_outputs
        else 0
    )

    pattern_counter: Counter[str] = Counter()
    if pragmatics_outputs:
        for p in pragmatics_outputs:
            pattern_counter[p.ending_pattern] += 1
    pattern_total = sum(pattern_counter.values())
    ending_pattern_distribution: dict[str, float] = (
        {k: v / pattern_total for k, v in sorted(pattern_counter.items())}
        if pattern_total > 0
        else {}
    )

    # ═══════════ Timeseries Aggregation ═══════════

    response_length_trend = _linear_regression_slope(
        [float(tc) for tc in token_counts],
    )

    if len(formality_values) >= 2:
        f_mid = len(formality_values) // 2
        first_half_mean = _simple_mean(formality_values[:f_mid])
        second_half_mean = _simple_mean(formality_values[f_mid:])
        formality_shift_magnitude = abs(first_half_mean - second_half_mean)
    else:
        formality_shift_magnitude = 0.0

    return NLPAggregate(
        avg_function_content_ratio=avg_function_content_ratio,
        avg_unique_token_ratio=avg_unique_token_ratio,
        avg_oov_ratio=avg_oov_ratio,
        avg_repetition_score=avg_repetition_score,
        proper_noun_set=proper_noun_set,
        proper_noun_consistency=proper_noun_consistency,
        avg_tree_depth=avg_tree_depth,
        avg_modifier_ratio=avg_modifier_ratio,
        avg_dependency_distance=avg_dependency_distance,
        avg_sentence_length=avg_sentence_length,
        avg_clause_count=avg_clause_count,
        avg_subordination_ratio=avg_subordination_ratio,
        avg_formality_level=avg_formality_level,
        formality_variance=formality_variance,
        formality_trend=formality_trend,
        total_hedging_count=total_hedging_count,
        total_intensifier_count=total_intensifier_count,
        total_honorific_count=total_honorific_count,
        ending_pattern_distribution=ending_pattern_distribution,
        response_length_trend=response_length_trend,
        formality_shift_magnitude=formality_shift_magnitude,
        nlp_kernel_version=version,
    )
