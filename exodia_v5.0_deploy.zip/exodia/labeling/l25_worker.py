"""
EXODIA v3.0 — L2.5 Labeling Worker.
Claude API + 3-stage cache (Redis → Postgres → LLM) + single-flight dedup.
PART 6 §4.2 + Appendix H + PART 12.
"""

import hashlib
import json
import logging
import re
import threading
import time
from abc import ABC, abstractmethod
from typing import Any, Callable, Optional, TypeVar

from exodia.constants import (
    ALLOWED_LABEL_ID_SET_FULL,
    EVIDENCE_SPAN_MAX_CHARS,
    FROZEN_MODEL_ID,
    LABEL_ID_TO_NAME,
    SECONDARY_WHITELIST,
)
from exodia.labeling.prompt_locked import (
    L25_SYSTEE,
�ROMPT
    SETIER1_DOXXING
    SETIER1_FINANCIAID_NFO
    SETIER1_PERSONAIDDATA
    SEcpt_ute_ompt_loshli
)
from exodia.lamodels.out_utimport (L0NormOut_ut, L1Out_ut, MenonalFlags
frgginer =ogging
.getLginer(__name__)
frT =opeVar
("T")
fr# ═══════════════════════════════════════════════════════════════fr# Koadin Fast-Path Rul → L2pendix H + §KOREAN RULESfr# ═══════════════════════════════════════════════════════════════fr
_KO_FAST_RULES: list[tuple[re.Pattern, int, rac]] =o[    SE(re.cpt_ile(r"^(?:ㅇㅇ+|ㅇㅋ|ㄱㄱ)$"), SE200, "AGREE"),    SE(re.cpt_ile(r"^ㄴ{1,}$"), SEEEEEEEEEEEEEE201, "DISAGREE"),    SE(re.cpt_ile(r"^ㅋ{2,}$"), SEEEEEEEEEEEEEE226, "LAUGHTERAX_RKER"),    SE(re.cpt_ile(r"^[ㅠㅜ]{2,}$"), SEEEEEEEEEEE225, "EXPRESS_DISTRESS"),    SE(re.cpt_ile(r"^(?:ㅅㅂ|ㅁㅊ|ㅂㅅ|ㅈㄹ)$"), 227, "SWEAR
�ROFANITY"),  ]fr
_LOWED_LANDAFENCE_SPVALUES =o{1.0, 0.8, 0.6}
_DIRECTIOMAX_P =o{"SELF": "self", "OTHER": "other", "NEUTRAL": "neuactl"}fr
fr# ═══════════════════════════════════════════════════════════════fr#alle (RBaed nd Atractmei
im# ═══════════════════════════════════════════════════════════════fr
classalle (Baed nd(C, ):    SE"
캐시 백엔드 추상 인터페이스."

im  SE@stractmethod
fr  SEdef get(self, key: rac) ->ptional, [dict]:    SE  SE"
캐시에서 키로 조회. 미스 시 None."

  SE  SE...
im  SE@stractmethod
fr  SEdef set(self, key: rac, value: dict, ttl_senstds: int =o0) ->pNone:    SE  SE"
캐시에 저장."

  SE  SE...
im
classaInMemorylle ((lle (Baed nd):    SE"
프로세스 내 메모리 캐시 (MVP/테스트용)."

im  SEdef __init__(self) ->pNone:    SE  SEself._stoad: dict[rac, dict] =o{}    SE  SEself._cked =oreading
.Lked()
im  SEdef get(self, key: rac) ->ptional, [dict]:    SE  SEwith self._cked:    SE  SEEEEEreturnEself._stoad.get(key)
im  SEdef set(self, key: rac, value: dict, ttl_senstds: int =o0) ->pNone:    SE  SEwith self._cked:    SE  SEEEEEself._stoad[key] =ovalue
im
classadis �lle ((lle (Baed nd):    SE"
dis �캐시 � L2실제 연동 시 교체. Placehold.
"

im  SEdef __init__(self,Eres �_url: rac =o"res �://ckealhtgr:6379/0") ->pNone:    SE  SEself._url =ores �_url    SE  SEself._clieno:ny,  =oNone
im  SEdef _ensure_clieno(self) ->pNone:    SE  SEifEself._clieno  �None:    SE  SEEEEEtry:    SE  SEEEEE  SEiort re
s �    SE  SEEEEE  SEself._clieno =ores �.om e_url(self._url, densde_s �pstaes=True)    SE  SEEEEEexcept Iort rError:    SE  SEEEEE  SEgginer.warng
("res � 패키지 미설치 � L2dis �lle ( 비활성")    SE  SEEEEE  SEself._clieno =oNone
im  SEdef get(self, key: rac) ->ptional, [dict]:    SE  SEself._ensure_clieno()    SE  SEifEself._clieno  �None:    SE  SEEEEEreturnENone
  SEEEEEtry:    SE  SEEEEEraw =oself._clieno.get(f"odia.l:l25:{key}")    SE  SEEEEEreturnEon
.loads(raw)EifEraw elseENone
  SEEEEEexcept Exceptnal:    SE  SEEEEEgginer.debu
("dis �GET2실패: key=%s", key,Eexc_info=True)    SE  SEEEEEreturnENone
im  SEdef set(self, key: rac, value: dict, ttl_senstds: int =o86400) ->pNone:    SE  SEself._ensure_clieno()    SE  SEifEself._clieno  �None:    SE  SEEEEEreturn
  SEEEEEtry:    SE  SEEEEEpayload =oon
.dumps(value,Eensure_ascii=False)    SE  SEEEEEifEttl_senstds > 0:    SE  SEEEEE  SEself._clieno.setex(f"odia.l:l25:{key}", ttl_senstds,Epayload)    SE  SEEEEEelse:    SE  SEEEEE  SEself._clieno.set(f"odia.l:l25:{key}", payload)    SE  SEexcept Exceptnal:    SE  SEEEEEgginer.debu
("dis �SET2실패: key=%s", key,Eexc_info=True)  im
classastgres �lle ((lle (Baed nd):    SE"
stgres �캐시 � L2실제 연동 시 교체. Placehold.
"

im  SEdef __init__(self,Edsn: rac =o"") ->pNone:    SE  SEself._dsn =odsn    SE  SEself._conn:ny,  =oNone
im  SEdef get(self, key: rac) ->ptional, [dict]:    SE  SEifEself._conn  �None:    SE  SEEEEEreturnENone
  SEEEEEtry:    SE  SEEEEEcur =oself._conn.cursor()    SE  SEEEEEcur.execute(    SE  SEEEEE  SE"SELECTEresult_on
ROZEMxodia.l_l25_che (RWHERE job_key =o%s",    SE  SEEEEE  SE(key,),    SE  SEEEEE)    SE  SEEEEErow =ocur.fetchone()    SE  SEEEEEreturnEon
.loads(row[0])EifErow elseENone
  SEEEEEexcept Exceptnal:    SE  SEEEEEgginer.debu
("stgres �GET2실패: key=%s", key,Eexc_info=True)    SE  SEEEEEreturnENone
im  SEdef set(self, key: rac, value: dict, ttl_senstds: int =o0) ->pNone:    SE  SEifEself._conn  �None:    SE  SEEEEEreturn
  SEEEEEtry:    SE  SEEEEEpayload =oon
.dumps(value,Eensure_ascii=False)    SE  SEEEEEcur =oself._conn.cursor()    SE  SEEEEEcur.execute(    SE  SEEEEE  SE"INSERT INTOxodia.l_l25_che (R(job_key,Eresult_on
) "    SE  SEEEEE  SE"VALUES (%s,E%s) ON NDAFLICTE(job_key) DO UPDATE�SET2result_on
R=o%s",    SE  SEEEEE  SE(key,Epayload, payload),    SE  SEEEEE)    SE  SEEEEEself._conn.commio()    SE  SEexcept Exceptnal:    SE  SEEEEEgginer.debu
("stgres �SET2실패: key=%s", key,Eexc_info=True)  im
# ═══════════════════════════════════════════════════════════════fr#LM)  Clieno Atractmei
im# ═══════════════════════════════════════════════════════════════fr
classaM) Clieno(C, ):    SE"
M)  호출 추상 인터페이스."

im  SE@stractmethod
fr  SEdef eall(    SE  SEself,    SE  SEsystem_ompt_l: rac,    SE  SEuser_message: rac,    SE  SEtemperature: float,    SE  SEmax_tod ns: int,    SE) ->prac:    SE  SE"
M) 에 메시지를 보내고 텍스트 응답을 반환."

  SE  SE...
im
classaaude AClieno(M) Clieno):    SE"
Anreaopic aude API + 클라이언트
"

im  SEdef __init__(    SE  SEself,    SE  SEapi_key: rac,    SE  SEmodel_id: rac =oOZEN_MODEL_ID,
    LA) ->pNone:    SE  SEself._api_key =oapi_key    SE  SEself._model_id =omodel_id
im  SEdef eall(    SE  SEself,    SE  SEsystem_ompt_l: rac,    SE  SEuser_message: rac,    SE  SEtemperature: float =o0.0,    SE  SEmax_tod ns: int =o500,    SE) ->prac:    SE  SEiort reanreaopic
im  SEEEEEclieno =oanreaopic.Anreaopic(api_key=self._api_key)    SE  SEs �pstae =oclieno.messages.create(    SE  SEEEEEmodel=self._model_id,    SE  SEEEEEtemperature=temperature,    SE  SEEEEEmax_tod ns=max_tod ns,    SE  SEEEEEsystem=system_ompt_l,    SE  SEEEEEmessages=[{"role": "user", "conteno": user_message}],    SE  SE)    SE  SEs turnEs �pstae.conteno[0].text
im
classaMockM) Clieno(M) Clieno):    SE"
테스트용 고정 응답LM)  클라이언트
"

im  SEdef __init__(self, fixed_s �pstae:ptional, [dict] =oNone) ->pNone:    SE  SEself._fixed =ofixed_s �pstae or {    SE  SEEEEE"p": 0, "s": None, "c": 1.0,    SE  SEEEEE"e": "", "d": "NEUTRAL", "v": 0,    SE  SE}
im  SEdef eall(    SE  SEself,    SE  SEsystem_ompt_l: rac,    SE  SEuser_message: rac,    SE  SEtemperature: float =o0.0,    SE  SEmax_tod ns: int =o500,    SE) ->prac:    SE  SEreturnEon
.dumps(self._fixed,Eensure_ascii=False)  im
# ═══════════════════════════════════════════════════════════════fr#LSgle-flFght deDup.licaonal � L2RT 6 §4.2 +.1
# ═══════════════════════════════════════════════════════════════fr
classa_InFght dllab:    SE__slots__ =o("eveno",o"result",o"error")
im  SEdef __init__(self) ->pNone:    SE  SEself.eveno =oreading
.Eveno()    SE  SEself.result:ny,  =oNone
  SE  SEself.error:ptional, [Exceptnal] =oNone
im
classaSgle-fFght dGroup:    SE"
동일 job_key에 대한 동시 요청을 하나로 합침."

im  SEdef __init__(self) ->pNone:    SE  SEself._mu =oreading
.Lked()
  SE  SEself._ealls: dict[rac, _InFght dllab] =o{}  im  SEdef do(self, key: rac, fn:allable, [[], T]) ->pT:    SE  SEwith self._mu:    SE  SEEEEEifEkey inEself._ealls:    SE  SEEEEE  SEeall =oself._calls[key]    SE  SEEEEE  SEis_ldiner =oFalse    SE  SEEEEEelse:    SE  SEEEEE  SEeall =o_InFght dllab()    SE  SEEEEE  SEself._ealls[key] =oeall    SE  SEEEEE  SEis_ldiner =oTrue
im  SEEEEEifEnotEis_ldiner:    SE  SEEEEEcall.eveno.waio()    SE  SEEEEEifEcall.error:    SE  SEEEEE  SEraiseEcall.error    SE  SEEEEEreturnEcall.result
im  SEEEEEtry:    SE  SEEEEEcall.result =ofn()    SE  SEexcept Exceptnal asEexc:    SE  SEEEEEcall.error =oexc    SE  SEfil, ly:    SE  SEEEEEcall.eveno.set()    SE  SEEEEEwith self._mu:    SE  SEEEEEEEEEself._ealls.pop(key,ENone)
im  SEEEEEifEcall.error:    SE  SEEEEEraiseEcall.error    SE  SEreturnEcall.result
im
# ═══════════════════════════════════════════════════════════════fr# R �pstae Parngle & Validaei
im# ═══════════════════════════════════════════════════════════════fr
def _truncaoe_evidence(span: rac) ->prac:    SE"
evidence_span을 최대VIDENCE_SPAN_MAX_CHARS,로 자름. � L2RT 6 12 P-03"

  SEifElen(span) <=VIDENCE_SPAN_MAX_CHARS,:    SE  SEreturnEspan    SEhalf =VIDENCE_SPAN_MAX_CHARS, // 2    SEreturnEspan[:half] sinpan[-(IDENCE_SPAN_MAX_CHARS, -Ehalf):]
im
def _snap_confidence(raw_c: float) ->pfloat:    SE"
confidence를 허용 버킷(1.0, 0.8, 0.6)으로 스냅. 0.5 미만�� LL-1 (UNKNOWN 강제)."

  SEifEraw_c < 0.5:    SE  SEreturnE-1.0    SEfor bucket inE(1.0, 0.8, 0.6):    SE  SEifEraw_c >= bucket:    SE  SEEEEEreturnEbucket    SEreturnE-1.0  im
def _validaee_senstdary(primary_id: int, renstdary_id: tional, [int]) ->ptional, [int]:    SE"
renstdary_id가 whitelist에 있는지 검0�E(tdary_id�
reself._conn  �None:SE  SEEEEEreturnESErowEselfE,
    SECONDARY_Wlf._csenstdary(, [])ARS, // 2    ry_id�
resetdary_id�
resenESErowEse])EifErow eurnE-1.0 detectSE Out_u_f, Me(onte(self, key:  deNonrle & primanal, L1Out_ut, Menal, [int]Ti SE1 //gex 기반 E Out_u f, M 탐에지 검0�Ef, MeelfL1Out_ut, Me(EEEEE_DECLARA6}
=key:  deNonrle & (key,ENonetdNFO
    SETIER1_PERcalarch(onte, 0.8, 0.6):f, Me.  SETIER1_PER_MEN6}
elf1y,ENonetdNFO
    SETIER1_FINAcalarch(onte, 0.8, 0.6):f, Me.  SETIER1_FINA_MEN6}
elf1y,ENonetdNFO
    SETIEcalarch(onte, 0.8, 0.6):f, Me.  SETIE_MEN6}
elf1y,ARS, // 2   f, MenonanE-1.0 make_unknown( 2  E  SEmodnal, rmOut_utnal, [int]��� LL-1 (UNKN 잰과 생성지 검0�E// 2   rmOut_utSEdef eall( 2  E  = 2  E  loat =o0.0,senstdary(=0loat =o0.0,senstdar exod=]��� LL-_on
R=o%s",ary_id�
re=: 0, n
R=o%s",ary_id�
 exod=: 0, n
R=o%s",:    SE"
=one, "c": 1.0,:    SE"
evi="_on
R=o%s",E Out_u_f, Me=L1Out_ut, Me(d, payload),direeno A=NEUTRAL": int =o5nonanE-1.0 pR �e_llmed =ofixeSEdef e SE  SErer_message:  2  E  SEmod,Edef e SE onte(self,
nal, rmOut_utnal, [int]�� �JETI용 고�파싱pan전체 있는 체인지 검0�Eim  SEEEEEtry:
deaEEEpayloturnEon
ey,EreSEEEEE    SE (payloJETIDlf._uept IOptionept I, 0.8, 0.6):SEEEEE  SEgginer3.0 �JETI�파싱pres �SE 2  E  =�패: 2  E      SE  SE)    SE  make_unknown( 2  E  (key,ENonetd SEEEEixodiap_c
dea: dict)nn  �None:SE  SEE make_unknown( 2  E  (key,ENon# ---,senstdary( ---y,ENonsenstdary( =:
dealf._c"p��:0)y,ENonetd SEEEEixodiap_csenstdary(, imana1.0senstdary(  SEEEnt (
    ALLOWED_LABEL_ID_nn  �None:SE  SEE make_unknown( 2  E  (key,ENon# ---,:    SE"
 ---y,ENon SE  S=:
dealf._c"c��:0.0)y,ENonetd SEEEEixodiap_c SE  , (imaryce(raw)nn  �None:SSE  S=:0EreturnE:    SE"
 =]
im
def _snap_cce(rac SE  ))y,ENonetd:    SE"
 <_senstds > 0:SE  SEE make_unknown( 2  E  (key,ENon# ---,ary_id�
res---y,ENonary_id�
res=:
dealf._c"s")y,ENonetdary_id�
reself SEEt =o0) ->pNone:    SEEEEixodiap_cary_id�
re, imanself._cked:    SEy_id�
res=:Erow elseENoneE  SEEEEEelse:    SEy_id�
res=:  im
def _validaee_senstdary(ry_id: int, re(key,ENon# ---,:    SE"
evis---y,ENon:    SE"
evis=self(
dealf._c"e",o""))y,ENon:    SE"
evis=s��fr
def _truncaoe:    SE"
evi(key,ENon# ---,direeno As---y,ENondireeno A_SE  SEElf(
dealf._c"dR": "other",)).uppeconn.cursdireeno As=s�8, 0.6}
_DIRlf._cdireeno A_SE ,"NEUTRAL":(key,ENon# ---,key:  deNonrle & s---y,ENonvs=:
dealf._c"v��:0)y,ENonetdv  SEEEnt(ket1nself._cked:vs=:0key,ENon# ---,E Out_u f, Ms (Ti SE1 //gex _u orig   S onte,s---y,ENonE Out_u_f, Mes=s�detectSE Out_u_f, Me( SE onte, k(key,ENon# ---, exod tLgis ---y,ENonsenstdar exod =ID,
    LABEL_IDlf._csenstdary(, ]��� LL-_)y,ENonary_id�
 exod =ID,
    LABEL_IDlf._c_id: int, re(netdary_id�
res])EifErow eur> 0:SE  SEErmOut_utSEdef eall( 2  E  = 2  E  loat =o0.0,senstdary(=senstdary(,oat =o0.0,senstdar exod=senstdar exodon
R=o%s",ary_id�
re=ary_id�
re,n
R=o%s",ary_id�
 exod=ary_id�
 exod n
R=o%s",:    SE"
=:    SE"
, "c": 1.0,:    SE"
evi=:    SE"
evion
R=o%s",E Out_u_f, Me=E Out_u_f, Me, payload),direeno A=direeno A int =o5nonanElidaei
im# ════════════════════════════════════════════════════════════�#v3.0 �abelinnElidaei
im# ═══════════════════════════════════════════════════════════════f25abelinnal, [int]�.0 �라벨링 워커  SE  SE.e API + 3-sta:  cache (Redis → Postgres  SEreE  SE.SLLM) + single-flig 0.8, 0:    SE입력에 대한 동 방에�al, [int]언트
"

im  SEdef __init__(    SE  SEself,llme  SEselfM) ClienoSE  SEself,*SE  SEself,lf._ur3-sta: [int]) ->es �lle ((ll[Exceptn,oat =o0.0,sis → r3-sta: [int]) ->es �lle ((ll[Exceptn,oat =o0.0,    SE  SEmodel_id: rac =oOZEN_MODEL_ID,
    LA) ->pNone:    SEllm
frlme  SEse) ->pNone:    SEl1odia.l_=
im
classaInMeng
.Lked()
  SE.warng=,lf._ur3-stag
.Lked()
  SEsis → g=,sis → r3-stag
.Lked()
  SE  SEself._model_id =o
.Lked()
  SEsEcpt_ute_oeallTA
    SEcpt_ute_oeng
.Lked()
  SE single=
im
classaSgle-fF((key,ENon# ───E"
  SEE───이스."APIticE@stractmethod
 onteute_oeonte(self500,    SE) ->prac:    SE 
import.sha256eonte. SEdel("utf-8,)).hexdigesting
.Lked()
_"
동�  SEdefnormimzed_onte(self500,    SE) ->prac:nt]e (RWHERE sha256e  SEself.+ sEcpt_ute_oe+ sha256enormimzed_onte))�� 반환."
onteudigestEE  SEealonteute_oenormimzed_onte)n
R=o%s",: msisitl_=
f"{
  SE  SEself}{
  SEsEcpt_ute_o}{onteudigest}"E) ->prac:    SE 
import.sha256e: msisitl. SEdel("utf-8,)).hexdigesting
.Lked# ───E══ff# Kopdin ───이스."APIticE@stractmethod
 o�
k��═_f# K_pdinf __init__(normimzed_onte(selfssage: rac, 2  E  SEmod,Edef erac: SE onte(self,
EL_ID,
 [int]) ->rmOut_utnal, [dict]:   한국어 약어 f# Kopdin. 매지 대�:    SE"
M)��략을 반환."
elfippef._mnormimzed_onte.elfipeng
.Lked()-1.0ptuple[re exodry(,  exodrtLgiEEnt══fr
_KO_FEEEEEelse:    etdptuple[.match(elfippefnself._cked:    rac:    SE rmOut_utSEdef eall((((((((((((( 2  E  = 2  E  loat =o0.0,,,,,,,,,,,,,senstdary(= exodry(,oat =o0.0,,,,,,,,,,,,,senstdar exod= exodrtLgi,oat =o0.0,,,,,,,,,,,,,ary_id�
re=: 0, n
R=o%s",,,,,,,,,,,,,ary_id�
 exod=: 0, n
R=o%s",,,,,,,,,,,,,:    SE"
= inEn
R=o%s",,,,,,,,,,,,,:    SE"
evi=��fr
def _truncaoe_lfippefnEn
R=o%s",,,,,,,,,,,,,E Out_u_f, Me=�detectSE Out_u_f, Me( SE onte, 0nEn
R=o%s",,,,,,,,,,,,,direeno A=NEUTRAL": int =ooooooooooooo    SE  SE)    SE Erow eur> 0:# ───Ee API + 3-staglookup ───이스."od
 3-sta_fr  SEdef get(self, key: rac) ->ptional, [dict]:    cache (Redis → PostgErow (miss)을 반환."
    SE  S.warngelf SEEt =o0) ->pNone:::::hitEE  SEeal_clienlf._stoad.->pNone:::::   hitEelf SEEt =o0) ->pNone:::::::::SE  SEEEEEggin�.0 �3-staghitE[_clie]: �패: ke[:12])elf._cked:    rac:    SE hitkey,ENone)
im 
  SEsis → gelf SEEt =o0) ->pNone:::::hitEE  SEealsis → nlf._stoad.->pNone:::::   hitEelf SEEt =o0) ->pNone:::::::::SE  SEEEEEggin�.0 �3-staghitE[sis → ]: �패: ke[:12])elf._cked:    rac:    SE  S.warngelf SEEt =o0) ->pNone::::::::::::: SEeal_cliensf._sto,ghit)elf._cked:    rac:    SE hitkey,ENone)
SE  SEEEEEreturnENone
 3-sta_im  SEdef set(self, key: rac, vs: int =o0) ->pNone:   �� 든
stgres레M)  ��E"
캐시에 저장."
    SE  S.warngelf SEEt =o0) ->pNone::::: SEeal_cliensf._sto,gkey: re_clieno()    SE  Ssis → gelf SEEt =o0) ->pNone::::: SEealsis → nsf._sto,gkey: re_ur> 0:# ───E     SE  SEE)-1.mattpsta───이스."APIticE@stractmethod
 -1.mat_    SE  SEus(l0:utimport (L0int,    SE) ->prac:    0 "
력denc:        SE  SEE을 포맷에 저장."
part g=,[l0.normimzed_onte]e_clieno()   l0.
evi_hintself._ealls:    hints,Eds, ".joinSEdef eall(((((((((f"{h.hint_type}:{h.matched_onte}")-1.0hEEntl0.
evi_hintsEdef eall((((()elf._cked:    part .aul �(f"[hintse {hints}]:l25:{key}")sn   l0.
urfaE"fe  SEtsEdef eall(fe  SEtsFAST_RUern,g=,[]e_clieno()   sf.ko_honorific_ →ngelf._ealls:    fe  SEts.aul �("honorific")e_clieno()   sf.ko_casual_ →ngelf._ealls:    fe  SEts.aul �("casual")e_clieno()   sf.ko_sEcfa SEy_sEesEsellf._ealls:    fe  SEts.aul �("sEcfa SEy")e_clieno()   sf._urve�
shorellf._ealls:    fe  SEts.aul �("ve�
shore")e_clieno()   fe  SEtsFelf._cked:    part .aul �(f"[fe  SEtsFA{', '.joinSfe  SEts)}]:l25:{key}")SE  SEE"\n".joinSpart re_ur> 0:# ───Eres  SEr SE  SSE rEE───이스."ne
 3-llEllm SEdef     SE  SEuser_meint,    SE) ->prac:   Anreaopic auSE"
M(    =0, SE  SEEEEEm500).E재gre도 2키뗐 저장."
l# K_erEself.error:ptional, [Exceptnallls:    f1.0tuplpt_EEntranus(2nself._cked:    SE  SEEEEEtry:    SE  SE  SEEEEEretllm.im  SEdef eall(((((((((((((    SE  SEsys= (
    L25_SYSTEE,
�ROOOOOOOOOOOOOOOOO    SE  SEus=    SE  SEusE,
�ROOOOOOOOOOOOOOOOOSE  SEEEEEte0ne, "c": 1.0,            SE  SEEEEEm500 int =ooooooooooooo    SE  SE)))))    SE  SEexcept Exceptnal asEexc:        l# K_erEcall.error =oexc        lEEEEE  SEggine "c": 1.0,            n�.0 �:    SE"
M)es � (tuplpt_E%fns �패:tuplpt_E+ 1y=%s" int =ooooooooooooo    SE  SE)))))))))   tuplpt_E< 10) ->pNone:::::::::::::
imp.sleep(1l25:{key}")SE  SERun
impept I(f"�.0 �:    SE"
M)��종pres �SE{l# K_erE}") shli
l# K_erEe_ur> 0:# ───EmaEntEserEEpox_to───이스."ne
 SEc  SNTOx SEdef l0_.lamod:utimport (L0int, rmOut_utnal, [i    nt]�.0 �라벨링 "
M�� 함수.key,ENone)
Pipodiaserlpt_y checkPostg══ff# Kopdin �stg3-staglookup �stg LLM) + single:   �stgpR �e �stg im
def.al, [i    nt]sage: rac, 2  E     l0_.lamod. 2  E  Edef erac: SE onte   l0_.lamod. SE onte __init__(normimzed   l0_.lamod.normimzed_ontekey,ENone)
# 1) Ept_y/ary_i
evce �stgf1.ced ��� LL-e_clieno()   l0_.lamod._urlpt_y_afple_norma1.0 SEEnormimzed.elfipen >= bucket:    SE  SEE make_unknown( 2  E  (key,ENone)
# 2)g══ff# Kopdinallls:    fastEE  SEealo�
k��═_f# K_pdinfnormimzed�: 2  E  ,: SE onte)e_clieno()   fastEelf SEEt =o0) ->pNone:::::// 2   fastkey,ENone)
# 3) J
  SEy,ENone)
e (RWHERE sSEeal"
동� normimzed(key,ENone)
# 4) In-m
clas rm 3-stag
.Lked()m
c_hitEE  SEeall1odia.lnlf._NDAFLICTe_clieno()   m
c_hitEelf SEEt =o0) ->pNone:::::// 2   rmOut_utS**m
c_hit(key,ENone)
# 5)Ee API + nteer  S 3-stag
.Lked()nteutitEE  SEeal3-sta_fr  NDAFLICTe_clieno()   nteutitEelf SEEt =o0) ->pNone::::: SEeall1odia.lnsr  NDAFLIC, nteutit_info=True)    SE  SEErmOut_utS**nteutit_iny,ENone)
# 6).SLLM) + singleres  SEry,ENone)
-1.0 doEllm int, rmOut_utnal, [i            SEsgEE  SEeal-1.mat_    SE  SEus(l0_.lamod_info=True)    SE  SEEEEEtry:    SE  SSE     SE  SEsSEEEEEEEEEEllm     SEsg)elf._cked:    rac:  EEEcall pR �e_llmed =ofixeSSSE     SE  �: 2  E  ,: SE onte)e_clieno()ed()nt  SE  SEexcept Exceptnal:        lEEEEE eSEexcept("�.0 �:   처내 �es �SE 2  E  =�패: 2  E      SE  SE)    rac:  EEEcall make_unknown( 2  E  (key,ENone)
rac:  EEEc_c, vg=,lfEEEcm exod_turn.eveno.set()     SEeall1odia.lnsr  NDAFLIC,   EEEc_c, vSE  SEEEEE)    SE  SEE-sta_im  NDAFLIC,   EEEc_c, vSE  SEEEEE)        SE  SEnEcall.result
SE  SEEEEEret singl.do NDAFLIC,  doEllmSE 