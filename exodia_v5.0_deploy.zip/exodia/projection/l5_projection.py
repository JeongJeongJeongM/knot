"""
EXODIA v3.0 — L5 Projection (PCR).
순수 Python. LLM 금지. 결정론적.
구현 기준: PART 4 §3.
"""
from __future__ import annotations

from typing import Optional

from exodia.constants import PCR_EXPECTATIONS
from exodia.models.outputs import L3Output, L4Output

_INTENSITY_KEYS = ["A1", "A2", "A3", "A4", "A5", "A6"]
_DEFAULT_PURPOSE = "P.CASUAL"


def compute_l4_projection(
    session_id: str,
    l3_output: L3Output,
    purpose_distribution: dict[str, float],
) -> Optional[L4Output]:
    """L3Output + Purpose Distribution → L4Output.

    BLOCK 스킵: l3_output.status == "BLOCKED" → return None.
    Empty distribution → default P.CASUAL.
    """
    if l3_output.status == "BLOCKED":
        return None

    if not purpose_distribution:
        purpose_distribution = {_DEFAULT_PURPOSE: 1.0}

    total_turns = sum(purpose_distribution.values())
    if total_turns <= 0:
        purpose_distribution = {_DEFAULT_PURPOSE: 1.0}
        total_turns = 1.0

    # ─── Weighted Expectation — PART 4 §3.3 ───
    weighted_expectation: dict[str, float] = {}
    for axis in _INTENSITY_KEYS:
        w_exp = 0.0
        for purpose, turns in sorted(purpose_distribution.items()):
            weight = turns / total_turns
            pcr = PCR_EXPECTATIONS.get(purpose)
            if pcr and axis in pcr:
                w_exp += weight * pcr[axis]
        weighted_expectation[axis] = w_exp

    # ─── Delta & Bias — PART 4 §3.3 ───
    delta: dict[str, float] = {}
    bias: dict[str, float] = {}

    axes = l3_output.intensity_axes or {}
    for axis in _INTENSITY_KEYS:
        ax = axes.get(axis)
        observed = ax.score if ax else 0.0
        expected = weighted_expectation.get(axis, 0.0)
        delta[axis] = abs(observed - expected)
        bias[axis] = observed - expected

    # ─── ADP — PART 4 §3.4 ───
    delta_values = [delta[k] for k in _INTENSITY_KEYS]
    adp = 1.0 - (sum(delta_values) / len(delta_values)) if delta_values else 0.0
    adp = max(0.0, min(1.0, adp))

    # ─── Per-purpose profile ───
    per_purpose: dict[str, dict] = {}
    for purpose in sorted(purpose_distribution.keys()):
        pcr = PCR_EXPECTATIONS.get(purpose)
        if not pcr:
            continue
        p_delta: dict[str, float] = {}
        p_bias: dict[str, float] = {}
        for axis in _INTENSITY_KEYS:
            ax = axes.get(axis)
            observed = ax.score if ax else 0.0
            expected = pcr.get(axis, 0.0)
            p_delta[axis] = abs(observed - expected)
            p_bias[axis] = observed - expected
        per_purpose[purpose] = {"delta": p_delta, "bias": p_bias}

    return L4Output(
        session_id=session_id,
        purpose_distribution=dict(sorted(purpose_distribution.items())),
        weighted_expectation=weighted_expectation,
        delta=delta,
        bias=bias,
        adp=adp,
        per_purpose_profile=per_purpose,
    )
