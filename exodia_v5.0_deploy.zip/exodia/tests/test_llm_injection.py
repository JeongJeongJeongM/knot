"""P0-2: LLM 클라이언트 주입 테스트."""
from exodia.api.pipeline import ExodiaPipeline
from exodia.models.inputs import ConversationSession, RawTurn, TurnMetadata


def _make_session(n_turns: int = 15) -> ConversationSession:
    turns = [
        RawTurn(
            turn_id=f"t{i}",
            raw_text=f"안녕하세요 테스트 메시지 {i}",
            metadata=TurnMetadata(speaker="user" if i % 2 == 0 else "partner"),
        )
        for i in range(n_turns)
    ]
    return ConversationSession(session_id="s1", user_id="u1", turns=turns)


def test_pipeline_without_llm():
    """LLM 없으면 UNKNOWN 반환 확인."""
    pipe = ExodiaPipeline(llm_client=None)
    result = pipe.run_session(_make_session())
    assert not hasattr(result, "error_code"), f"Expected Profile, got EngineError: {result}"
