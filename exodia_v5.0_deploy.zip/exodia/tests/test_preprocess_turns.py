"""P0-1: speaker 필터 + 턴 트렁케이트 테스트."""
from exodia.api.pipeline import _preprocess_turns
from exodia.models.inputs import ConversationSession, RawTurn, TurnMetadata


def _make_turn(turn_id: str, speaker: str = "user") -> RawTurn:
    return RawTurn(
        turn_id=turn_id,
        raw_text=f"text_{turn_id}",
        metadata=TurnMetadata(speaker=speaker),
    )


def test_speaker_filter():
    """E-05: VALID_SPEAKERS 외 턴이 제거되는지 확인."""
    session = ConversationSession(
        session_id="s1",
        user_id="u1",
        turns=[
            _make_turn("t1", "user"),
            _make_turn("t2", "system"),
            _make_turn("t3", "partner"),
            _make_turn("t4", "metadata"),
            _make_turn("t5", "user"),
        ],
    )
    result = _preprocess_turns(session)
    assert len(result) == 3
    speakers = [t.metadata.speaker for t in result]
    assert speakers == ["user", "partner", "user"]


def test_turn_truncate():
    """E-04: 1000턴 초과 시 최근 1000턴만 유지."""
    turns = [_make_turn(f"t{i}", "user") for i in range(1500)]
    session = ConversationSession(session_id="s2", user_id="u2", turns=turns)
    result = _preprocess_turns(session)
    assert len(result) == 1000
    assert result[0].turn_id == "t500"
    assert result[-1].turn_id == "t1499"


def test_turn_count_uses_filtered():
    """turn_count가 필터 후 기준인지 확인."""
    turns = [_make_turn(f"t{i}", "user") for i in range(20)]
    turns += [_make_turn(f"sys{i}", "system") for i in range(5)]
    session = ConversationSession(session_id="s3", user_id="u3", turns=turns)
    result = _preprocess_turns(session)
    assert len(result) == 20
