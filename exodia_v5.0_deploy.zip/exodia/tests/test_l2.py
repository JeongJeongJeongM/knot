"""L2 테스트. — EXODIA Prompts Phase 5 + P2-1 엣지 케이스"""
import pytest
from exodia.layers.l2 import L2Processor
from exodia.schemas import L1Output, MentionFlags
from exodia.config import K, LABEL_ID_TO_NAME, MAX_TURNS_PER_SESSION


def _make_l1(primary_id, confidence, direction="neutral"):
    """테스트용 L1Output 헬퍼."""
    return L1Output(
        turn_id="t", primary_id=primary_id,
        primary_label=LABEL_ID_TO_NAME.get(primary_id, "UNKNOWN"),
        confidence=confidence, direction=direction,
        mention_flags=MentionFlags(),
        input_hash="h", model_id="m", prompt_hash="p",
    )


class TestL2Processor:
    def test_empty_inputs(self, l2):
        result = l2.process("s1", [])
        assert result.metrics.total_turns == 0

    def test_normal_inputs(self, l2, sample_l1_outputs):
        result = l2.process("s1", sample_l1_outputs)
        assert result.metrics.total_turns == 20
        assert result.metrics.valid_turns > 0

    def test_transition_matrix_shape(self, l2, sample_l1_outputs):
        result = l2.process("s1", sample_l1_outputs)
        assert len(result.transition.counts_dense) == K
        assert len(result.transition.counts_dense[0]) == K
        assert len(result.transition.probs_dense) == K

    def test_transition_row_sum(self, l2, sample_l1_outputs):
        """전이확률 행 합 = 1.0 ± epsilon."""
        result = l2.process("s1", sample_l1_outputs)
        for row in result.transition.probs_dense:
            assert abs(sum(row) - 1.0) < 1e-9

    def test_unknown_excluded(self, l2):
        """UNKNOWN 포함 L1 → 전이에서 제외."""
        outputs = [
            L1Output(turn_id=f"t{i}", primary_id=0 if i % 3 == 0 else 200,
                     confidence=0.8, direction="neutral",
                     mention_flags=MentionFlags(), input_hash=f"h{i}",
                     model_id="m", prompt_hash="p")
            for i in range(10)
        ]
        result = l2.process("s1", outputs)
        assert result.transition.qc.unknown_turns > 0

    def test_low_confidence_skipped(self, l2):
        """confidence < 0.6 → skipped."""
        # L1Output schema allows only 1.0/0.8/0.6; use model_construct for test
        outputs = [
            L1Output.model_construct(
                turn_id=f"t{i}", primary_id=200, primary_label="AGREE",
                confidence=0.6 if i % 2 == 0 else 0.3, direction="neutral",
                mention_flags=MentionFlags(), input_hash=f"h{i}",
                model_id="m", prompt_hash="p",
            )
            for i in range(10)
        ]
        result = l2.process("s1", outputs)
        assert result.transition.qc.low_conf_turn_rate > 0

    def test_determinism(self, l2, sample_l1_outputs):
        """결정론 100회."""
        results = [l2.process("s1", sample_l1_outputs) for _ in range(100)]
        first = results[0]
        for r in results[1:]:
            assert r.transition.self_loop_all == first.transition.self_loop_all
            assert r.metrics.interest_rate == first.metrics.interest_rate

    # ═══ P2-1 추가 테스트 ═══

    def test_l2_all_unknown(self, l2):
        """모든 턴이 UNKNOWN일 때."""
        outputs = [_make_l1(primary_id=0, confidence=1.0) for _ in range(10)]
        result = l2.process("sess_unknown", outputs)
        assert result.transition.effective_transitions == 0
        assert result.transition.qc.no_transition is True

    def test_l2_single_turn(self, l2):
        """1턴 세션."""
        outputs = [_make_l1(primary_id=200, confidence=0.8)]
        result = l2.process("sess_1", outputs)
        assert result.metrics.total_turns == 1
        assert result.transition.effective_transitions == 0

    def test_l2_max_turns_truncation(self, l2):
        """MAX_TURNS 초과 시 절단."""
        outputs = [_make_l1(primary_id=200, confidence=0.8) for _ in range(1500)]
        result = l2.process("sess_long", outputs)
        assert result.metrics.total_turns == MAX_TURNS_PER_SESSION
        assert result.transition.qc.truncated is True

    def test_l2_determinism_100(self, l2, sample_l1_outputs):
        """결정론: 100회 반복 동일 출력."""
        first = l2.process("det", sample_l1_outputs)
        for _ in range(99):
            result = l2.process("det", sample_l1_outputs)
            assert result.transition.entropy_raw == first.transition.entropy_raw
            assert result.transition.self_loop_all == first.transition.self_loop_all
            assert result.metrics.interest_rate == first.metrics.interest_rate

    def test_l2_low_confidence_filter(self, l2):
        """confidence < 0.6 턴은 전이에서 제외."""
        # model_construct for confidence=0.5 (schema allows only 1.0/0.8/0.6)
        low = L1Output.model_construct(
            turn_id="t1", primary_id=303, primary_label="EMPATHY",
            confidence=0.5, direction="neutral", mention_flags=MentionFlags(),
            input_hash="h1", model_id="m", prompt_hash="p",
        )
        outputs = [
            _make_l1(primary_id=200, confidence=0.8),
            low,
            _make_l1(primary_id=300, confidence=0.8),
        ]
        result = l2.process("sess_conf", outputs)
        assert result.transition.qc.skipped_transition_rate > 0
