"""P1-2: Stanza가 런타임 download()를 호출하지 않는지 확인."""
import exodia.kernel.l1_syntax as mod


def test_stanza_no_download_call(monkeypatch):
    """_get_stanza()가 stanza.download()를 호출하지 않는지 확인."""
    mod._stanza_checked = False
    mod._stanza_pipeline = None

    download_called = []

    def mock_download(*args, **kwargs):
        download_called.append(True)

    try:
        import stanza
        monkeypatch.setattr(stanza, "download", mock_download)
    except ImportError:
        pass

    mod._get_stanza()
    assert len(download_called) == 0, "stanza.download() was called at runtime"
