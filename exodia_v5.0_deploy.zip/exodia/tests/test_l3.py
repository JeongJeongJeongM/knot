"""L3 테스트. — EXODIA Prompts Phase 7 + P2-2 테스트 보강"""
import pytest
from exodia.layers.l2 import L2Processor
from exodia.layers.l3 import L3Synthesizer
from exodia.schemas import L2Output, L2Metrics, TransitionData, TimeseriesData


class TestL3Synthesizer:
    def test_all_zero(self, l_):
        """L2 전부 0 → L3 전부 0."""
        l2 = L2Output(session_id="s1")
        result = l3.process(l2)
        for key, axis in result.intensity_axes.items():
            assert 0.0 <= axis.score <= 1.0

    def test_range_check(self, l_):
        """모든 축 0.0~1.0 범위."""
        l2 = L2Output(
            session_id="s1",
            metrics=L2Metrics(
                interest_rate=0.5, sharing_rate=0.3, empathy_rate=0.4,
                feedback_pos_rate=0.2, disinterest_rate=0.1,
                task_assign_rate=0.15, feedback_neg_rate=0.1,
                boundary_rate=0.05, availability_rate=0.1,
                hostile_rate=0.05, distress_rate=0.05,
                status_update_rate=0.1, total_turns=50, valid_turns=45,
            ),
            transition=TransitionData(self_loop_all=0.3),
            timeseries=TimeseriesData(
                volatility=0.2, change_point_count=2, turn_count=50
            ),
        )
        result = l3.process(l2)
        for key, axis in result.intensity_axes.items():
            assert 0.0 <= axis.score <= 1.0, f"{key} score out of range: {axis.score}"
        for key, axis in result.structural_axes.items():
            total_mix = sum(axis.mix.values())
            assert abs(total_mix - 1.0) < 1e-6, f"{key} mix sum: {total_mix}"

    def test_determinism(self, l_):
        """결정론 100회."""
        l2 = L2Output(
            session_id="s1",
            metrics=L2Metrics(
                interest_rate=0.3, sharing_rate=0.2, empathy_rate=0.3,
                total_turns=30, valid_turns=28,
            ),
            transition=TransitionData(self_loop_all=0.2),
            timeseries=TimeseriesData(turn_count=30),
        )
        results = [l3.process(l2) for _ in range(100)]
        first = results[0]
        for r in results[1:]:
            for key in first.intensity_axes:
                assert r.intensity_axes[key].score == first.intensity_axes[key].score

    # ═══ P2-2 추가 테스트 ═══

    def test_l3_all_zero_metrics(self, l_):
        """메트릭 모두 0일 때 축 점수 [0,1] 범위."""
        l2 = L2Output(session_id="zero", metrics=L2Metrics(total_turns=30, valid_turns=30))
        result = l3.process(l2)
        for key, axis in result.intensity_axes.items():
            assert 0.0 <= axis.score <= 1.0, f"{key} out of range"
        for key, axis in result.structural_axes.items():
            assert sum(axis.mix.values()) > 0.99, f"{key} mix sum != 1"

    def test_l3_insufficient_turns(self, l_):
        """턴 부족 → insufficient."""
        l2 = L2Output(session_id="few", metrics=L2Metrics(total_turns=5, valid_turns=5))
        result = l3.process(l2)
        for axis in result.intensity_axes.values():
            assert axis.level == "insufficient"

    def test_l3_determinism_100(self, l_, sample_l1_outputs):
        """결정론: 100회."""
        l2_out = L2Processor().process("det", sample_l1_outputs)
        first = l3.process(l2_out)
        for _ in range(99):
            result = l3.process(l2_out)
            for key in first.intensity_axes:
                assert result.intensity_axes[key].score == first.intensity_axes[key].score
