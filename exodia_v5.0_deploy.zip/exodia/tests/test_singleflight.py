"""P1-1: SingleFlight timeout 제거 — follower가 leader 완료까지 대기."""
import threading
import time

from exodia.labeling.l25_worker import SingleFlightGroup


def test_singleflight_waits_for_leader():
    """follower가 leader 완료까지 대기하고 동일 결과를 받는지 확인."""
    sfg = SingleFlightGroup()
    results: list = []

    def slow_fn():
        time.sleep(0.3)
        return "done"

    def run(idx: int):
        r = sfg.do("key1", slow_fn)
        results.append((idx, r))

    t1 = threading.Thread(target=run, args=(1,))
    t2 = threading.Thread(target=run, args=(2,))
    t1.start()
    time.sleep(0.05)
    t2.start()
    t1.join(timeout=5)
    t2.join(timeout=5)

    assert len(results) == 2
    assert all(r == "done" for _, r in results)
