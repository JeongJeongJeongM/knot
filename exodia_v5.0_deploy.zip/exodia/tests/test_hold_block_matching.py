"""P1-3: HOLD/BLOCK 프로파일 L6 매칭 차단 테스트."""
import pytest

from exodia.comparison.l6_compare import MatchingBlockedError, compute_l5_comparison
from exodia.models.outputs import (
    ConsistencyOutput,
    IntegrityOutput,
    L2Output,
    L3Output,
    L4Output,
    Profile,
    RiskReport,
    UserProfile,
)


def _make_profile(action: str = "ALLOW", user_id: str = "u1") -> Profile:
    return Profile(
        session_id="s1",
        user_id=user_id,
        l2=L2Output(session_id="s1"),
        l3=L3Output(session_id="s1"),
        l4=L4Output(session_id="s1"),
        integrity=IntegrityOutput(trust_level="TRUSTED"),
        risk_report=RiskReport(action=action),
    )


def _make_user_profile(action: str = "ALLOW", user_id: str = "u1") -> UserProfile:
    return UserProfile(
        user_id=user_id,
        l3=L3Output(session_id="s1"),
        l4=L4Output(session_id="s1"),
        integrity=IntegrityOutput(trust_level="TRUSTED"),
        consistency=ConsistencyOutput(user_id=user_id, status="COMPUTED", risk_level="LOW"),
    )


def test_hold_profile_blocked():
    """HOLD 프로파일은 L6 매칭에서 거부."""
    a = _make_profile(action="HOLD", user_id="u1")
    b = _make_user_profile(user_id="u2")
    with pytest.raises(MatchingBlockedError, match="HELD"):
        compute_l5_comparison(a, b)


def test_block_profile_blocked():
    """BLOCK 프로파일도 L6 매칭에서 거부."""
    a = _make_profile(action="BLOCK", user_id="u1")
    b = _make_user_profile(user_id="u2")
    with pytest.raises(MatchingBlockedError, match="BLOCKED"):
        compute_l5_comparison(a, b)


def test_allow_profile_passes_action_check():
    """ALLOW 프로파일은 action contract를 통과 (후속 gate에서 걸릴 수 있음)."""
    a = _make_profile(action="ALLOW", user_id="u1")
    b = _make_user_profile(user_id="u2")
    try:
        compute_l5_comparison(a, b)
    except MatchingBlockedError as e:
        assert "HELD" not in str(e) and "BLOCKED" not in str(e)
