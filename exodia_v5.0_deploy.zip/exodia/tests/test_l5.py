"""L5 테스트. — EXODIA Prompts Phase 10"""
import pytest
from exodia.layers.l5 import L5Comparator
from exodia.schemas import (
    ConsistencyOutput, IntegrityOutput, IntensityAxis, L3Output, L4Output,
    StructuralAxis, UserProfile,
)


def _make_user_profile(user_id: str, a1: float = 0.5,
                        a7_style: str = 'balanced',
                        status: str = 'PROFILED') -> UserProfile:
    return UserProfile(
        user_id=user_id,
        l3=L3Output(
            intensity_axes={
                f"A{i}": IntensityAxis(score=a1, level='medium', confidence=0.8)
                for i in range(1, 7)
            },
            structural_axes={
                "A7": StructuralAxis(style=a7_style, mix={a7_style: 0.7, 'balanced': 0.3}, confidence=0.8),
                "A8": StructuralAxis(style='repair', mix={'repair': 0.6, 'boundary': 0.4}, confidence=0.8),
                "A9": StructuralAxis(style='analytical', mix={'analytical': 0.7, 'suppressive': 0.3}, confidence=0.8),
                "A10": StructuralAxis(style='slow_burn', mix={'slow_burn': 0.8, 'surface_locked': 0.2}, confidence=0.8),
                "A11": StructuralAxis(style='balanced', mix={'balanced': 0.6, 'giver': 0.4}, confidence=0.8),
            },
        ),
        l4=L4Output(
            bias={f"A{i}": 0.0 for i in range(1, 7)},
            delta={f"A{i}": 0.0 for i in range(1, 7)},
        ),
        integrity=IntegrityOutput(trust_score=0.9, trust_level='TRUSTED'),
        consistency=ConsistencyOutput(
            user_id=user_id, session_count=5, status='COMPUTED',
            c1_pvi=0.1, risk_level='LOW', risk_score=0.1,
        ),
        session_count=5,
        status=status,
    )


class TestL5Comparator:
    def test_identical_profiles(self, l5):
        """동일 프로파일 → friction ≈ 0."""
        a = _make_user_profile("a")
        b = _make_user_profile("b")
        result = l5.compare(a, b)
        assert not result.blocked
        assert result.friction_total < 0.3

    def test_opposite_profiles(self, l5):
        """정반대 프로파일 → friction 높음."""
        a = _make_user_profile("a", a1=0.9, a7_style='initiator')
        b = _make_user_profile("b", a1=0.1, a7_style='responder')
        # bias를 반대로 설정
        a.l4.bias = {f"A{i}": 0.4 for i in range(1, 7)}
        b.l4.bias = {f"A{i}": -0.4 for i in range(1, 7)}
        result = l5.compare(a, b)
        assert not result.blocked
        assert result.friction_total > 0

    def test_unstable_blocked(self, l5):
        """risk_level=HIGH → blocked."""
        a = _make_user_profile("a")
        b = _make_user_profile("b")
        b.consistency.risk_level = 'HIGH'
        result = l5.compare(a, b)
        assert result.blocked
        assert "risk_level" in result.block_reason

    def test_untrusted_blocked(self, l5):
        """trust_level=UNTRUSTED → blocked."""
        a = _make_user_profile("a")
        b = _make_user_profile("b")
        b.integrity.trust_level = 'UNTRUSTED'
        result = l5.compare(a, b)
        assert result.blocked

    def test_stability_bonus(self, l5):
        """둘 다 안정 → stability_bonus 가산."""
        a = _make_user_profile("a")
        b = _make_user_profile("b")
        result = l5.compare(a, b)
        assert result.stability_bonus >= 0
        assert result.final_score >= result.compatibility
