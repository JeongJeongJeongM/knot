"""L4 테스트. — EXODIA Prompts Phase 9"""
import pytest
from exodia.layers.l4 import L4Projector
from exodia.schemas import IntensityAxis, L3Output


class TestL4Projector:
    def test_default_purpose(self, l4):
        """Purpose 미지정 → P.CASUAL 기본."""
        l3 = L3Output(intensity_axes={
            "A1": IntensityAxis(score=0.5, level='medium', confidence=0.8),
            "A2": IntensityAxis(score=0.5, level='medium', confidence=0.8),
            "A3": IntensityAxis(score=0.5, level='medium', confidence=0.8),
            "A4": IntensityAxis(score=0.5, level='medium', confidence=0.8),
            "A5": IntensityAxis(score=0.5, level='medium', confidence=0.8),
            "A6": IntensityAxis(score=0.5, level='medium', confidence=0.8),
        })
        result = l4.process(l3)
        assert "P.CASUAL" in result.purpose_distribution
        assert 0.0 <= result.adp <= 1.0

    def test_delta_bias(self, l4):
        l3 = L3Output(intensity_axes={
            "A1": IntensityAxis(score=0.8, level='high', confidence=0.9),
            "A2": IntensityAxis(score=0.3, level='low', confidence=0.9),
            "A3": IntensityAxis(score=0.5, level='medium', confidence=0.9),
            "A4": IntensityAxis(score=0.5, level='medium', confidence=0.9),
            "A5": IntensityAxis(score=0.5, level='medium', confidence=0.9),
            "A6": IntensityAxis(score=0.5, level='medium', confidence=0.9),
        })
        result = l4.process(l3, {"P.CASUAL": 1.0})
        # A1: 0.8 - 0.50 = +0.30
        assert result.bias["A1"] == pytest.approx(0.30, abs=0.01)
        # A2: 0.3 - 0.60 = -0.30
        assert result.bias["A2"] == pytest.approx(-0.30, abs=0.01)
