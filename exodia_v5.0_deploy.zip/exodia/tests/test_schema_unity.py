"""schemas.py re-export 정합성 테스트."""
import pytest


class TestSchemaUnity:
    """schemas.py가 models/outputs.py의 re-export인지 검증."""

    def test_l3output_is_same_class(self):
        from exodia.schemas import L3Output as SchemaL3
        from exodia.models.outputs import L3Output as ModelL3
        assert SchemaL3 is ModelL3, "schemas.L3Output must be models.outputs.L3Output"

    def test_l0output_is_l0norm_alias(self):
        from exodia.schemas import L0Output, L0NormOutput
        assert L0Output is L0NormOutput, "L0Output must be alias of L0NormOutput"

    def test_l3output_has_cross_validation(self):
        from exodia.schemas import L3Output
        fields = L3Output.model_fields
        assert "cross_validation" in fields, "L3Output must have cross_validation"
        assert "metadata" in fields, "L3Output must have metadata"
        assert "status" in fields, "L3Output must have status"

    def test_blocked_invariant(self):
        from exodia.schemas import L3Output
        blocked = L3Output(session_id="test", status="BLOCKED")
        assert blocked.intensity_axes is None
        assert blocked.structural_axes is None
        assert blocked.cross_validation is None

    def test_profile_l4_optional(self):
        from exodia.models.outputs import Profile, L2Output, L3Output, IntegrityOutput
        p = Profile(
            session_id="t",
            user_id="u",
            l2=L2Output(session_id="t"),
            l3=L3Output(session_id="t", status="BLOCKED"),
            l4=None,
            integrity=IntegrityOutput(),
        )
        assert p.l4 is None

    def test_all_schemas_importable(self):
        """schemas.py의 모든 re-export가 깨지지 않는지 확인."""
        from exodia import schemas
        required = [
            "L0Output",
            "L0NormOutput",
            "L1Output",
            "L2Output",
            "L3Output",
            "L4Output",
            "L5Output",
            "Profile",
            "ConversationSession",
            "RawTurn",
            "TurnMetadata",
            "EngineError",
            "RiskReport",
            "IntegrityOutput",
            "NLPAggregate",
            "MentionFlags",
            "SurfaceFeatures",
        ]
        for name in required:
            assert hasattr(schemas, name), f"schemas.py missing: {name}"
