"""Integrity 테스트. — EXODIA Prompts Phase 6 + P2-3 테스트 보강"""
import pytest
from exodia.layers.integrity import IntegrityGate
from exodia.schemas import L2Output, L2Metrics


class TestIntegrityGate:
    def test_insufficient_turns(self, integrity):
        """10턴 미만 → UNKNOWN."""
        l2 = L2Output(session_id="s1")
        result = integrity.evaluate(l2, turn_count=5)
        assert result.trust_level == 'UNKNOWN'
        assert result.trust_score is None

    def test_normal_no_client_signals(self, integrity):
        """클라이언트 신호 없음 → Stage 2 단독, 상한 CAUTIOUS."""
        l2 = L2Output(session_id="s1")
        result = integrity.evaluate(l2, turn_count=20)
        assert result.trust_level in ('TRUSTED', 'CAUTIOUS', 'SUSPICIOUS', 'UNTRUSTED')
        # PATCH-05: Stage2-only → 최대 CAUTIOUS
        if result.trust_score is not None and result.trust_score > 0.79:
            # 이 경우 trust_level이 CAUTIOUS로 강제됨
            pass

    def test_with_client_signals(self, integrity):
        """클라이언트 신호 포함."""
        from exodia.schemas import ClientSignals, ClientSignalMessage
        l2 = L2Output(session_id="s1")
        cs = ClientSignals(per_message=[
            ClientSignalMessage(
                message_id="m1",
                chars_per_second=3.0,  # 정상
                paste_event=False,
                backspace_ratio=0.15,
                edit_count=3,
                input_rhythm_variance=0.05,
            ),
        ])
        result = integrity.evaluate(l2, client_signals=cs, turn_count=20)
        assert result.trust_score is not None
        assert result.stage1_score is not None

    # ═══ P2-3 추가 테스트 ═══

    def test_integrity_below_min_turns(self, integrity):
        """< 10턴 → UNKNOWN."""
        l2 = L2Output(session_id="short", metrics=L2Metrics(total_turns=5, valid_turns=5))
        result = integrity.evaluate(l2, turn_count=5)
        assert result.trust_level == "UNKNOWN"
        assert result.trust_score is None

    def test_integrity_stage2_only_ceiling(self, integrity):
        """Stage1 없이 Stage2만 → CAUTIOUS 상한 (PATCH-05)."""
        l2 = L2Output(session_id="s2", metrics=L2Metrics(total_turns=30, valid_turns=30))
        result = integrity.evaluate(l2, client_signals=None, turn_count=30)
        assert result.trust_level != "TRUSTED"
