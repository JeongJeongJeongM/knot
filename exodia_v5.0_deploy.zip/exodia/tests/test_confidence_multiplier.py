"""P0-3: confidence_multiplier가 axis_confidence에 곱해지는지 확인."""
from exodia.models.outputs import L2Output, L2Metrics, NLPAggregate, RiskReport
from exodia.synthesis.l4_synthesis import compute_l3_synthesis


def _make_l2() -> L2Output:
    return L2Output(
        session_id="s1",
        metrics=L2Metrics(
            interest_rate=0.3,
            sharing_rate=0.2,
            empathy_rate=0.25,
            feedback_pos_rate=0.15,
            disinterest_rate=0.05,
            task_assign_rate=0.1,
            feedback_neg_rate=0.05,
            boundary_rate=0.02,
            availability_rate=0.1,
            hostile_rate=0.01,
            distress_rate=0.02,
            status_update_rate=0.1,
            smalltalk_rate=0.1,
        ),
    )


def test_confidence_multiplier_applied():
    """multiplier=0.5 → axis_conf가 multiplier=1.0 대비 절반."""
    l2 = _make_l2()
    nlp = NLPAggregate()

    r_full = RiskReport(confidence_multiplier=1.0)
    r_half = RiskReport(confidence_multiplier=0.5)

    out_full = compute_l3_synthesis("s1", l2, nlp, r_full, turn_count=50)
    out_half = compute_l3_synthesis("s1", l2, nlp, r_half, turn_count=50)

    for key in out_full.intensity_axes:
        cf = out_full.intensity_axes[key].confidence
        ch = out_half.intensity_axes[key].confidence
        if cf > 0:
            assert abs(ch - cf * 0.5) < 1e-9, f"{key}: {ch} != {cf} * 0.5"


def test_confidence_multiplier_one():
    """multiplier=1.0이면 변화 없음."""
    l2 = _make_l2()
    r1 = RiskReport(confidence_multiplier=1.0)

    out1 = compute_l3_synthesis("s1", l2, None, r1, turn_count=50)
    out2 = compute_l3_synthesis("s1", l2, None, r1, turn_count=50)

    for key in out1.intensity_axes:
        assert out1.intensity_axes[key].confidence == out2.intensity_axes[key].confidence
