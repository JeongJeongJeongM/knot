"""EXODIA 테스트 공용 fixture."""
import warnings

import pytest

# 레거시 layers 테스트용 DeprecationWarning 무시
warnings.filterwarnings("ignore", message="exodia.layers is deprecated", category=DeprecationWarning)

from exodia.layers.l1 import MockProvider, L1Processor
from exodia.layers.l0 import L0Processor
from exodia.layers.l2 import L2Processor
from exodia.layers.l3 import L3Synthesizer
from exodia.layers.l3_5 import L35Processor
from exodia.layers.l4 import L4Projector
from exodia.layers.l5 import L5Comparator
from exodia.layers.integrity import IntegrityGate
from exodia.pipeline import ExodiaPipeline
from exodia.schemas import (
    ConversationSession,
    L0Output,
    L1Output,
    MentionFlags,
    RawTurn,
    SurfaceFeatures,
    TurnMetadata,
)


@pytest.fixture
def l0():
    return L0Processor()


@pytest.fixture
def mock_provider():
    return MockProvider(fixed_response={
        "p": 200, "s": None, "c": 0.8,
        "e": "맞아", "d": "NEUTRAL", "v": 0
    })


@pytest.fixture
def l1(mock_provider):
    return L1Processor(provider=mock_provider)


@pytest.fixture
def l2():
    return L2Processor()


@pytest.fixture
def l3():
    return L3Synthesizer()


@pytest.fixture
def l3_5():
    return L35Processor()


@pytest.fixture
def l4():
    return L4Projector()


@pytest.fixture
def l5():
    return L5Comparator()


@pytest.fixture
def integrity():
    return IntegrityGate()


@pytest.fixture
def pipeline(mock_provider):
    return ExodiaPipeline(llm_provider=mock_provider)


@pytest.fixture
def sample_session():
    """샘플 대화 세션 (20턴)."""
    turns = []
    texts = [
        "안녕하세요?",
        "오늘 날씨 좋다",
        "맞아 진짜 좋네",
        "뭐 먹었어?",
        "나는 김치찌개 먹었어",
        "오 맛있겠다 더 얘기해봐",
        "고마워",
        "해줘 이거",
        "ㅇㅇ 할게",
        "ㅋㅋㅋ",
        "힘들었겠다",
        "그건 아닌 것 같아",
        "확인했어",
        "이렇게 하면 어때?",
        "좋은 생각이야",
        "내가 잘못했지",
        "괜찮아",
        "시간 돼?",
        "진행 중이야",
        "잘 가",
    ]
    for i, text in enumerate(texts):
        turns.append(RawTurn(
            turn_id=f"turn_{i}",
            raw_text=text,
            metadata=TurnMetadata(speaker="user"),
        ))
    return ConversationSession(
        session_id="test_session_001",
        user_id="test_user",
        turns=turns,
    )


@pytest.fixture
def sample_l1_outputs():
    """샘플 L1 출력 리스트 (20개)."""
    labels = [
        (120, "GREET_OPEN", 0.8, "neutral"),
        (302, "SMALL_TALK", 0.8, "neutral"),
        (200, "AGREE", 0.8, "neutral"),
        (140, "QUESTION_FACT", 0.8, "other"),
        (303, "SHARE_PERSONAL", 0.8, "self"),
        (300, "INTEREST_SIGNAL", 0.8, "other"),
        (122, "THANKS", 0.8, "other"),
        (160, "REQUEST_ACTION", 0.8, "other"),
        (205, "COMMIT", 0.8, "self"),
        (226, "LAUGHTER_MARKER", 0.8, "neutral"),
        (304, "EMPATHY", 0.8, "other"),
        (201, "DISAGREE", 0.8, "other"),
        (203, "ACKNOWLEDGE", 0.8, "neutral"),
        (180, "SUGGESTION", 0.8, "neutral"),
        (305, "FEEDBACK_POSITIVE", 0.8, "other"),
        (240, "SELF_REPAIR", 0.8, "self"),
        (125, "APOLOGY_RESPONSE", 0.8, "other"),
        (309, "AVAILABILITY_CHECK", 0.8, "other"),
        (308, "STATUS_UPDATE", 0.8, "self"),
        (121, "GREET_CLOSE", 0.8, "neutral"),
    ]
    outputs = []
    for i, (pid, pname, conf, direction) in enumerate(labels):
        outputs.append(L1Output(
            turn_id=f"turn_{i}",
            primary_id=pid,
            primary_label=pname,
            confidence=conf,
            direction=direction,
            mention_flags=MentionFlags(),
            input_hash=f"hash_{i}",
            model_id="mock",
            prompt_hash="mock_hash",
        ))
    return outputs
