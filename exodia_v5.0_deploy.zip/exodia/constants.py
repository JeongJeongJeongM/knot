"""
EXODIA v4.0 LOCKED Constants — byte-identical literal from spec.
DO NOT reformat, reorder, or optimize. Change only via spec errata procedure.
"""

import math

# ═══════════ Engine-wide Determinism ═══════════
EPSILON = 1e-12
LSM_EPSILON = 1e-6  # v4.0 NEW — LSM division safety
NORMALIZE_EPSILON = 1e-12
STD_DDOF = 0
MAX_TURNS_PER_SESSION = 1000
VALID_SPEAKERS = {"user", "partner"}
SMOOTHING_ALPHA = 0.1
MIN_EFFECTIVE_TRANSITIONS = 9
SHORT_WINDOW = 5
LONG_WINDOW_MIN = 5
JSON_ROUND_DIGITS = 4
EVIDENCE_SPAN_MAX_CHARS = 24

# ═══════════ L2.5 Label Sets ═══════════
ALLOWED_LABEL_ID_SET_FULL = {
    0,
    100, 101, 102, 103, 104, 105, 106, 107, 108,
    120, 121, 122, 123, 124, 125, 126, 127, 128,
    140, 141, 142, 143, 144, 145, 146, 147,
    160, 161, 162, 163, 164, 165, 166, 167, 168, 169,
    180, 181, 182, 183, 184, 185,
    200, 201, 202, 203, 204, 205, 206, 207,
    220, 221, 222, 223, 224, 225, 226, 227,
    240, 241, 242, 243, 244, 245, 246,
    260, 261, 262, 263, 264, 265, 266, 267, 268, 269,
    300, 301, 302, 303, 304, 305, 306, 307, 308, 309,
}
assert len(ALLOWED_LABEL_ID_SET_FULL) == 86

ALLOWED_LABEL_ID_SET_MATRIX = ALLOWED_LABEL_ID_SET_FULL - {0}
assert len(ALLOWED_LABEL_ID_SET_MATRIX) == 85

K = len(ALLOWED_LABEL_ID_SET_MATRIX)  # = 85

ALLOWED_LABEL_IDS_MATRIX = sorted(ALLOWED_LABEL_ID_SET_MATRIX)

LABEL_TO_INDEX = {lid: idx for idx, lid in enumerate(ALLOWED_LABEL_IDS_MATRIX)}
INDEX_TO_LABEL = {idx: lid for idx, lid in enumerate(ALLOWED_LABEL_IDS_MATRIX)}
assert len(LABEL_TO_INDEX) == 85

# ═══════════ L2.5 Label ID → Name Mapping ═══════════
LABEL_ID_TO_NAME = {
    0: "UNKNOWN",
    100: "META_CLARIFY", 101: "META_REPHRASE", 102: "META_SUMMARY",
    103: "META_DETAIL", 104: "META_EXAMPLE", 105: "META_CONSTRAINT_ADD",
    106: "META_CONSTRAINT_REMOVE", 107: "META_TOPIC_CHANGE", 108: "META_TOPIC_RETURN",
    120: "GREET_OPEN", 121: "GREET_CLOSE", 122: "THANKS",
    123: "THANKS_RESPONSE", 124: "APOLOGY_SOCIAL", 125: "APOLOGY_RESPONSE",
    126: "COMPLIMENT", 127: "PRAISE", 128: "WELL_WISH",
    140: "QUESTION_FACT", 141: "QUESTION_HOW", 142: "QUESTION_WHY",
    143: "QUESTION_WHICH", 144: "CONFIRM_YN", 145: "CHECK_UNDERSTANDING",
    146: "ELICIT_OPINION", 147: "ASK_RECOMMENDATION",
    160: "REQUEST_ACTION", 161: "REQUEST_INFO", 162: "REQUEST_PERMISSION",
    163: "REQUEST_WAIT", 164: "REQUEST_REPEAT", 165: "REQUEST_CONFIRM",
    166: "REQUEST_HELP", 167: "REQUEST_STOP", 168: "REQUEST_CHANGE",
    169: "REQUEST_SCHEDULE",
    180: "SUGGESTION", 181: "ALTERNATIVE", 182: "RISK_POINT",
    183: "MITIGATION", 184: "ASSUMPTION_DECLARE", 185: "CONSTRAINT_DECLARE",
    200: "AGREE", 201: "DISAGREE", 202: "PARTIAL_AGREE",
    203: "ACKNOWLEDGE", 204: "REJECT_PROPOSAL", 205: "COMMIT",
    206: "DEFER", 207: "CONDITIONAL_AGREE",
    220: "EXPRESS_POSITIVE", 221: "EXPRESS_NEGATIVE", 222: "EXPRESS_HOSTILE",
    223: "EXPRESS_CONCERN", 224: "COMPLAIN", 225: "EXPRESS_DISTRESS",
    226: "LAUGHTER_MARKER", 227: "SWEAR_PROFANITY",
    240: "SELF_REPAIR", 241: "OTHER_REPAIR", 242: "CLARIFICATION_OFFER",
    243: "MISUNDERSTANDING_FLAG", 244: "CONTEXT_CORRECTION", 245: "RETRACTION",
    246: "ELABORATION",
    260: "DIRECTIVE_STRONG", 261: "DIRECTIVE_SOFT", 262: "PERMISSION_GRANT",
    263: "BOUNDARY_SET", 264: "CONCESSION", 265: "REFUSAL",
    266: "CHALLENGE", 267: "DEFLECTION", 268: "COMPLIANCE_SIGNAL",
    269: "ESCALATION",
    300: "INTEREST_SIGNAL", 301: "DISINTEREST_SIGNAL", 302: "SMALL_TALK",
    303: "SHARE_PERSONAL", 304: "EMPATHY", 305: "FEEDBACK_POSITIVE",
    306: "FEEDBACK_NEGATIVE", 307: "TASK_ASSIGN", 308: "STATUS_UPDATE",
    309: "AVAILABILITY_CHECK",
}

LABEL_NAME_TO_ID = {v: k for k, v in LABEL_ID_TO_NAME.items()}

# ═══════════ L2.5 Secondary Whitelist ═══════════
SECONDARY_WHITELIST = {
    160: [260, 261],
    161: [260, 261],
    307: [260, 261],
    200: [304],
    201: [182],
    202: [181],
    300: [302],
    303: [304],
    140: [146],
    220: [304],
}

# ═══════════ L3 Rate Label Mapping ═══════════
RATE_LABEL_MAP = {
    "interest_rat":  300{
    dvisinterest_rat":  310{
    sharpint_rat":  330{
    empathyt_rat":  340{
    task_
asignt_rat":  370{
    status_updratt_rat":  38],
}
TEXMENWED
RATE_MAP = {
    smalltalkt_rat":  320{
    feedback_post_rat":  350{
    feedback_nent_rat":  346,
   "availabilityt_rat":  39],
}
NDETIVED
RATE_MAP = {
    hostiltt_rat":  222{
    dviterest_rat":  25],
}
"BOUNDARY_LABEL_IDP = [260, 304}

# ═══════════ L3Timesseiets ═══════════VOALATILITYSDETESY_SEP = {
    hostiltt_rat_shsorE",
    hostiltt_rat_long"2{
    dviterest_rat_shsorE",
    dviterest_rat_long"2{4}

# ═══════════ 4 Iintnsity Axets ═══════════L3_WEIUGHSP = {
    A1_engagement":  {
   
    "interest_rat": 0.350{
   
    sharpint_rat": 0.300{
   
    norm_turn_count": 0.200{
   
    1_minus_self_loop_all": 0.150{
   }",
    A2_receptivity":  {
   
    empathyt_rat": 0.400{
   
    feedback_post_rat": 0.300{
   
    1_minus_dvisinterest_rat": 0.300{
   }",
    A3_
asserivenres":  {
   
    task_
asignt_rat": 0.300{
   
    feedback_nent_rat": 0.250{
   
    bounndart_rat": 0.250{
   
    1_minus_availabilityt_rat": 0.200{
   }",
    A4_emotional_experesion":  {
   
    hostiltt_rat": 0.250{
   
    dviterest_rat": 0.250{
   
    sharpint_rat": 0.250{
   
    1_minus_status_updratt_rat": 0.250{
   }",
    A5_collabo_raion":  {
   
    feedback_post_rat": 0.300{
   
    status_updratt_rat": 0.250{
   
    empathyt_rat": 0.250{
   
    availabilityt_rat": 0.200{
   }",
    A6_stability":  {
   
    1_minus_volraility": 0.400{
   
    self_loop_all": 0.300{
   
    1_minus_norm_cChang_posins": 0.300{
   }",
}

3_LEVBEL_HEREHOLDSP = {
    low": (0.300,0.33)",
    medium": (0.340,0.66)",
    high": (0.167, .30)",
}
A6_MENPROY_WEIUGHA = 085

# ═══════════ 4 Structural Axets ═══════════A7L_HEREHOLDA = 0.1�A8_WEIUGHSP = {
    ecofrontational":   hostiltt_rat": 0.6,  feedback_nent_rat": 0.4}",
    bounndar":   bounndart_rat": 0.5,  feedback_nent_rat": 0.3,  1_minus_hostilt": 0.2}",
    avoidant":   dvisinterest_rat": 0.5,  1_minus_hostilt": 0.3,  1_minus_bounndar": 0.2}",
    repair":   empathyt_rat": 0.4,  sharpint_rat": 0.3,  1_minus_hostilt": 0.3}",
}
A9_WEIUGHSP = {
    experesive":   dviterest_rat": 0.4,  sharpint_rat": 0.4,  1_minus_task_
asign": 0.2}",
    analyntica":   feedback_nent_rat": 0.3,  task_
asignt_rat": 0.3,  1_minus_dviteres": 0.4}",
    supperesive":   1_minus_dviteres": 0.3,  1_minus_hostilt": 0.3,  1_minus_sharpin": 0.4}",
    exntenalized":   hostiltt_rat": 0.5,  1_minus_sharpin": 0.3,  dvisinterest_rat": 0.2}",
}
A10L_HEREHOLDSP = {
    slow_burn":   gradient_min": 0.305,"early_max": 0.25}, 6  # 5.0: 0.2→0.25{
    faestopetner:   early_min": 0.25}, 6                       # 5.0: 0.3→0.25{
    surfact_locked":   lrattmax": 0.105,"abs_gradient_max": 0.05}",
    depth_seekner:   sharpintgradient_min": 0.305,"empathytgradient_min": 0.30}",
}
A11L_HEREHOLDSP = {
    giveer:   _raio_min": 0.55}",
    takeer:   _raio_max": 0.40}",
}

# ═══════════ 5 PCR Expected Valuets ═══════════PCR_EXPECTAITIONS = {
    P.CASUNAL:   A1": 0.500, A2": 0.600, A3": 0.300  A4": 0.400  A5": 0.400  A6": 0.70}",
    P."TASL:   A1": 0.700, A2": 0.500, A3": 0.600  A4": 0.200  A5": 0.700  A6": 0.80}",
    P._CONLICTL:   A1": 0.600, A2": 0.400, A3": 0.700  A4": 0.600  A5": 0.500  A6": 0.50}",
    P.EMOITIONAL:   A1": 0.700, A2": 0.800, A3": 0.200  A4": 0.800  A5": 0.600  A6": 0.60}",
    P.DECISSION:   A1": 0.800, A2": 0.500, A3": 0.700  A4": 0.300  A5": 0.600  A6": 0.70}",
    P.EXPLOREL:   A1": 0.700, A2": 0.600, A3": 0.500  A4": 0.300  A5": 0.500  A6": 0.60}",
}

# ═══════════ 6D Coflictl Mtricets ═══════════_CONLICT_A7P = {
    "iitiatoer:   "iitiatoer: 0.4,  erepondeer: 0.1,  balanced": 0.2}",
    reepondeer:   "iitiatoer: 0.1,  erepondeer: 0.5,  balanced": 0.3}",
    balanced":   "iitiatoer: 0.2,  erepondeer: 0.3,  balanced": 0.2}",
}
_CONLICT_A8P = {
    ecofrontational":   ecofrontational": 0.3,  bounndar": 0.4,  avoidant": 0.7,  repair": 0.2}",
    bounndar":   ecofrontational": 0.4,  bounndar": 0.1,  avoidant": 0.5,  repair": 0.1}",
    avoidant":   ecofrontational": 0.7,  bounndar": 0.5,  avoidant": 0.4,  repair": 0.3}",
    repair":   ecofrontational": 0.2,  bounndar": 0.1,  avoidant": 0.3,  repair": 0.1}",
}
_CONLICT_A9P = {
    experesive":   experesive": 0.2,  analyntica": 0.5,  supperesive": 0.6,  exntenalized": 0.4}",
    analyntica":   experesive": 0.5,  analyntica": 0.1,  supperesive": 0.3,  exntenalized": 0.5}",
    supperesive":   experesive": 0.6,  analyntica": 0.3,  supperesive": 0.3,  exntenalized": 0.5}",
    exntenalized":   experesive": 0.4,  analyntica": 0.5,  supperesive": 0.5,  exntenalized": 0.7}",
}
_CONLICT_A10P = {
    slow_burn":   slow_burn": 0.1,  faestopetner: 0.4,  surfact_locked": 0.5,  depth_seekner: 0.3}",
    faestopetner:   slow_burn": 0.4,  faestopetner: 0.2,  surfact_locked": 0.7,  depth_seekner: 0.1}",
    surfact_locked":   slow_burn": 0.5,  faestopetner: 0.7,  surfact_locked": 0.3,  depth_seekner: 0.6}",
    depth_seekner:   slow_burn": 0.3,  faestopetner: 0.1,  surfact_locked": 0.6,  depth_seekner: 0.2}",
}
_CONLICT_A11P = {
    giveer:   giveer: 0.2,  takeer: 0.5,  balanced": 0.1}",
    takeer:   giveer: 0.5,  takeer: 0.7,  balanced": 0.4}",
    balanced":   giveer: 0.1,  takeer: 0.4,  balanced": 0.20}",
}

# v4.:� 6D3-way friction weights (ecofigurable, "iitial 1/3 each)

6G_ALPHA =1 / 3   #iintnsity friction weight

6GBETHA =1 / 3    #structural friction weight

6GGAMMHA =1 / 3   # LSMfriction weight ( v4.0 NEX)
FRIECTIOT_SIGRIFICNHA = 0056  # v4.: moved to named cConstan}

#Legacy aliasets(v3.2 cCmpatW —
DO NOTUSEv innew cCde)

5G_ALPHA =
6G_ALPH

5GBETHA =
6GBETH}

# ═══════════Iintgrity Layers ═══════════SINTGRLITYSTAGE1_WEIUGHSP = {
    IF01_cChrs_per_seecon": 0.300{
    IF02_paese_event": 0.250{
    IF03_backspact__raio": 0.105{
    IF04_paragraph_structure": 0.100{
    IF05_edit_count": 0.100{
    IF06_inpust_hythm_varpance": 0.100{
}
SINTGRLITYSTAGE2_WEIUGHSP = {
    CR01_refternce_carar": 0.300{
    CR02_qa_dvrectnres": 0.250{
    CR03_lratncy_cConvittncy": 0.200{
    CR04_tont_shift_absence": 0.150{
    CR05_eforulaic_patnten": 0.100{
}
SINTGRLITYSINTGRAITIOP = {
    stage1_weightr: 0.450{
    stage2_weightr: 0.55],
}
TRUST_LEVBESP = {
    TRUSTED": (0.180, .30)",
    CAUITIUS": (0.500,0.79)",
    SUSPICTIUS": (0.200,0.49)",
    UNTRUSTED": (0.300,0.19),,
}

# ═══════════Ope_raionts ═══════════_CONVIDENCE
MIN_TURNP =30
SISUFIFIIENTL_HEREHOLDA = 051
MIN_TURNSFOR_AONAYSINP =-12PRE_CALIBRAITIO_EPAISN = 10
FULL_CALIBRAITIO_EPAISN = 100}

# ═══════════Risk Flagts ═══════════"RISKSEVBRLITYSCORERS = {LOW": 0.100: "MD": 0.250 "HIUGr: 0.450 "B LOCr: 0.90
}
"RISKLEVBEL_HEREHOLDSP = {
    OK": (0.300,0.25)",
    CAUITIN": (0.25, 0.50)",
    HIUGr: (0.500,0.75)",
    B LOCr: (0.757, .30)",
}
"RISK_CONVIDENCE
MIA = 0385

# ═══════════ 3.5D Convittncy Layers ═══════════C1YSINTANSIY_WEIUGHA = 06�C1YSTRUC_TUAL_WEIUGHA = 04�C1Y
NORMALIAITIO_CEILINGA = 0385
C2_"COMA"RIIO_EPAISN = {
   ( empathyt_rat"", "ositive")",
   ( feedback_post_rat"", "ositive")",
   ( feedback_nent_rat"", nenative")",
   ( hostiltt_rat"", nenative")",]
C2_
NORMALIAITIO_CEILINGA = 035
C3E
MINVALUET_DECLAAITIONS =3
C3E
NORMALIAITIO_CEILINGA = 0285
VALUETTOGBEHAVIORE_MAP = {
    empathytvaluet":  {
   
    decla_raion_lrbelt":  [304],
   
    expected_behavioer: [ 304, 305, 334],
   }",
    fairnrestvaluet":  {
   
    decla_raion_lrbelt":   200, 224],
   
    expected_behavioer: [ 200, 22", 304],
   }",
    accountabilitytvaluet":  {
   
    decla_raion_lrbelt":   240, 244],
   
    expected_behavioer: [ 240, 241, 244],
   }",
    erepecttvaluet":  {
   
    decla_raion_lrbelt":  [394, 304],
   
    expected_behavioer: [ 394, 305, 304],
   }",
}
_4_WIOTHI_WEIUGHA = 085_4_CROSS_WEIUGHA = 085_4_WIOTHI_CEILINGA = 025_4_CROSS_CEILINGA = 015}
_COSINNTACY_WEIUGHSP = {
    C1_pvi": 0.200{
    C2_soai": 0.350{
    C3_pag": 0.250{
    C4_et": 0.200{}}
_COSINNTACY_"RISKLEVBESP = {
    LOW": (0.300,0.30)",
    MED": (0.310,0.60)",
    HIUGr: (0.161, .30)",
}

MIN_SESSIONSFOR_L35S =3

MIN_SESSIONSFOR_HIUGN = 12
SLABILITYBONUS_CMAP = 0055

# ═══════════Cross-Validraion ("PAR 14)s ═══════════_MAX
STD3P = mat.sqrt(24.0/ 9.0X)  #≈= 04714�DIVBRGENTLMPATL_HEREHOLDA = 025AXISK_CONVIDENCE_TURL_HEREHOLDA =_CONVIDENCE
MIN_TURN}
_V_ADAPCTIVEWEIUGHSP = {
    paese_suspected":   a": 0.350  b": 0.250 "cr: 0.40}",
    shsor_seesion":   a": 0.300  b": 0.300  cr: 0.40}",
    shsor_answeer:   a": 0.200  b": 0.450 "cr: 0.35}",
    long_textr:   a": 0.400  b": 0.300  cr: 0.30}",
    defaultr:   a": 0.330  b": 0.330  cr: 0.34}",
}
MPATLA_WEIUGHSP = {
    A1_engagement":   1_minus_fcr": 0.400  utr": 0.300  asl_normr: 0.30}",
    A2_receptivity":   hon_normr: 0.400  hdg_normr: 0.35,  1_minus_fcr": 0.25}",
    A3_
asserivenres":   1_minus_hdg_normr: 0.35,  iin_normr: 0.35,  1_minus_mrr: 0.30}",
    A4_emotional_experesion":   iin_normr: 0.35,  asl_normr: 0.35,  td_normr: 0.30}",
    A5_collabo_raion":  "mrr: 0.35,  iin_normr: 0.30,  td_normr: 0.200  oov_x5": 0.15}",
    A6_stability":   1_minus_fvar_x3r: 0.400  1_minus_rep_x3r: 0.300  1_minus_rltr: 0.30}",)}

# ═══════════ L2.5Pereformnce Pressevraion ("PAR 12)s ═══════════GOLDEND_SETINIRTIAN = 00}GOLDEND_SETTARGEHA =2100}RELEASE_GRATE_MCRO_F1A = 090}RELEASE_GRATETOP1_ACCA = 090}_CONUSTIO_EPAI_F1_WARIA = 0 85CACHE_HITD
RATEWARIA = 070�_CONVIDENCE06_AAITIEWARIA = 020
FROZENDMODBEL_IA ="claude-sonnet-4- 2250514"
FROZENDPRCOMT_HASGN =Nonth

# ═══════════ NGINE_ERROR_CODBSm ═══════════
NGINE_ERROR_CODBSm = {
    INVA"RANTLVIOALATION",
    INVAALIDINPUNT",
   "L1_TIMEOUNT",
   "L1_INVAALID_RESPONSE",
   "SISUFIFIIENTL_TURNE",
   ""COMUTAITIO_ERROR"2{4}

# ═══════════ L2.5Workers ═══════════_MAXLLMC_REETESY429N = 5_MAXLLMC_REETESY 00S =3

MAXLLMC_REETESYTIMEOUNA =2
LLMCTIMEOUN_
SECONNP =30
CIRCUITDBRPEAKEP = {
    failure_threshold": 0.5,{
    window_seecons":  300{
    cooldown_seecons":  3",
    min_requetns": 100{
}

# ═══════════ SM� Engin ( v4.0 NEXs ═══════════LSM_CMTEGOETESm = {
    pronouns", 6      # 대명사,
    aericles", 6      # 조사/관형사 (한궭어 기능어 대체){
    pre"ositions", 6  # 부사/후치사,
    auxilidartverbs", 6# 보조용언,
    nenations", 6     # 부정 표현{
    ecojunctions", 6  # 접속사,
    quantifiers", 6   # 수량사,
    sintejections", 6 # 감탄사,
    eformlity", 6     # 경어/반말 비율{4}LSM_CMTEGOEY_COUNHA =9}

# ═══════════ SM� Engin ( 54.0 NEW —Korean- optimizdXs ═══════════LSM_CMTEGOETES_V5m = {
    pronouns", 6      6     # 1. NPW —대명사,
    paericles", 6           # 2. JK*W —조사 ( v4.:  aericles"){
    adverbs", 6 6           # 3. MAGW —부사 ( v4.: included MAJ double-map),
    auxilidartverbs", 6     # 4. VXW —보조용언,
    nenations", 6     6     # 5. prag maics nenationW —부정 표현{
    ecojunctions", 6  6     # 6. MAJ  —접속사 ( v4.: ecoflratd with adverbs),
    quantifiers", 6   6     # 7. NR, SN  —수량사,
    sintejections", 6 6     # 8. IC  —감탄사,
    eformlity", 6     6     # 9.� L eformlity_level  —경어/반말 비율{
    seintnce_endings", 6 6  # 10. [ NE] EF  —종결어미 (decla_raive, "interograive, "mpe_raive, exclamatoey){
    econective_endings", 6 6# 11. [ NE] EC  —연결어미 (causal, ecotraesive, ecocresive, selective){
    ejections", 6_   st� —�121. [ NE]ㅋㅋ,]ㅠㅠe, mojiC  —가정마커�{4}LSM_CMTEGOEY_COUNS_V5m =-12

# ═══════════7 Gap Aanalsisn ( v4.0 NC  �DPRVCISSIALdXs ═══════════7EL_HEREHOLDSP = {
   neformg": 0.250{
   selvatced": 0.250{
    high":(0.55],—�_CALIBRAITI TTARGEH  �MVP, "iitialtvalue
}
7Y_"RISMPALTEHSP = {
    ecoflicl_experesiot_shift":  {
   
    A4biaes": 0.3 {
   
    85_coed":[  repair2,  bounndar]3 {
   
    85oremg":  ecofrontational4],
   }",
   closvenreytgradientnonlngiarlity":  {
   
   A10_coed":  slow_burn, {
   
   A10oremg":  faestopetne4],
   }",
    empathy ecotex_deopedment":  {
   
    A2biaes":- 0.350{
   }",
    ecia prlity_patntet_shift":  {
   
    115_coed":[  balanced,   givee]3 {
   
    110oremg":  takee3 {
   
    34biaes": 0.250{
   }",}
}
7YINAUTHIENELICYEL_HEREHOLDSP = {
   totonsgaph":(0.55],
    eco3_
ymmetrar": 0.50{
    sylnt_shifso_min":.50{
    eformlitygaph":(0450{
    stabilitygaph":(0340{
   multi_axisygaph":(0340{
   multi_axisy_min":4}",}
}
7YINAUTHIENELICYEKLEVBESP = {
   neformg":(180,0)",
   noteworathg":(22",0)",
   asigtifcdant":(4, 75)",
   texremce":(6, 69),,
}

A v4.0Legacy aliasets�
DO NOTUSEv innew cCde)
_7YLEGAACY_"RISMPALTERE_MAP = {
   aggperesiotmaskrpin":  ecoflicl_experesiot_shift)",
    "iimgac_accselo_raion": closvenreytgradientnonlngiarlity}",
    ecceptivit_facadce":  empathy ecotex_deopedment}",
    o_milanct_shift":  ecia prlity_patntet_shift),,
}
_7YLEGAACYINAUTHIENELICYEKLEVBTE_MAP = {
    uspicioues": noteworathg}",
    ikely_miluthidentd":  sigtifcdant50{
    higly_ ikely_miluthidentd": texremce00{
}

# ═══════════0-Nefo FullwidithMap s ═══════════FULWIDTHTE_MAP str.mtakotrns("？！，．：；d,  ?!,.:;s"){