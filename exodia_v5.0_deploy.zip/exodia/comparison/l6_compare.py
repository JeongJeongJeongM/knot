"""
EXODIA v4.0 — L6 Comparison (standalone).
순수 Python. LLM 금지. 결정론적.
구현 기준: v4.0 Spec Section 13.

이 모듈은 comparison/ 디렉토리의 레거시 진입점.
실제 비교 로직은 layers/l5.py (L5Comparator)에 있음.
이 파일은 backward compatibility를 위해 유지.
"""
from __future__ import annotations

from typing import Union

from exodia.constants import (
    CONFLICT_A7,
    CONFLICT_A8,
    CONFLICT_A9,
    CONFLICT_A10,
    CONFLICT_A11,
    L6_ALPHA,
    L6_BETA,
    L6_GAMMA,
    STABILITY_BONUS_CAP,
    FRICTION_SIGNIFICANT,
)
from exodia.models.outputs import (
    FrictionSource,
    L5Output,
    LSMFeatures,
    Profile,
    UserProfile,
)

_CONFIDENCE_THRESHOLD = 0.5

_INTENSITY_KEYS = ["A1", "A2", "A3", "A4", "A5", "A6"]
_STRUCTURAL_KEYS = ["A7", "A8", "A9", "A10", "A11"]

_CONFLICT_MATRICES: dict[str, dict] = {
    "A7": CONFLICT_A7,
    "A8": CONFLICT_A8,
    "A9": CONFLICT_A9,
    "A10": CONFLICT_A10,
    "A11": CONFLICT_A11,
}


class MatchingBlockedError(Exception):
    """Matching gate가 비교를 차단할 때 발생."""
    pass


def compute_l5_comparison(
    profile_a: Union[Profile, UserProfile],
    profile_b: Union[Profile, UserProfile],
    friction_lsm: float = 0.0,
    phase: str = "cold",
) -> L5Output:
    """두 프로파일 → L5Output.

    v4.0: friction_lsm 파라미터 추가 (LSM Engine에서 산출된 값).

    Matching Gate:
      trust_level == UNKNOWN → MatchingBlockedError
      consistency risk_level in (HIGH, UNKNOWN) → MatchingBlockedError
    """
    # ─── Action Contract: HOLD/BLOCK → matching 금지 ───
    for label, profile in [("A", profile_a), ("B", profile_b)]:
        risk_report = getattr(profile, "risk_report", None)
        if risk_report is not None:
            action = risk_report.action
            if action == "BLOCK":
                raise MatchingBlockedError(
                    f"Profile {label} is BLOCKED (invalid profile)"
                )
            if action == "HOLD":
                raise MatchingBlockedError(
                    f"Profile {label} is HELD (excluded from matching)"
                )

    # ─── Matching Gate ───
    _check_matching_gate(profile_a, "A")
    _check_matching_gate(profile_b, "B")

    l3_a = profile_a.l3
    l3_b = profile_b.l3

    friction_sources: list[FrictionSource] = []
    excluded_axes: list[str] = []

    int_axes_a = l3_a.intensity_axes or {}
    int_axes_b = l3_b.intensity_axes or {}
    struct_axes_a = l3_a.structural_axes or {}
    struct_axes_b = l3_b.structural_axes or {}

    # ─── Intensity Friction (A1~A6) — Spec Section 13.2 ───
    intensity_frictions: list[float] = []

    for key in _INTENSITY_KEYS:
        axis_a = int_axes_a.get(key)
        axis_b = int_axes_b.get(key)

        if not axis_a or not axis_b:
            excluded_axes.append(key)
            continue
        if (axis_a.confidence < _CONFIDENCE_THRESHOLD
                or axis_b.confidence < _CONFIDENCE_THRESHOLD):
            excluded_axes.append(key)
            continue

        friction_val = abs(axis_a.score - axis_b.score)
        intensity_frictions.append(friction_val)

        if friction_val > FRICTION_SIGNIFICANT:
            friction_sources.append(FrictionSource(
                axis=key,
                type="intensity_divergence",
                a_value=axis_a.score,
                b_value=axis_b.score,
                friction_contribution=friction_val,
                description_key=f"{key}_divergence",
            ))

    friction_intensity = (
        sum(intensity_frictions) / len(intensity_frictions)
        if intensity_frictions else 0.0
    )

    # ─── Structural Friction (A7~A11) — Spec Section 13.3 ───
    structural_frictions: list[float] = []

    for key in _STRUCTURAL_KEYS:
        axis_a = struct_axes_a.get(key)
        axis_b = struct_axes_b.get(key)

        if not axis_a or not axis_b:
            excluded_axes.append(key)
            continue
        if (axis_a.confidence < _CONFIDENCE_THRESHOLD
                or axis_b.confidence < _CONFIDENCE_THRESHOLD):
            excluded_axes.append(key)
            continue

        matrix = _CONFLICT_MATRICES.get(key, {})
        mix_a = axis_a.mix
        mix_b = axis_b.mix

        friction_val = 0.0
        for style_m, weight_m in sorted(mix_a.items()):
            for style_n, weight_n in sorted(mix_b.items()):
                conflict = matrix.get(style_m, {}).get(style_n, 0.0)
                friction_val += weight_m * weight_n * conflict

        structural_frictions.append(friction_val)

        if friction_val > FRICTION_SIGNIFICANT:
            friction_sources.append(FrictionSource(
                axis=key,
                type="structural_clash",
                a_style=axis_a.dominant,
                b_style=axis_b.dominant,
                friction_contribution=friction_val,
                description_key=f"{key}_{axis_a.dominant}_vs_{axis_b.dominant}",
            ))

    friction_structural = (
        sum(structural_frictions) / len(structural_frictions)
        if structural_frictions else 0.0
    )

    # ─── LSM Friction source (v4.0) ───
    if friction_lsm > FRICTION_SIGNIFICANT:
        friction_sources.append(FrictionSource(
            axis="LSM",
            type="lsm_divergence",
            friction_contribution=friction_lsm,
            description_key="lsm_style_mismatch",
        ))

    # ─── Total Friction / Compatibility — Spec Section 13.1 (v4.0 3-way) ───
    total_friction = (
        L6_ALPHA * friction_intensity +
        L6_BETA * friction_structural +
        L6_GAMMA * friction_lsm
    )
    compatibility = max(0.0, min(1.0, 1.0 - total_friction))

    # ─── Stability Bonus (Spec Section 13.4) ───
    consistency_a = getattr(profile_a, "consistency", None)
    consistency_b = getattr(profile_b, "consistency", None)

    c1_a = consistency_a.c1_pvi if consistency_a else None
    c1_b = consistency_b.c1_pvi if consistency_b else None

    stability_a = 1.0 - c1_a if c1_a is not None else 0.0
    stability_b = 1.0 - c1_b if c1_b is not None else 0.0
    stability_bonus = STABILITY_BONUS_CAP * min(stability_a, stability_b)

    final_compatibility = min(1.0, compatibility + stability_bonus)

    pair_id = f"{profile_a.user_id}_vs_{profile_b.user_id}"

    return L5Output(
        pair_id=pair_id,
        phase=phase,
        friction_total=total_friction,
        friction_intensity=friction_intensity,
        friction_structural=friction_structural,
        friction_lsm=friction_lsm,
        compatibility=final_compatibility,
        friction_sources=friction_sources,
        excluded_axes=excluded_axes,
        stability_bonus=stability_bonus,
        final_score=final_compatibility,
        metadata={
            "base_compatibility": compatibility,
            "stability_bonus": stability_bonus,
        },
    )


def _check_matching_gate(
    profile: Union[Profile, UserProfile],
    label: str,
) -> None:
    """매칭 게이트 검사. 차단 시 MatchingBlockedError 발생."""
    if profile.integrity.trust_level == "UNKNOWN":
        raise MatchingBlockedError(
            f"Person {label}: trust_level=UNKNOWN, blocked from matching"
        )

    consistency = getattr(profile, "consistency", None)
    if consistency is None:
        raise MatchingBlockedError(
            f"Person {label}: no consistency data, blocked from matching"
        )
    if consistency.risk_level in ("HIGH", "UNKNOWN"):
        raise MatchingBlockedError(
            f"Person {label}: risk_level={consistency.risk_level}, "
            f"blocked from matching"
        )
