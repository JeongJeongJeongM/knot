"""EXODIA v3.0 — Cross-validation helper for 3-path system (PART 14).

Provides utility functions for adaptive weight selection, stable softmax,
agreement confidence, and divergent-path detection.
"""

from __future__ import annotations

import math
from typing import Optional

from exodia.constants import (
    CV_ADAPTIVE_WEIGHTS,
    DIVERGENT_PATH_THRESHOLD,
    EPSILON,
    MAX_STD_3,
)


# ═══════════ Stable Softmax ═══════════


def stable_softmax_mix(
    scores: dict[str, float],
    temperature: float = 1.0,
) -> dict[str, float]:
    """Softmax normalization with numerical stability.

    Clips inputs to [-20, 20], subtracts max before exp.
    Zero-sum fallback: equal distribution.
    """
    if not scores:
        return {}

    temp = max(temperature, EPSILON)
    clipped = {
        k: max(-20.0, min(20.0, v / temp)) for k, v in scores.items()
    }
    max_val = max(clipped.values())
    shifted = {k: v - max_val for k, v in clipped.items()}

    exp_vals = {k: math.exp(v) for k, v in shifted.items()}
    total = sum(exp_vals.values())

    if total < EPSILON:
        n = len(exp_vals)
        return {k: 1.0 / n for k in sorted(exp_vals)}

    return {k: exp_vals[k] / total for k in sorted(exp_vals)}


# ═══════════ Adaptive Weight Selection (PART 14 §4) ═══════════


def compute_adaptive_weights(
    risk_flag_ids: list[str],
    turn_count: int,
    avg_sentence_length: float,
) -> dict[str, float]:
    """Select cross-validation weights via first-match priority.

    1. paste_suspected (RF.04/RF.12)
    2. short_session   (turn_count < 20)
    3. short_answer    (avg_sentence_length < 5)
    4. long_text       (avg_sentence_length > 15)
    5. default
    """
    paste_ids = {"RF.04", "RF.12"}
    if paste_ids & set(risk_flag_ids):
        return dict(CV_ADAPTIVE_WEIGHTS["paste_suspected"])
    if turn_count < 20:
        return dict(CV_ADAPTIVE_WEIGHTS["short_session"])
    if avg_sentence_length < 5:
        return dict(CV_ADAPTIVE_WEIGHTS["short_answer"])
    if avg_sentence_length > 15:
        return dict(CV_ADAPTIVE_WEIGHTS["long_text"])
    return dict(CV_ADAPTIVE_WEIGHTS["default"])


# ═══════════ Agreement Confidence ═══════════


def compute_agreement_confidence(path_scores: dict[str, float]) -> float:
    """Compute agreement_confidence from 3-path scores.

    normalized_std = raw_std / MAX_STD_3
    agreement_confidence = 1.0 - normalized_std
    """
    vals = list(path_scores.values())
    if len(vals) < 2:
        return 1.0

    mean = sum(vals) / len(vals)
    variance = sum((v - mean) ** 2 for v in vals) / len(vals)
    raw_std = math.sqrt(max(variance, 0.0))

    normalized_std = raw_std / MAX_STD_3
    return max(0.0, min(1.0, 1.0 - normalized_std))


# ═══════════ Divergent Path Detection ═══════════


def find_divergent_path(
    path_scores: dict[str, float],
) -> tuple[Optional[str], float]:
    """Identify a path whose score differs > 0.2 from the mean of the other two.

    Returns ``(divergent_path_name | None, divergence_magnitude)``.
    """
    if len(path_scores) < 3:
        return None, 0.0

    for key in sorted(path_scores):
        others = [v for k, v in path_scores.items() if k != key]
        others_mean = sum(others) / len(others) if others else 0.0
        diff = abs(path_scores[key] - others_mean)
        if diff > DIVERGENT_PATH_THRESHOLD:
            return key, diff

    return None, 0.0
