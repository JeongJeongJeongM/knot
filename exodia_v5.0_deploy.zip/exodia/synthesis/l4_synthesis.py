"""EXODIA v3.0 — L4 Synthesis + 3-Path Cross-Validation (Phase 7).

Implements PART 14: intensity axes A1–A6 via 3-path cross-validation
(Path A NLP deterministic, Path B L3 formula, Path C statistical pattern)
and structural axes A7–A11.

100 % deterministic.  LLM 금지.
"""

from __future__ import annotations

import math
from typing import Optional

from exodia.constants import (
    A10_THRESHOLDS,
    A11_THRESHOLDS,
    A7_THRESHOLD,
    A8_WEIGHTS,
    A9_WEIGHTS,
    CONFIDENCE_MIN_TURNS,
    EPSILON,
    L3_LEVEL_THRESHOLDS,
    L3_WEIGHTS,
    PATH_A_WEIGHTS,
)
from exodia.models.outputs import (
    ContributingMetric,
    CrossValidationEvidence,
    IntensityAxis,
    L2Output,
    L3Output,
    NLPAggregate,
    RiskReport,
    StructuralAxis,
)
from exodia.synthesis.cross_validator import (
    compute_adaptive_weights,
    compute_agreement_confidence,
    find_divergent_path,
    stable_softmax_mix,
)

# ═══════════ Internal helpers ═══════════

_AXIS_SHORT_KEYS = {
    "A1_engagement": "A1",
    "A2_receptivity": "A2",
    "A3_assertiveness": "A3",
    "A4_emotional_expression": "A4",
    "A5_collaboration": "A5",
    "A6_stability": "A6",
}


def _clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, value))


def _series_trend(
    series: list[float],
) -> tuple[float, float, float]:
    """Return (early_mean, late_mean, gradient) from a rolling series."""
    if not series:
        return 0.0, 0.0, 0.0
    n = len(series)
    if n == 1:
        return series[0], series[0], 0.0
    third = max(n // 3, 1)
    early = sum(series[:third]) / third
    late = sum(series[-third:]) / third
    return early, late, late - early


def _data_confidence(turn_count: int) -> float:
    if turn_count >= CONFIDENCE_MIN_TURNS:
        return 1.0
    return turn_count / CONFIDENCE_MIN_TURNS


def _classify_level(score: float, confidence: float) -> str:
    if confidence < 0.5:
        return "insufficient"
    for level, (lo, hi) in sorted(L3_LEVEL_THRESHOLDS.items()):
        if lo <= score <= hi:
            return level
    return "low"


# ═══════════ Path B — L3 weighted formula ═══════════


def _build_path_b_metrics(
    l2: L2Output,
    turn_count: int,
) -> dict[str, float]:
    """Build the metric-values dict consumed by L3_WEIGHTS."""
    m = l2.metrics
    tr = l2.transition
    ts = l2.timeseries

    norm_turn_count = min(turn_count / 30.0, 1.0)
    norm_change_points = min(ts.change_point_count / 10.0, 1.0)

    return {
        "interest_rate": m.interest_rate,
        "sharing_rate": m.sharing_rate,
        "norm_turn_count": norm_turn_count,
        "self_loop_all": tr.self_loop_all,
        "1_minus_self_loop_all": 1.0 - tr.self_loop_all,
        "empathy_rate": m.empathy_rate,
        "feedback_pos_rate": m.feedback_pos_rate,
        "disinterest_rate": m.disinterest_rate,
        "1_minus_disinterest_rate": 1.0 - m.disinterest_rate,
        "task_assign_rate": m.task_assign_rate,
        "feedback_neg_rate": m.feedback_neg_rate,
        "boundary_rate": m.boundary_rate,
        "availability_rate": m.availability_rate,
        "1_minus_availability_rate": 1.0 - m.availability_rate,
        "hostile_rate": m.hostile_rate,
        "distress_rate": m.distress_rate,
        "status_update_rate": m.status_update_rate,
        "1_minus_status_update_rate": 1.0 - m.status_update_rate,
        "smalltalk_rate": m.smalltalk_rate,
        "1_minus_volatility": 1.0 - ts.volatility,
        "1_minus_norm_change_points": 1.0 - norm_change_points,
    }


def _compute_path_b_score(
    axis_key: str,
    metric_values: dict[str, float],
) -> tuple[float, list[ContributingMetric]]:
    """Weighted sum per L3_WEIGHTS for a single intensity axis."""
    weights = L3_WEIGHTS.get(axis_key, {})
    score = 0.0
    cms: list[ContributingMetric] = []
    for metric, w in sorted(weights.items()):
        val = metric_values.get(metric, 0.0)
        score += w * val
        cms.append(ContributingMetric(metric=metric, value=val, weight=w))
    return _clamp(score), cms


# ═══════════ Path A — NLP deterministic ═══════════


def _build_path_a_features(
    nlp: NLPAggregate,
    turn_count: int,
) -> dict[str, float]:
    """Map NLPAggregate fields to normalised [0,1] feature names expected by PATH_A_WEIGHTS."""
    tc = max(turn_count, 1)

    fcr = nlp.avg_function_content_ratio
    utr = nlp.avg_unique_token_ratio
    asl_norm = _clamp(nlp.avg_sentence_length / 30.0)
    hon_norm = _clamp(nlp.total_honorific_count / tc)
    hdg_norm = _clamp(nlp.total_hedging_count / tc)
    int_norm = _clamp(nlp.total_intensifier_count / tc)
    mr = nlp.avg_modifier_ratio
    td_norm = _clamp(nlp.avg_tree_depth / 10.0)
    oov_x5 = _clamp(nlp.avg_oov_ratio * 5.0)
    fvar_x3 = _clamp(nlp.formality_variance * 3.0)
    rep_x3 = _clamp(nlp.avg_repetition_score * 3.0)
    rlt = _clamp(abs(nlp.response_length_trend))

    return {
        "1_minus_fcr": 1.0 - fcr,
        "utr": utr,
        "asl_norm": asl_norm,
        "hon_norm": hon_norm,
        "hdg_norm": hdg_norm,
        "1_minus_hdg_norm": 1.0 - hdg_norm,
        "int_norm": int_norm,
        "1_minus_mr": 1.0 - mr,
        "mr": mr,
        "td_norm": td_norm,
        "oov_x5": oov_x5,
        "1_minus_fvar_x3": 1.0 - fvar_x3,
        "1_minus_rep_x3": 1.0 - rep_x3,
        "1_minus_rlt": 1.0 - rlt,
    }


def _compute_path_a_score(
    axis_key: str,
    feature_values: dict[str, float],
) -> float:
    """Weighted sum per PATH_A_WEIGHTS for a single intensity axis."""
    weights = PATH_A_WEIGHTS.get(axis_key, {})
    score = 0.0
    for feat, w in weights.items():
        score += w * feature_values.get(feat, 0.0)
    return _clamp(score)


# ═══════════ Path C — Statistical pattern ═══════════


def _compute_path_c_scores(
    l2: L2Output,
    turn_count: int,
) -> dict[str, float]:
    """Derive intensity-axis scores from transition / timeseries patterns."""
    tr = l2.transition
    ts = l2.timeseries

    entropy = tr.entropy_norm if tr.entropy_norm is not None else 0.5
    self_loop = tr.self_loop_all
    eff_norm = (
        _clamp(tr.effective_transitions / max(turn_count - 1, 1))
        if turn_count > 1
        else 0.0
    )
    vol = _clamp(ts.volatility)
    cp_norm = _clamp(ts.change_point_count / 10.0)

    _, _, sharing_grad = _series_trend(ts.sharing_rolling)
    _, empathy_late, _ = _series_trend(ts.empathy_rolling)
    _, hostile_late, _ = _series_trend(ts.hostile_short_rolling)

    return {
        "A1_engagement": _clamp(
            0.35 * (1.0 - self_loop) + 0.35 * entropy + 0.30 * eff_norm
        ),
        "A2_receptivity": _clamp(
            0.40 * entropy
            + 0.30 * _clamp(empathy_late)
            + 0.30 * (1.0 - vol)
        ),
        "A3_assertiveness": _clamp(
            0.40 * self_loop + 0.30 * (1.0 - entropy) + 0.30 * eff_norm
        ),
        "A4_emotional_expression": _clamp(
            0.40 * vol + 0.30 * cp_norm + 0.30 * _clamp(hostile_late)
        ),
        "A5_collaboration": _clamp(
            0.35 * entropy + 0.35 * (1.0 - vol) + 0.30 * eff_norm
        ),
        "A6_stability": _clamp(
            0.40 * (1.0 - vol)
            + 0.30 * (1.0 - cp_norm)
            + 0.30 * self_loop
        ),
    }


# ═══════════ Structural axes A7–A11 ═══════════


def _build_structural_metrics(l2: L2Output) -> dict[str, float]:
    """Build metric-values dict for structural axis computation."""
    m = l2.metrics
    return {
        "hostile_rate": m.hostile_rate,
        "feedback_neg_rate": m.feedback_neg_rate,
        "boundary_rate": m.boundary_rate,
        "disinterest_rate": m.disinterest_rate,
        "empathy_rate": m.empathy_rate,
        "sharing_rate": m.sharing_rate,
        "distress_rate": m.distress_rate,
        "task_assign_rate": m.task_assign_rate,
        "interest_rate": m.interest_rate,
        "feedback_pos_rate": m.feedback_pos_rate,
        "status_update_rate": m.status_update_rate,
        "availability_rate": m.availability_rate,
        "1_minus_hostile": 1.0 - m.hostile_rate,
        "1_minus_boundary": 1.0 - m.boundary_rate,
        "1_minus_sharing": 1.0 - m.sharing_rate,
        "1_minus_distress": 1.0 - m.distress_rate,
        "1_minus_task_assign": 1.0 - m.task_assign_rate,
    }


def _compute_structural_raw(
    config: dict[str, dict[str, float]],
    metric_values: dict[str, float],
) -> dict[str, float]:
    """Compute raw weighted scores per style in a structural axis config."""
    scores: dict[str, float] = {}
    for style, weights in config.items():
        if not isinstance(weights, dict):
            continue
        s = sum(w * metric_values.get(k, 0.0) for k, w in weights.items())
        scores[style] = s
    return scores


def _compute_a7(
    metric_values: dict[str, float],
    conf: float,
) -> StructuralAxis:
    init_score = (
        metric_values.get("task_assign_rate", 0.0)
        + metric_values.get("interest_rate", 0.0)
    )
    resp_score = (
        metric_values.get("empathy_rate", 0.0)
        + metric_values.get("feedback_pos_rate", 0.0)
    )
    diff = init_score - resp_score

    if diff > A7_THRESHOLD:
        dominant = "initiator"
    elif diff < -A7_THRESHOLD:
        dominant = "responder"
    else:
        dominant = "balanced"

    raw = {
        "initiator": init_score,
        "responder": resp_score,
        "balanced": max(0.0, 1.0 - abs(diff) * 5.0),
    }
    mix = stable_softmax_mix(raw)

    return StructuralAxis(
        dominant=dominant if conf >= 0.5 else "insufficient",
        mix=mix,
        confidence=conf,
        contributing_metrics=[
            ContributingMetric(metric="initiative_score", value=init_score, weight=0.5),
            ContributingMetric(metric="response_score", value=resp_score, weight=0.5),
        ],
    )


def _compute_a8(
    metric_values: dict[str, float],
    conf: float,
) -> StructuralAxis:
    raw = _compute_structural_raw(A8_WEIGHTS, metric_values)
    mix = stable_softmax_mix(raw)
    dominant = max(sorted(raw), key=lambda k: raw[k])
    return StructuralAxis(
        dominant=dominant if conf >= 0.5 else "insufficient",
        mix=mix,
        confidence=conf,
    )


def _compute_a9(
    metric_values: dict[str, float],
    conf: float,
) -> StructuralAxis:
    raw = _compute_structural_raw(A9_WEIGHTS, metric_values)
    mix = stable_softmax_mix(raw)
    dominant = max(sorted(raw), key=lambda k: raw[k])
    return StructuralAxis(
        dominant=dominant if conf >= 0.5 else "insufficient",
        mix=mix,
        confidence=conf,
    )


def _compute_a10(
    l2: L2Output,
    conf: float,
) -> StructuralAxis:
    ts = l2.timeseries
    sharing_early, sharing_late, sharing_grad = _series_trend(ts.sharing_rolling)
    empathy_early, empathy_late, empathy_grad = _series_trend(ts.empathy_rolling)

    th = A10_THRESHOLDS
    scores: dict[str, float] = {}

    scores["slow_burn"] = (
        1.0
        if (
            sharing_grad >= th["slow_burn"]["gradient_min"]
            and sharing_early <= th["slow_burn"]["early_max"]
        )
        else 0.0
    )
    scores["fast_opener"] = (
        1.0 if sharing_early >= th["fast_opener"]["early_min"] else 0.0
    )
    scores["surface_locked"] = (
        1.0
        if (
            sharing_late <= th["surface_locked"]["late_max"]
            and abs(sharing_grad) <= th["surface_locked"]["abs_gradient_max"]
        )
        else 0.0
    )
    scores["depth_seeker"] = (
        1.0
        if (
            sharing_grad >= th["depth_seeker"]["sharing_gradient_min"]
            and empathy_grad >= th["depth_seeker"]["empathy_gradient_min"]
        )
        else 0.0
    )

    if max(scores.values()) == 0:
        scores["surface_locked"] = 0.5

    dominant = max(sorted(scores), key=lambda k: scores[k])
    mix = stable_softmax_mix(scores)

    return StructuralAxis(
        dominant=dominant if conf >= 0.5 else "insufficient",
        mix=mix,
        confidence=conf,
        contributing_metrics=[
            ContributingMetric(metric="sharing_early", value=sharing_early, weight=0.25),
            ContributingMetric(metric="sharing_late", value=sharing_late, weight=0.25),
            ContributingMetric(metric="sharing_gradient", value=sharing_grad, weight=0.25),
            ContributingMetric(metric="empathy_gradient", value=empathy_grad, weight=0.25),
        ],
    )


def _compute_a11(
    metric_values: dict[str, float],
    conf: float,
) -> StructuralAxis:
    give = (
        metric_values.get("feedback_pos_rate", 0.0)
        + metric_values.get("empathy_rate", 0.0)
        + metric_values.get("status_update_rate", 0.0)
    )
    take = (
        metric_values.get("task_assign_rate", 0.0)
        + metric_values.get("interest_rate", 0.0)
        + (1.0 - metric_values.get("sharing_rate", 0.0))
    )
    ratio = give / (give + take + EPSILON)

    if ratio >= A11_THRESHOLDS["giver"]["ratio_min"]:
        dominant = "giver"
    elif ratio <= A11_THRESHOLDS["taker"]["ratio_max"]:
        dominant = "taker"
    else:
        dominant = "balanced"

    raw = {
        "giver": give,
        "taker": take,
        "balanced": max(0.0, 1.0 - abs(give - take) * 3.0),
    }
    mix = stable_softmax_mix(raw)

    return StructuralAxis(
        dominant=dominant if conf >= 0.5 else "insufficient",
        mix=mix,
        confidence=conf,
        contributing_metrics=[
            ContributingMetric(metric="give_score", value=give, weight=0.5),
            ContributingMetric(metric="take_score", value=take, weight=0.5),
        ],
    )


# ═══════════ Public API ═══════════


def compute_l3_synthesis(
    session_id: str,
    l2_output: L2Output,
    nlp_aggregate: Optional[NLPAggregate],
    risk_report: RiskReport,
    turn_count: int,
) -> L3Output:
    """Compute L4 synthesis with 3-path cross-validation (PART 14).

    Returns L3Output (blueprint naming convention: L3Output = L4 synthesis result).
    """

    # ── BLOCK handling ──
    if risk_report.action == "BLOCK":
        return L3Output(
            session_id=session_id,
            status="BLOCKED",
        )

    conf = _data_confidence(turn_count)

    # ── Path B: L3 weighted formula ──
    path_b_metrics = _build_path_b_metrics(l2_output, turn_count)
    path_b_scores: dict[str, float] = {}
    path_b_cms: dict[str, list[ContributingMetric]] = {}
    for axis_key in L3_WEIGHTS:
        score, cms = _compute_path_b_score(axis_key, path_b_metrics)
        path_b_scores[axis_key] = score
        path_b_cms[axis_key] = cms

    # ── Path A: NLP deterministic (only when nlp_aggregate available) ──
    has_path_a = nlp_aggregate is not None
    path_a_scores: dict[str, float] = {}
    if has_path_a:
        assert nlp_aggregate is not None
        path_a_features = _build_path_a_features(nlp_aggregate, turn_count)
        for axis_key in PATH_A_WEIGHTS:
            path_a_scores[axis_key] = _compute_path_a_score(
                axis_key, path_a_features
            )

    # ── Path C: statistical pattern ──
    path_c_raw = _compute_path_c_scores(l2_output, turn_count)
    path_c_scores: dict[str, float] = {}
    for axis_key in L3_WEIGHTS:
        path_c_scores[axis_key] = path_c_raw.get(axis_key, 0.0)

    # ── Adaptive weights ──
    risk_flag_ids = [f.rule_id for f in risk_report.flags]
    asl = nlp_aggregate.avg_sentence_length if nlp_aggregate else 10.0
    weights = compute_adaptive_weights(risk_flag_ids, turn_count, asl)

    # When Path A unavailable, redistribute its weight to B and C
    if not has_path_a and weights["a"] > 0.0:
        extra = weights["a"]
        total_bc = weights["b"] + weights["c"]
        if total_bc > EPSILON:
            weights["b"] += extra * weights["b"] / total_bc
            weights["c"] += extra * weights["c"] / total_bc
        else:
            weights["b"] += extra / 2.0
            weights["c"] += extra / 2.0
        weights["a"] = 0.0

    # ── Cross-validated intensity axes A1–A6 ──
    intensity_axes: dict[str, IntensityAxis] = {}
    cross_validation: list[CrossValidationEvidence] = []

    for axis_key in L3_WEIGHTS:
        short = _AXIS_SHORT_KEYS.get(axis_key, axis_key)

        scores_3: dict[str, float] = {"b": path_b_scores[axis_key]}
        if has_path_a and axis_key in path_a_scores:
            scores_3["a"] = path_a_scores[axis_key]
        scores_3["c"] = path_c_scores[axis_key]

        # Fuse
        final_score = (
            weights.get("a", 0.0) * scores_3.get("a", 0.0)
            + weights["b"] * scores_3["b"]
            + weights["c"] * scores_3["c"]
        )
        final_score = _clamp(final_score)

        # Agreement
        agreement = compute_agreement_confidence(scores_3)
        axis_conf = _clamp(min(conf, agreement) * risk_report.confidence_multiplier)
        level = _classify_level(final_score, axis_conf)

        # Divergent path
        div_path, div_mag = find_divergent_path(scores_3)

        cv_evidence = CrossValidationEvidence(
            axis=short,
            scores=scores_3,
            agreement=agreement,
            weights_used=weights,
            divergent_path=div_path,
            divergence_magnitude=div_mag,
            final_score=final_score,
        )
        cross_validation.append(cv_evidence)

        intensity_axes[short] = IntensityAxis(
            score=final_score,
            level=level,
            confidence=axis_conf,
            contributing_metrics=path_b_cms.get(axis_key, []),
        )

    # ── Structural axes A7–A11 ──
    struct_conf = _clamp(conf * risk_report.confidence_multiplier)
    struct_metrics = _build_structural_metrics(l2_output)
    structural_axes: dict[str, StructuralAxis] = {
        "A7": _compute_a7(struct_metrics, struct_conf),
        "A8": _compute_a8(struct_metrics, struct_conf),
        "A9": _compute_a9(struct_metrics, struct_conf),
        "A10": _compute_a10(l2_output, struct_conf),
        "A11": _compute_a11(struct_metrics, struct_conf),
    }

    return L3Output(
        session_id=session_id,
        status="OK",
        intensity_axes=intensity_axes,
        structural_axes=structural_axes,
        cross_validation=cross_validation,
        metadata={
            "turn_count": turn_count,
            "path_a_available": has_path_a,
            "adaptive_weights": weights,
        },
    )
