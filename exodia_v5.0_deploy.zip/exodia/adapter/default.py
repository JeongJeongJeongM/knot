"""EXODIA v5.0 — DefaultAdapter (minimal implementation)."""
from __future__ import annotations
from typing import Optional
from exodia.adapter.base import ExodiaAdapter, CompatibilityLabel, RiskAction


class DefaultAdapter(ExodiaAdapter):
    """Minimal default adapter with neutral framing."""

    def translate_compatibility(self, score: float) -> CompatibilityLabel:
        if score >= 0.8:
            return CompatibilityLabel(
                label="높은 조화",
                description="많은 공통점이 발견된 조합입니다",
            )
        elif score >= 0.6:
            return CompatibilityLabel(
                label="좋은 가능성",
                description="서로를 보완할 수 있는 조합입니다",
            )
        elif score >= 0.4:
            return CompatibilityLabel(
                label="흥미로운 조합",
                description="다양한 관점을 나눌 수 있는 조합입니다",
            )
        elif score >= 0.2:
            return CompatibilityLabel(
                label="특별한 매력",
                description="서로 다른 강점을 가진 조합입니다",
            )
        else:
            return CompatibilityLabel(
                label="새로운 발견",
                description="차이점을 통해 새로운 관점을 얻을 수 있습니다",
            )

    def translate_gap_narrative(self, total_gap: Optional[float], signals: list[str]) -> str:
        if total_gap is None or total_gap < 0.25:
            return "자연스러운 맥락 적응이 관찰됩니다."
        elif total_gap < 0.45:
            return "상황에 따라 다양한 모습을 보여주는 분입니다."
        elif total_gap < 0.65:
            return "대화 환경에 따른 의미 있는 행동 변화가 관찰됩니다. 실제 대화로 더 알아보세요."
        else:
            return "다양한 대화 환경에서 풍부한 변화를 보이는 분입니다. 직접 대화로 이해를 넓혀보세요."

    def translate_risk_action(self, inauthenticity_score: int) -> RiskAction:
        if inauthenticity_score <= 1:
            return RiskAction(action="none")
        elif inauthenticity_score <= 3:
            return RiskAction(
                action="inform",
                reason="대화 환경에 따른 흥미로운 변화가 관찰됩니다",
            )
        else:
            return RiskAction(
                action="suggest_caution",
                reason="다양한 행동 변화가 관찰됩니다. 추가 대화를 통해 서로를 이해해보세요",
            )
