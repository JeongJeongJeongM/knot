"""EXODIA v5.0 — Adapter Layer (Abstract Base)."""
from __future__ import annotations
from abc import ABC, abstractmethod
from pydantic import BaseModel
from typing import Optional


class CompatibilityLabel(BaseModel):
    label: str
    description: str
    emoji: str = ""


class RiskAction(BaseModel):
    action: str  # "none" | "inform" | "suggest_caution"
    reason: str = ""


class ExodiaAdapter(ABC):
    """Domain-specific UX translation layer."""

    @abstractmethod
    def translate_compatibility(self, score: float) -> CompatibilityLabel:
        """Compatibility score → user-facing label."""

    @abstractmethod
    def translate_gap_narrative(self, total_gap: Optional[float], signals: list[str]) -> str:
        """L7 gap analysis → user-friendly explanation."""

    @abstractmethod
    def translate_risk_action(self, inauthenticity_score: int) -> RiskAction:
        """L7 risk signal → action recommendation."""
