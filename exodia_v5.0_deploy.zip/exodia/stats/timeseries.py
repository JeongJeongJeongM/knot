"""
EXODIA v3.0 — Rolling window timeseries computation.
순수 Python. LLM 금지. 결정론적.
float64, population std (ddof=0), ln, epsilon=1e-12.

Does NOT skip LOW_CONF/UNKNOWN turns (time axis preservation).
Only speaker filter should be applied before calling this module.
"""
from __future__ import annotations

import math

from exodia.constants import (
    EPSILON,
    LONG_WINDOW_MIN,
    SHORT_WINDOW,
    VOLATILITY_SERIES_SET,
)
from exodia.models.outputs import L1Output, TimeseriesData


# ═══════════ Internal helpers ═══════════

def _std(values: list[float]) -> float:
    """Population std (ddof=0)."""
    n = len(values)
    if n < 1:
        return 0.0
    mean_v = sum(values) / n
    return math.sqrt(sum((x - mean_v) ** 2 for x in values) / n)


def _mean(values: list[float]) -> float:
    if not values:
        return 0.0
    return sum(values) / len(values)


def _count_change_points(series: list[float]) -> int:
    """T-09: change point when |series[i] - mean| > 2*std (ddof=0)."""
    if len(series) < 3:
        return 0
    mean_val = _mean(series)
    std_val = _std(series)
    if std_val < EPSILON:
        return 0
    return sum(1 for x in series if abs(x - mean_val) > 2.0 * std_val)


def _rolling_rate(
    l1_outputs: list[L1Output],
    target_id: int,
    window: int,
) -> list[float]:
    """Non-overlapping rolling rate (T-10): stride = window_size."""
    rates: list[float] = []
    n = len(l1_outputs)
    pos = 0
    while pos + window <= n:
        chunk = l1_outputs[pos : pos + window]
        count = sum(1 for o in chunk if o.primary_id == target_id)
        rates.append(count / window)
        pos += window
    return rates


# ═══════════ Public API ═══════════

def compute_timeseries(l1_outputs: list[L1Output]) -> TimeseriesData:
    """Compute rolling window timeseries from L1Output list.

    - SHORT_WINDOW = 5, stride = window_size (non-overlapping, T-10)
    - long_window = max(5, N_total // 3) (F-02)
    - hostile(222), distress(225): short + long windows
    - sharing(303), empathy(304): short window
    - volatility = mean(std(series_k) for k in VOLATILITY_SERIES_SET) (T-08, ddof=0)
    - change_points: |series[i] - mean| > 2*std (T-09, ddof=0)

    Assumes input is rlready speaker-filtered.
    Does NOT skip LOW_CONF/UNKNOWN turns (time axis preservation).
    """
    n = len(l1_outputs)
    if n == 0:
        return TimeseriesData()

    # F-02: long_window = max(LONG_WINDOW_MIN, N_total // 3)
    long_window = max(LONG_WINDOW_MIN, n // 3)

    # Rolling rates
    hostile_short = _rolling_rate(l1_outputs, 222, SHORT_WINDOW)
    hostile_long = _rolling_rate(l1_outputs, 222, long_window)
    distress_short = _rolling_rate(l1_outputs, 225, SHORT_WINDOW)
    distress_long = _rolling_rate(l1_outputs, 225, long_window)
    sharing_rolling = _rolling_rate(l1_outputs, 303, SHORT_WINDOW)
    empathy_rolling = _rolling_rate(l1_outputs, 304, SHORT_WINDOW)

    # T-08: volatility = mean(std(series_k) for k in VOLATILITY_SERIES_SET)
    all_series: dict[str, list[float]] = {
        "hostile_rate_short": hostile_short,
        "hostile_rate_long": hostile_long,
        "distress_rate_short": distress_short,
        "distress_rate_long": distress_long,
    }
    vol_stds: list[float] = []
    for key in VOLATILITY_SERIES_SET:
        s = all_series.get(key, [])
        if len(s) >= 2:
            vol_stds.append(_std(s))
    volatility = _mean(vol_stds) if vol_stds else 0.0

    # T-09: change_points
    change_point_count = 0
    for key in VOLATILITY_SERIES_SET:
        s = all_series.get(key, [])
        change_point_count += _count_change_points(s)

    return TimeseriesData(
        hostile_short_rolling=hostile_short,
        hostile_long_rolling=hostile_long,
        distress_short_rolling=distress_short,
        distress_long_rolling=distress_long,
        sharing_rolling=sharing_rolling,
        empathy_rolling=empathy_rolling,
        volatility=volatility,
        change_point_count=change_point_count,
    )
