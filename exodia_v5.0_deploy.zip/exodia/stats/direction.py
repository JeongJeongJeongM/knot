"""
EXODIA v3.0 — Direction metrics computation.
순수 Python. LLM 금지. 결정론적.
float64, all dict iteration in sorted order.
"""
from __future__ import annotations

from exodia.constants import (
    BOUNDARY_LABEL_IDS,
    DERIVED_RATE_MAP,
    EXTENDED_RATE_MAP,
    RATE_LABEL_MAP,
)
from exodia.models.outputs import DirectionMetrics, L1Output


def compute_direction_metrics(l1_outputs: list[L1Output]) -> DirectionMetrics:
    """Compute direction distribution, per-direction rates, and value declaration rates.

    - direction_distribution: fraction of turns per direction (self/other/neutral)
    - rates_by_direction: all label rates split by direction
    - value_declaration_rate / _self_rate / _other_rate

    Assumes input is already speaker-filtered and truncated.
    """
    total = len(l1_outputs)
    if total == 0:
        return DirectionMetrics()

    # ── Accumulate per-direction counts ──────────────────────────
    dir_counts: dict[str, int] = {}
    dir_outputs: dict[str, list[L1Output]] = {}
    vd_self = 0
    vd_other = 0

    for o in l1_outputs:
        d = o.direction
        dir_counts[d] = dir_counts.get(d, 0) + 1
        dir_outputs.setdefault(d, []).append(o)
        if o.mention_flags.VALUE_DECLARATION:
            if d == "self":
                vd_self += 1
            elif d == "other":
                vd_other += 1

    # ── Direction distribution (sorted keys) ─────────────────────
    direction_distribution: dict[str, float] = {}
    for k in sorted(dir_counts.keys()):
        direction_distribution[k] = dir_counts[k] / total

    # ── Build unified rate label lookup ──────────────────────────
    all_rate_labels: dict[str, int] = {}
    for name in sorted(RATE_LABEL_MAP.keys()):
        all_rate_labels[name] = RATE_LABEL_MAP[name]
    for name in sorted(EXTENDED_RATE_MAP.keys()):
        all_rate_labels[name] = EXTENDED_RATE_MAP[name]
    for name in sorted(DERIVED_RATE_MAP.keys()):
        all_rate_labels[name] = DERIVED_RATE_MAP[name]

    # ── Rates by direction (sorted keys) ─────────────────────────
    rates_by_direction: dict[str, dict[str, float]] = {}
    for direction in sorted(dir_outputs.keys()):
        outputs = dir_outputs[direction]
        dir_total = len(outputs)
        rates: dict[str, float] = {}

        for rate_name in sorted(all_rate_labels.keys()):
            label_id = all_rate_labels[rate_name]
            if dir_total > 0:
                count = sum(1 for o in outputs if o.primary_id == label_id)
                rates[rate_name] = count / dir_total
            else:
                rates[rate_name] = 0.0

        if dir_total > 0:
            boundary_count = sum(
                1 for o in outputs if o.primary_id in BOUNDARY_LABEL_IDS
            )
            rates["boundary_rate"] = boundary_count / dir_total
        else:
            rates["boundary_rate"] = 0.0

        rates_by_direction[direction] = dict(sorted(rates.items()))

    # ── Value declaration rates ──────────────────────────────────
    vd_total = vd_self + vd_other
    return DirectionMetrics(
        direction_distribution=direction_distribution,
        rates_by_direction=rates_by_direction,
        value_declaration_rate=vd_total / total,
        value_declaration_self_rate=vd_self / total,
        value_declaration_other_rate=vd_other / total,
    )
