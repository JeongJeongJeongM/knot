"""
EXODIA v5.0 — L7 Gap Analysis (PROVISIONAL).
순수 Python. LLM 금지. 결정론적.
구현 기준: v5.0 Spec Section 14.

L7은 동일 유저의 profile_cold와 profile_real을 비교하여
크로스-컨텍스트 일관성을 측정한다. 행동 일관성 분석을 통해
맥락별 신뢰성을 평가한다.

- L6: 두 **사람** 간 호환성
- L7: 한 **사람**의 두 **컨텍스트** 간 일관성

Status: PROVISIONAL — 공식 확정, 임계값 교정 대상.
"""
from __future__ import annotations

from typing import Optional

from exodia.constants import (
    L7_THRESHOLDS,
    L7_RISK_PATTERNS,
    L7_INAUTHENTICITY_THRESHOLDS,
    L7_INAUTHENTICITY_LEVELS,
)
from exodia.models.outputs import (
    BiasShift,
    GapAnalysis,
    GapComponents,
    IntensityAxis,
    L7Output,
    RiskAssessment,
    SessionProfile,
    StructuralAxis,
    StyleShift,
    UserProfile,
)

_CONFIDENCE_THRESHOLD = 0.5
_INTENSITY_KEYS = ["A1", "A2", "A3", "A4", "A5", "A6"]
_STRUCTURAL_KEYS = ["A7", "A8", "A9", "A10", "A11"]
_MIN_VALID_INTENSITY = 3  # 유효 축 3개 미만이면 강도 갭 보류
_MIN_VALID_STRUCTURAL = 2  # 유효 축 2개 미만이면 구조 갭 보류


class L7GapAnalyzer:
    """L7 Gap Analysis — cold vs real 불일치 분석.

    Spec Section 14.2 활성화 조건:
        profile_real 데이터가 존재할 때만 활성화.
        cold만 있으면 L7 출력 없음 (FAIL-SAFE).
    """

    def analyze(self, user_profile: UserProfile) -> Optional[L7Output]:
        """유저의 cold vs real 프로파일 갭 분석.

        Args:
            user_profile: profile_cold와 profile_real이 모두 있는 UserProfile

        Returns:
            L7Output if profile_real exists, None otherwise (FAIL-SAFE)
        """
        cold = user_profile.profile_cold
        real = user_profile.profile_real

        # Spec 14.2: real이 없으면 L7 비활성
        if cold is None or real is None:
            return None

        # Intensity Gap (Spec 14.3)
        intensity_gap, bias_shifts = self._compute_intensity_gap(cold, real)

        # Structural Gap (Spec 14.4)
        structural_gap, style_shifts = self._compute_structural_gap(cold, real)

        # LSM Gap (Spec 14.5)
        lsm_gap = self._compute_lsm_gap(user_profile)

        # Total Gap (Spec 14.6)
        gap_analysis = self._compute_total_gap(intensity_gap, structural_gap, lsm_gap)

        # Risk Assessment (Spec 14.8 + 14.9 + 14.10)
        risk_assessment = self._assess_risk(
            gap_analysis, bias_shifts, style_shifts, cold, real
        )

        # Gap Vector 20d (Spec 14.11)
        gap_vector = self._build_gap_vector(
            cold, real, bias_shifts, style_shifts, lsm_gap, user_profile
        )

        return L7Output(
            user_id=user_profile.user_id,
            gap_analysis=gap_analysis,
            bias_shifts=bias_shifts,
            style_shifts=style_shifts,
            risk_assessment=risk_assessment,
            gap_vector_20d=gap_vector,
            metadata={
                "engine_version": "5.0.0",
                "layer": "L7",
                "cold_turns": cold.turn_count,
                "real_turns": real.turn_count,
            },
        )

    def _compute_intensity_gap(
        self, cold: SessionProfile, real: SessionProfile
    ) -> tuple[Optional[float], list[BiasShift]]:
        """Spec 14.3: Intensity Gap (A1-A6)."""
        cold_axes = cold.l3.intensity_axes or {}
        real_axes = real.l3.intensity_axes or {}

        valid_gaps: list[float] = []
        bias_shifts: list[BiasShift] = []

        for key in _INTENSITY_KEYS:
            axis_cold = cold_axes.get(key, IntensityAxis())
            axis_real = real_axes.get(key, IntensityAxis())

            conf_cold = axis_cold.confidence
            conf_real = axis_real.confidence

            # conf < 0.5 → 산출 보류
            if min(conf_cold, conf_real) < _CONFIDENCE_THRESHOLD:
                bias_shifts.append(BiasShift(
                    axis=key,
                    cold_score=axis_cold.score,
                    real_score=axis_real.score,
                    shift=0.0,  # 보류
                ))
                continue

            raw_gap = abs(axis_cold.score - axis_real.score)
            effective_gap = raw_gap * min(conf_cold, conf_real)
            valid_gaps.append(effective_gap)

            # Bias shift: 양수 = real에서 더 높음
            shift = axis_real.score - axis_cold.score
            bias_shifts.append(BiasShift(
                axis=key,
                cold_score=axis_cold.score,
                real_score=axis_real.score,
                shift=shift,
            ))

        # 유효 축 3개 미만이면 전체 보류 (FAIL-SAFE)
        if len(valid_gaps) < _MIN_VALID_INTENSITY:
            return None, bias_shifts

        return sum(valid_gaps) / len(valid_gaps), bias_shifts

    def _compute_structural_gap(
        self, cold: SessionProfile, real: SessionProfile
    ) -> tuple[Optional[float], list[StyleShift]]:
        """Spec 14.4: Structural Gap (A7-A11) using JSD."""
        cold_axes = cold.l3.structural_axes or {}
        real_axes = real.l3.structural_axes or {}

        valid_gaps: list[float] = []
        style_shifts: list[StyleShift] = []

        for key in _STRUCTURAL_KEYS:
            axis_cold = cold_axes.get(key, StructuralAxis())
            axis_real = real_axes.get(key, StructuralAxis())

            conf_cold = axis_cold.confidence
            conf_real = axis_real.confidence

            shifted = axis_cold.dominant != axis_real.dominant
            style_shifts.append(StyleShift(
                axis=key,
                cold_dominant=axis_cold.dominant,
                real_dominant=axis_real.dominant,
                shifted=shifted,
            ))

            if min(conf_cold, conf_real) < _CONFIDENCE_THRESHOLD:
                continue

            # JSD approximation using mix distributions
            mix_cold = axis_cold.mix
            mix_real = axis_real.mix

            if not mix_cold or not mix_real:
                continue

            jsd = self._jsd_squared(mix_cold, mix_real)
            effective_gap = jsd * min(conf_cold, conf_real)
            valid_gaps.append(effective_gap)

        # 유효 축 2개 미만이면 전체 보류
        if len(valid_gaps) < _MIN_VALID_STRUCTURAL:
            return None, style_shifts

        return sum(valid_gaps) / len(valid_gaps), style_shifts

    @staticmethod
    def _jsd_squared(p: dict[str, float], q: dict[str, float]) -> float:
        """Jensen-Shannon Divergence (squared), 0~1.

        JSD^2 = (KLD(P||M) + KLD(Q||M)) / 2, where M = (P+Q)/2
        """
        import math

        all_keys = set(p.keys()) | set(q.keys())
        if not all_keys:
            return 0.0

        eps = 1e-12
        jsd = 0.0

        for key in all_keys:
            p_val = max(p.get(key, 0.0), eps)
            q_val = max(q.get(key, 0.0), eps)
            m_val = (p_val + q_val) / 2.0

            if p_val > eps:
                jsd += 0.5 * p_val * math.log(p_val / m_val)
            if q_val > eps:
                jsd += 0.5 * q_val * math.log(q_val / m_val)

        # JSD^2 as per spec
        return max(0.0, min(1.0, jsd))

    def _compute_lsm_gap(self, user_profile: UserProfile) -> float:
        """Spec 14.5: LSM Gap = |LSM_cold - LSM_real|."""
        lsm_cold = user_profile.lsm_cold
        lsm_real = user_profile.lsm_real

        if lsm_cold is None or lsm_real is None:
            return 0.0

        return abs(lsm_cold - lsm_real)

    def _compute_total_gap(
        self,
        intensity_gap: Optional[float],
        structural_gap: Optional[float],
        lsm_gap: float,
    ) -> GapAnalysis:
        """Spec 14.6: Total Gap = mean(available components)."""
        components: dict[str, float] = {}

        if intensity_gap is not None:
            components['intensity'] = intensity_gap
        if structural_gap is not None:
            components['structural'] = structural_gap
        components['lsm'] = lsm_gap  # 항상 존재

        if not components:
            return GapAnalysis(
                total_gap=None,
                reliability="low",
                components=GapComponents(lsm=lsm_gap),
            )

        total_gap = sum(components.values()) / len(components)

        # Reliability
        n = len(components)
        reliability_map = {1: "low", 2: "medium", 3: "high"}
        reliability = reliability_map.get(n, "low")

        return GapAnalysis(
            total_gap=total_gap,
            reliability=reliability,
            components=GapComponents(
                intensity=intensity_gap,
                structural=structural_gap,
                lsm=lsm_gap,
            ),
        )

    def _assess_risk(
        self,
        gap_analysis: GapAnalysis,
        bias_shifts: list[BiasShift],
        style_shifts: list[StyleShift],
        cold: SessionProfile,
        real: SessionProfile,
    ) -> RiskAssessment:
        """Spec 14.8 + 14.9 + 14.10: Risk level, patterns, inauthenticity."""

        total_gap = gap_analysis.total_gap

        # Risk Level (Spec 14.8)
        if total_gap is None:
            risk_level = "normal"
        elif total_gap >= L7_THRESHOLDS["high"]:
            risk_level = "critical"
        elif total_gap >= L7_THRESHOLDS["elevated"]:
            risk_level = "high"
        elif total_gap >= L7_THRESHOLDS["normal"]:
            risk_level = "elevated"
        else:
            risk_level = "normal"

        # Risk Patterns (Spec 14.9)
        risk_patterns = self._detect_risk_patterns(bias_shifts, style_shifts)

        # Inauthenticity Detection (Spec 14.10)
        inauthenticity_score = self._compute_inauthenticity(
            total_gap, bias_shifts, style_shifts, cold, real
        )

        # Inauthenticity Level
        inauthenticity_level = "normal"
        for level, (lo, hi) in L7_INAUTHENTICITY_LEVELS.items():
            if lo <= inauthenticity_score <= hi:
                inauthenticity_level = level
                break

        return RiskAssessment(
            risk_level=risk_level,
            risk_patterns=risk_patterns,
            inauthenticity_score=inauthenticity_score,
            inauthenticity_level=inauthenticity_level,
        )

    def _detect_risk_patterns(
        self,
        bias_shifts: list[BiasShift],
        style_shifts: list[StyleShift],
    ) -> list[str]:
        """Spec 14.9: 4 risk patterns (v5.0 neutral labels)."""
        patterns: list[str] = []
        bias_map = {b.axis: b.shift for b in bias_shifts}
        style_map = {s.axis: s for s in style_shifts}

        # 1: conflict_expression_shift (v5.0)
        cfg = L7_RISK_PATTERNS["conflict_expression_shift"]
        a4_shift = bias_map.get("A4", 0.0)
        a8_style = style_map.get("A8")
        if (a4_shift > cfg["A4_bias"] and a8_style and
                a8_style.cold_dominant in cfg["A8_cold"] and
                a8_style.real_dominant == cfg["A8_real"]):
            patterns.append("conflict_expression_shift")

        # 2: closeness_gradient_nonlinearity (v5.0)
        cfg = L7_RISK_PATTERNS["closeness_gradient_nonlinearity"]
        a10_style = style_map.get("A10")
        if (a10_style and
                a10_style.cold_dominant == cfg["A10_cold"] and
                a10_style.real_dominant == cfg["A10_real"]):
            patterns.append("closeness_gradient_nonlinearity")

        # 3: empathy_context_dependent (v5.0)
        cfg = L7_RISK_PATTERNS["empathy_context_dependent"]
        a2_shift = bias_map.get("A2", 0.0)
        if a2_shift < cfg["A2_bias"]:
            patterns.append("empathy_context_dependent")

        # 4: reciprocity_pattern_shift (v5.0)
        cfg = L7_RISK_PATTERNS["reciprocity_pattern_shift"]
        a11_style = style_map.get("A11")
        a3_shift = bias_map.get("A3", 0.0)
        if (a11_style and
                a11_style.cold_dominant in cfg["A11_cold"] and
                a11_style.real_dominant == cfg["A11_real"] and
                a3_shift > cfg["A3_bias"]):
            patterns.append("reciprocity_pattern_shift")

        return patterns

    def _compute_inauthenticity(
        self,
        total_gap: Optional[float],
        bias_shifts: list[BiasShift],
        style_shifts: list[StyleShift],
        cold: SessionProfile,
        real: SessionProfile,
    ) -> int:
        """Spec 14.10: 6 inauthenticity signals, 0-6 score."""
        thresholds = L7_INAUTHENTICITY_THRESHOLDS
        score = 0

        # 1: 극단적 종합 갭
        if total_gap is not None and total_gap > thresholds["total_gap"]:
            score += 1

        # 2: 신뢰도 비대칭
        cold_confs = [
            a.confidence for a in (cold.l3.intensity_axes or {}).values()
        ]
        real_confs = [
            a.confidence for a in (real.l3.intensity_axes or {}).values()
        ]
        if cold_confs and real_confs:
            mean_cold_conf = sum(cold_confs) / len(cold_confs)
            mean_real_conf = sum(real_confs) / len(real_confs)
            if abs(mean_cold_conf - mean_real_conf) > thresholds["conf_asymmetry"]:
                score += 1

        # 3: 구조축 다수 반전 (5개 중 3개+)
        shifted_count = sum(1 for s in style_shifts if s.shifted)
        if shifted_count >= thresholds["style_shifts_min"]:
            score += 1

        # 4: 경어/반말 급변 (formality gap)
        # Use L2 pragmatics formality level from NLP aggregate if available
        cold_formality = self._get_avg_formality(cold)
        real_formality = self._get_avg_formality(real)
        if cold_formality is not None and real_formality is not None:
            if abs(cold_formality - real_formality) > thresholds["formality_gap"]:
                score += 1

        # 5: 시계열 불일치 (A6 Stability gap)
        a6_cold = (cold.l3.intensity_axes or {}).get("A6")
        a6_real = (real.l3.intensity_axes or {}).get("A6")
        if a6_cold and a6_real:
            stability_gap = abs(a6_cold.score - a6_real.score)
            if stability_gap > thresholds["stability_gap"]:
                score += 1

        # 6: 다축 이상 클러스터 (강도축 4개+ gap > 0.3)
        large_gap_count = sum(
            1 for b in bias_shifts
            if abs(b.shift) > thresholds["multi_axis_gap"]
        )
        if large_gap_count >= thresholds["multi_axis_min"]:
            score += 1

        return score

    @staticmethod
    def _get_avg_formality(session: SessionProfile) -> Optional[float]:
        """세션의 평균 formality level 추출."""
        # lsm_features의 formality rate 사용 (있으면)
        if session.lsm_features and "formality" in session.lsm_features.category_rates:
            return session.lsm_features.category_rates["formality"]
        return None

    def _build_gap_vector(
        self,
        cold: SessionProfile,
        real: SessionProfile,
        bias_shifts: list[BiasShift],
        style_shifts: list[StyleShift],
        lsm_gap: float,
        user_profile: UserProfile,
    ) -> list[float]:
        """Spec 14.11: gap_vector_20d v5.0.

        [A1-A6 gap(6), A7-A11 JSD(5), LSM_total(1),
         LSM_sentence_endings, LSM_connective_endings, LSM_emotional_markers,
         LSM_particles, LSM_formality, LSM_negations, LSM_interjections,
         LSM_pronouns]
        = 6 + 5 + 1 + 8 = 20 dimensions
        """
        vector: list[float] = []

        # A1-A6 gap (6 dims)
        bias_map = {b.axis: abs(b.shift) for b in bias_shifts}
        for key in _INTENSITY_KEYS:
            vector.append(bias_map.get(key, 0.0))

        # A7-A11 gap (5 dims) — JSD of style mixes
        cold_struct = cold.l3.structural_axes or {}
        real_struct = real.l3.structural_axes or {}
        for key in _STRUCTURAL_KEYS:
            axis_cold = cold_struct.get(key, StructuralAxis())
            axis_real = real_struct.get(key, StructuralAxis())
            if axis_cold.mix and axis_real.mix:
                jsd = self._jsd_squared(axis_cold.mix, axis_real.mix)
            else:
                jsd = 0.0
            vector.append(jsd)

        # LSM_total (1 dim)
        vector.append(lsm_gap)

        # v5.0: LSM category gaps (8 dims) — Korean-optimized
        lsm_v5_categories = [
            "sentence_endings", "connective_endings", "emotional_markers",
            "particles", "formality", "negations", "interjections", "pronouns",
        ]

        cold_sp = user_profile.profile_cold
        real_sp = user_profile.profile_real
        cold_rates = cold_sp.lsm_features.category_rates if (cold_sp and cold_sp.lsm_features) else {}
        real_rates = real_sp.lsm_features.category_rates if (real_sp and real_sp.lsm_features) else {}

        for cat in lsm_v5_categories:
            c_rate = cold_rates.get(cat, 0.0)
            r_rate = real_rates.get(cat, 0.0)
            vector.append(abs(c_rate - r_rate))

        assert len(vector) == 20, f"gap_vector_20d must be 20 dims, got {len(vector)}"
        return vector
