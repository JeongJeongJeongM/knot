"""
EXODIA v3.0 — Integrity Gate (Trust Score)
PART 5 + PART 7 patches.  Deterministic.  No exceptions.
"""
from __future__ import annotations

from typing import Optional

from exodia.constants import (
    INTEGRITY_INTEGRATION,
    INTEGRITY_STAGE1_WEIGHTS,
    INTEGRITY_STAGE2_WEIGHTS,
    MIN_TURNS_FOR_ANALYSIS,
    TRUST_LEVELS,
)
from exodia.models.inputs import ClientSignals
from exodia.models.outputs import IntegrityEvidence, IntegrityOutput, L2Output


def _clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def _linear(val: float, lo: float, hi: float) -> float:
    """Linear interpolation 0→1 over [lo, hi], clamped to [0, 1]."""
    if hi <= lo:
        return 0.0
    return _clamp((val - lo) / (hi - lo), 0.0, 1.0)


# ═══════════ Stage 1: Input Fingerprint (IF.01~IF.06) ═══════════


def _score_if01(cps: Optional[float]) -> float:
    """IF.01 chars_per_second: 0 if <=8, 1 if >=20, linear."""
    if cps is None:
        return 0.0
    return _linear(cps, 8.0, 20.0)


def _score_if02(paste: Optional[bool]) -> float:
    """IF.02 paste_event: 1.0 if True else 0.0."""
    if paste is None:
        return 0.0
    return 1.0 if paste else 0.0


def _score_if03(ratio: Optional[float]) -> float:
    """IF.03 backspace_ratio: 0 if >=0.05, 1.0-(ratio/0.05) otherwise."""
    if ratio is None:
        return 0.0
    if ratio >= 0.05:
        return 0.0
    return _clamp(1.0 - ratio / 0.05, 0.0, 1.0)


def _score_if04(val: Optional[float]) -> float:
    """IF.04 paragraph_structure: 0 if <=0.5, (val-0.5)/0.5 otherwise."""
    if val is None:
        return 0.0
    if val <= 0.5:
        return 0.0
    return _clamp((val - 0.5) / 0.5, 0.0, 1.0)


def _score_if05(edit_count: Optional[int]) -> float:
    """IF.05 edit_count: 0 if >=1, 1.0 if 0."""
    if edit_count is None:
        return 0.0
    return 1.0 if edit_count == 0 else 0.0


def _score_if06(var: Optional[float]) -> float:
    """IF.06 input_rhythm_variance: 0 if >=0.01, 1.0-(var/0.01) otherwise."""
    if var is None:
        return 0.0
    if var >= 0.01:
        return 0.0
    return _clamp(1.0 - var / 0.01, 0.0, 1.0)


def _compute_stage1(client_signals: Optional[ClientSignals]) -> Optional[float]:
    """Stage 1: per-message paste_likelihood → session_paste_likelihood (mean)."""
    if client_signals is None or not client_signals.messages:
        return None

    w = INTEGRITY_STAGE1_WEIGHTS
    msg_scores: list[float] = []

    for msg in client_signals.messages:
        msg_paste = (
            w["IF01_chars_per_second"] * _score_if01(msg.chars_per_second)
            + w["IF02_paste_event"] * _score_if02(msg.paste_event)
            + w["IF03_backspace_ratio"] * _score_if03(msg.backspace_ratio)
            + w["IF04_paragraph_structure"] * _score_if04(msg.paragraph_structure)
            + w["IF05_edit_count"] * _score_if05(msg.edit_count)
            + w["IF06_input_rhythm_variance"] * _score_if06(msg.input_rhythm_variance)
        )
        msg_scores.append(msg_paste)

    if not msg_scores:
        return None

    return sum(msg_scores) / len(msg_scores)


# ═══════════ Stage 2: Conversation Reciprocity (CR.01~CR.05) ═══════════


def _score_cr01(carry_rate: float) -> float:
    """CR.01: 0 if carry_rate>=0.25, 1.0 if <=0.05, linear (inverted)."""
    if carry_rate <= 0.05:
        return 1.0
    if carry_rate >= 0.25:
        return 0.0
    return _clamp((0.25 - carry_rate) / (0.25 - 0.05), 0.0, 1.0)


def _score_cr02(directness: float) -> float:
    """CR.02: 0 if directness>=0.60, 1.0 if <=0.20, linear (inverted)."""
    if directness <= 0.20:
        return 1.0
    if directness >= 0.60:
        return 0.0
    return _clamp((0.60 - directness) / (0.60 - 0.20), 0.0, 1.0)


def _score_cr03(anomaly: float) -> float:
    """CR.03: 0 if anomaly<=0.40, 1.0 if >=0.80, linear."""
    return _linear(anomaly, 0.40, 0.80)


def _score_cr04(anomaly: float) -> float:
    """CR.04: 0 if anomaly<=0.45, 1.0 if >=0.85, linear."""
    return _linear(anomaly, 0.45, 0.85)


def _score_cr05(pattern_rate: float) -> float:
    """CR.05: 0 if pattern_rate<=0.20, 1.0 if >=0.50, linear."""
    return _linear(pattern_rate, 0.20, 0.50)


def _compute_stage2(l2_output: L2Output) -> float:
    """Stage 2: reciprocity_anomaly from L2-derived signals."""
    w = INTEGRITY_STAGE2_WEIGHTS

    # CR.01 / CR.02 / CR.05 are not directly computable from L2Output;
    # score defaults to 0 (no suspicion) until upstream supplies values.
    s_cr01 = 0.0
    s_cr02 = 0.0
    s_cr03 = _score_cr03(l2_output.cr03_latency_anomaly)
    s_cr04 = _score_cr04(l2_output.cr04_tone_anomaly)
    s_cr05 = 0.0

    reciprocity = (
        w["CR01_reference_carry"] * s_cr01
        + w["CR02_qa_directness"] * s_cr02
        + w["CR03_latency_consistency"] * s_cr03
        + w["CR04_tone_shift_absence"] * s_cr04
        + w["CR05_formulaic_pattern"] * s_cr05
    )
    return _clamp(reciprocity, 0.0, 1.0)


# ═══════════ Stage 3: Trust Score + Classification ═══════════


def _classify_trust_level(trust_score: float) -> str:
    """Classify trust_score → TRUSTED / CAUTIOUS / SUSPICIOUS / UNTRUSTED."""
    for level, (lo, _hi) in sorted(TRUST_LEVELS.items(), key=lambda x: -x[1][0]):
        if trust_score >= lo:
            return level
    return "UNTRUSTED"


def compute_integrity(
    l2_output: L2Output,
    client_signals: Optional[ClientSignals],
    turn_count: int,
) -> IntegrityOutput:
    """Main entry point — L2 + ClientSignals → IntegrityOutput.

    * turn_count < MIN_TURNS_FOR_ANALYSIS  →  UNKNOWN
    * Stage 1 available  →  raw_suspicion = 0.45·stage1 + 0.55·stage2
    * Stage 1 absent     →  raw_suspicion = stage2 only
    * PATCH-05: client_signals is None → trust_score ≤ 0.79, level ≤ CAUTIOUS
    """
    if turn_count < MIN_TURNS_FOR_ANALYSIS:
        return IntegrityOutput(trust_score=None, trust_level="UNKNOWN")

    session_paste_likelihood = _compute_stage1(client_signals)
    reciprocity_anomaly = _compute_stage2(l2_output)

    if session_paste_likelihood is not None:
        raw_suspicion = (
            INTEGRITY_INTEGRATION["stage1_weight"] * session_paste_likelihood
            + INTEGRITY_INTEGRATION["stage2_weight"] * reciprocity_anomaly
        )
    else:
        raw_suspicion = reciprocity_anomaly

    trust_score = _clamp(1.0 - raw_suspicion, 0.0, 1.0)

    # PATCH-05: Stage2-only cap — no client evidence ⇒ max CAUTIOUS
    if client_signals is None:
        trust_score = min(trust_score, 0.79)

    trust_level = _classify_trust_level(trust_score)

    # ── Evidence ──
    stage1_dict = (
        {"session_paste_likelihood": round(session_paste_likelihood, 4)}
        if session_paste_likelihood is not None
        else None
    )
    stage2_dict = {"reciprocity_anomaly": round(reciprocity_anomaly, 4)}

    top_signals: list[dict] = []
    if session_paste_likelihood is not None:
        top_signals.append({
            "stage": "stage1",
            "name": "session_paste_likelihood",
            "value": round(session_paste_likelihood, 4),
        })
    top_signals.append({
        "stage": "stage2",
        "name": "reciprocity_anomaly",
        "value": round(reciprocity_anomaly, 4),
    })

    return IntegrityOutput(
        trust_score=round(trust_score, 4),
        trust_level=trust_level,
        stage1=stage1_dict,
        stage2=stage2_dict,
        evidence=IntegrityEvidence(top_signals=top_signals),
    )
