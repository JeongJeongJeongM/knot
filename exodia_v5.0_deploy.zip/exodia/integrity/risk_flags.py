"""
EXODIA v3.0 — Risk Flag System (RF.01~RF.14)
PART 15.  Deterministic.  No exceptions.
"""
from __future__ import annotations

from typing import Optional

from exodia.constants import (
    RISK_CONFIDENCE_MIN,
    RISK_LEVEL_THRESHOLDS,
    RISK_SEVERITY_SCORES,
)
from exodia.models.outputs import (
    IntegrityOutput,
    L2Output,
    NLPAggregate,
    RiskFlag,
    RiskReport,
)

# Per-rule confidence multiplier effects (spec PART 15)
_CONFIDENCE_EFFECTS: dict[str, float] = {
    "RF.01": 0.80,
    "RF.02": 0.75,
    "RF.03": 0.80,
    "RF.04": 0.50,
    "RF.05a": 0.85,
    "RF.05b": 0.85,
    "RF.05c": 0.85,
    "RF.05d": 0.85,
    "RF.11": 0.70,
    "RF.12": 1.00,
    "RF.13": 1.00,
    "RF.14": 0.75,
}

# Rules whose activation forces action=HOLD regardless of risk_level
_HOLD_RULES: frozenset[str] = frozenset({"RF.12", "RF.13"})


# ═══════════ Helpers ═══════════


def _estimate_turn_count(l2_output: L2Output) -> int:
    ts_len = len(l2_output.timeseries.hostile_short_rolling)
    if ts_len > 0:
        return ts_len
    return max(l2_output.transition.effective_transitions + 1, 1)


def _max_label_rate(l2_output: L2Output) -> float:
    m = l2_output.metrics
    return max(
        m.interest_rate, m.disinterest_rate, m.sharing_rate,
        m.empathy_rate, m.task_assign_rate, m.status_update_rate,
        m.smalltalk_rate, m.feedback_pos_rate, m.feedback_neg_rate,
        m.availability_rate, m.hostile_rate, m.distress_rate,
        m.boundary_rate,
    )


# ═══════════ Base Rules (RF.01~RF.05) ═══════════


def _check_rf01(l2_output: L2Output) -> Optional[RiskFlag]:
    """RF.01: turn_count < 12 → MED, confidence × 0.80."""
    turn_count = _estimate_turn_count(l2_output)
    if turn_count < 12:
        return RiskFlag(
            rule_id="RF.01",
            severity="MED",
            value=float(turn_count),
            threshold=12.0,
            evidence={"turn_count": turn_count},
        )
    return None


def _check_rf02(l2_output: L2Output) -> Optional[RiskFlag]:
    """RF.02: top1_label_rate > 0.65 → MED~HIGH, confidence × 0.75."""
    top1_rate = _max_label_rate(l2_output)
    if top1_rate > 0.65:
        severity = "HIGH" if top1_rate > 0.80 else "MED"
        return RiskFlag(
            rule_id="RF.02",
            severity=severity,
            value=round(top1_rate, 4),
            threshold=0.65,
            evidence={"top1_label_rate": round(top1_rate, 4)},
        )
    return None


def _check_rf03(l2_output: L2Output) -> Optional[RiskFlag]:
    """RF.03: effective_states decline / self_loop surge → MED, confidence × 0.80."""
    td = l2_output.transition
    if td.effective_transitions < 2:
        return None

    self_loop = td.self_loop_all
    entropy = td.entropy_norm if td.entropy_norm is not None else 0.0

    if self_loop > 0.50 and entropy < 0.30:
        return RiskFlag(
            rule_id="RF.03",
            severity="MED",
            value=round(self_loop, 4),
            threshold=0.50,
            evidence={
                "self_loop_all": round(self_loop, 4),
                "entropy_norm": round(entropy, 4),
            },
        )
    return None


def _check_rf04(integrity: IntegrityOutput) -> Optional[RiskFlag]:
    """RF.04: paste / typing burst (integrity stage1) → HIGH, confidence × 0.50."""
    if integrity.stage1 is None:
        return None

    paste_likelihood = integrity.stage1.get("session_paste_likelihood")
    if paste_likelihood is None:
        return None

    if paste_likelihood > 0.50:
        return RiskFlag(
            rule_id="RF.04",
            severity="HIGH",
            value=round(paste_likelihood, 4),
            threshold=0.50,
            evidence={"session_paste_likelihood": round(paste_likelihood, 4)},
        )
    return None


def _check_rf05(
    l2_output: L2Output, integrity: IntegrityOutput
) -> list[RiskFlag]:
    """RF.05: internal contradiction patterns (RF.05a~RF.05d) → MED, confidence × 0.85."""
    flags: list[RiskFlag] = []
    m = l2_output.metrics

    # RF.05a: high empathy + high hostile
    if m.empathy_rate > 0.20 and m.hostile_rate > 0.15:
        flags.append(RiskFlag(
            rule_id="RF.05a",
            severity="MED",
            value=round(m.empathy_rate + m.hostile_rate, 4),
            threshold=0.35,
            evidence={
                "empathy_rate": round(m.empathy_rate, 4),
                "hostile_rate": round(m.hostile_rate, 4),
            },
        ))

    # RF.05b: high sharing + high disinterest
    if m.sharing_rate > 0.20 and m.disinterest_rate > 0.15:
        flags.append(RiskFlag(
            rule_id="RF.05b",
            severity="MED",
            value=round(m.sharing_rate + m.disinterest_rate, 4),
            threshold=0.35,
            evidence={
                "sharing_rate": round(m.sharing_rate, 4),
                "disinterest_rate": round(m.disinterest_rate, 4),
            },
        ))

    # RF.05c: high feedback_pos + high feedback_neg
    if m.feedback_pos_rate > 0.15 and m.feedback_neg_rate > 0.15:
        flags.append(RiskFlag(
            rule_id="RF.05c",
            severity="MED",
            value=round(m.feedback_pos_rate + m.feedback_neg_rate, 4),
            threshold=0.30,
            evidence={
                "feedback_pos_rate": round(m.feedback_pos_rate, 4),
                "feedback_neg_rate": round(m.feedback_neg_rate, 4),
            },
        ))

    # RF.05d: low trust + high engagement
    ts = integrity.trust_score
    if ts is not None and ts < 0.30 and m.interest_rate > 0.30:
        flags.append(RiskFlag(
            rule_id="RF.05d",
            severity="MED",
            value=round(1.0 - ts, 4),
            threshold=0.70,
            evidence={
                "trust_score": round(ts, 4),
                "interest_rate": round(m.interest_rate, 4),
            },
        ))

    return flags


# ═══════════ NLP-Enhanced Rules (RF.11~RF.14) ═══════════


def _check_rf11(l2_output: L2Output, nlp: NLPAggregate) -> Optional[RiskFlag]:
    """RF.11: fcr high + sharing/interest high → HIGH, confidence × 0.70."""
    m = l2_output.metrics
    fcr = nlp.avg_function_content_ratio
    sharing_interest = m.sharing_rate + m.interest_rate

    if fcr > 0.60 and sharing_interest > 0.40:
        return RiskFlag(
            rule_id="RF.11",
            severity="HIGH",
            value=round(fcr, 4),
            threshold=0.60,
            evidence={
                "avg_function_content_ratio": round(fcr, 4),
                "sharing_rate": round(m.sharing_rate, 4),
                "interest_rate": round(m.interest_rate, 4),
            },
            requires_nlp=True,
        )
    return None


def _check_rf12(nlp: NLPAggregate) -> Optional[RiskFlag]:
    """RF.12: formality std > 0.40 or front/back diff > 0.35 → HIGH, HOLD."""
    formality_std = nlp.formality_variance ** 0.5
    shift = abs(nlp.formality_shift_magnitude)

    if formality_std > 0.40 or shift > 0.35:
        trigger_value = max(formality_std, shift)
        trigger_threshold = 0.40 if formality_std > 0.40 else 0.35
        return RiskFlag(
            rule_id="RF.12",
            severity="HIGH",
            value=round(trigger_value, 4),
            threshold=trigger_threshold,
            evidence={
                "formality_std": round(formality_std, 4),
                "formality_shift_magnitude": round(shift, 4),
            },
            requires_nlp=True,
        )
    return None


def _check_rf13(nlp: NLPAggregate) -> Optional[RiskFlag]:
    """RF.13: proper_noun_consistency < 0.30 → HIGH, HOLD."""
    pnc = nlp.proper_noun_consistency
    if len(nlp.proper_noun_set) > 0 and pnc < 0.30:
        return RiskFlag(
            rule_id="RF.13",
            severity="HIGH",
            value=round(pnc, 4),
            threshold=0.30,
            evidence={
                "proper_noun_consistency": round(pnc, 4),
                "proper_noun_count": len(nlp.proper_noun_set),
            },
            requires_nlp=True,
        )
    return None


def _check_rf14(nlp: NLPAggregate) -> Optional[RiskFlag]:
    """RF.14: oov_ratio spike in specific segments → MED~HIGH, confidence × 0.75."""
    oov = nlp.avg_oov_ratio
    if oov > 0.15:
        severity = "HIGH" if oov > 0.25 else "MED"
        return RiskFlag(
            rule_id="RF.14",
            severity=severity,
            value=round(oov, 4),
            threshold=0.15,
            evidence={"avg_oov_ratio": round(oov, 4)},
            requires_nlp=True,
        )
    return None


# ═══════════ Aggregation ═══════════


def _classify_risk_level(risk_score: float) -> str:
    """Classify risk_score → OK / CAUTION / HIGH / BLOCK."""
    for level, (lo, _hi) in sorted(
        RISK_LEVEL_THRESHOLDS.items(), key=lambda x: -x[1][0]
    ):
        if risk_score >= lo:
            return level
    return "OK"


def _determine_action(risk_level: str, flags: list[RiskFlag]) -> str:
    """Map risk_level + special flags → ALLOW / WARN / HOLD / BLOCK."""
    for f in flags:
        if f.rule_id in _HOLD_RULES:
            return "HOLD"

    if risk_level == "BLOCK":
        return "BLOCK"
    if risk_level == "HIGH":
        return "HOLD"
    if risk_level == "CAUTION":
        return "WARN"
    return "ALLOW"


def compute_risk_flags(
    l2_output: L2Output,
    integrity: IntegrityOutput,
    nlp_aggregate: Optional[NLPAggregate] = None,
) -> RiskReport:
    """Main entry point — aggregate all risk flags into a RiskReport.

    * Base rules RF.01~RF.05 require only L2Output + IntegrityOutput.
    * NLP-enhanced rules RF.11~RF.14 activate only when nlp_aggregate is given.
    * Aggregation: Noisy-OR over severity scores.
    * confidence_multiplier: product of per-rule effects, floor RISK_CONFIDENCE_MIN.
    """
    flags: list[RiskFlag] = []

    # ── Base rules ──
    rf01 = _check_rf01(l2_output)
    if rf01:
        flags.append(rf01)

    rf02 = _check_rf02(l2_output)
    if rf02:
        flags.append(rf02)

    rf03 = _check_rf03(l2_output)
    if rf03:
        flags.append(rf03)

    rf04 = _check_rf04(integrity)
    if rf04:
        flags.append(rf04)

    flags.extend(_check_rf05(l2_output, integrity))

    # ── NLP-enhanced rules ──
    if nlp_aggregate is not None:
        rf11 = _check_rf11(l2_output, nlp_aggregate)
        if rf11:
            flags.append(rf11)

        rf12 = _check_rf12(nlp_aggregate)
        if rf12:
            flags.append(rf12)

        rf13 = _check_rf13(nlp_aggregate)
        if rf13:
            flags.append(rf13)

        rf14 = _check_rf14(nlp_aggregate)
        if rf14:
            flags.append(rf14)

    # ── No flags → clean report ──
    if not flags:
        return RiskReport(
            risk_score=0.0,
            risk_level="OK",
            flags=[],
            confidence_multiplier=1.0,
            action="ALLOW",
        )

    # ── Noisy-OR aggregation ──
    product = 1.0
    for f in flags:
        product *= 1.0 - RISK_SEVERITY_SCORES.get(f.severity, 0.0)
    risk_score = 1.0 - product

    # ── Confidence multiplier ──
    conf_product = 1.0
    for f in flags:
        conf_product *= _CONFIDENCE_EFFECTS.get(f.rule_id, 1.0)
    confidence_multiplier = max(conf_product, RISK_CONFIDENCE_MIN)

    risk_level = _classify_risk_level(risk_score)
    action = _determine_action(risk_level, flags)

    return RiskReport(
        risk_score=round(risk_score, 4),
        risk_level=risk_level,
        flags=flags,
        confidence_multiplier=round(confidence_multiplier, 4),
        action=action,
    )
