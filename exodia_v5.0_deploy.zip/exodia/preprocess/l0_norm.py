"""
L0-Norm: Preprocessing — Normalize + SurfaceFeatures + SpanHints.
100% deterministic. No NLP libraries. No exceptions.
Appendix G implementation (LOCKED).
"""

from __future__ import annotations

import re
from typing import Optional

from exodia.constants import FULLWIDTH_MAP
from exodia.models.outputs import L0NormOutput, SpanHint, SurfaceFeatures


# ═══════════ G.1 Normalization Pipeline (order LOCKED) ═══════════

def normalize(raw_text: str) -> str:
    """L0 normalization. 7-step pipeline, order change forbidden."""
    text = raw_text

    # Step 1: Remove control chars / zero-width
    text = re.sub(
        r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f\u200b-\u200f\u2028-\u202f\ufeff]",
        "",
        text,
    )

    # Step 2: Fullwidth punctuation → halfwidth
    text = text.translate(FULLWIDTH_MAP)

    # Step 3: URL → [URL]
    text = re.sub(r"https?://\S+", "[URL]", text)

    # Step 4: Code blocks → [CODE]
    text = re.sub(r"```[\s\S]*?```", "[CODE]", text)
    text = re.sub(r"`[^`]+`", "[CODE]", text)

    # Step 5: Korean jamo 3+ → 2 (ㅋㅋㅋㅋ → ㅋㅋ)
    text = re.sub(r"([ㄱ-ㅎㅏ-ㅣ])\1{2,}", r"\1\1", text)

    # Step 6: Same char 4+ → 3 (!!!! → !!!)
    text = re.sub(r"(.)\1{3,}", r"\1\1\1", text)

    # Step 7: Collapse whitespace → single space, strip
    text = re.sub(r"\s+", " ", text).strip()

    return text


# ═══════════ G.2 SurfaceFeatures 20 fields ═══════════

def extract_surface_features(normalized_text: str) -> SurfaceFeatures:
    """Extract 20 surface features from normalized text."""
    t = normalized_text

    char_count = len(t)
    words = t.split() if t else []
    word_count = len(words)

    sentence_markers = re.findall(r"[.?!]+", t)
    sentence_count = len(sentence_markers) if sentence_markers else (1 if t.strip() else 0)

    question_mark_count = t.count("?")
    exclamation_count = t.count("!")
    ellipsis_present = "..." in t or "\u2026" in t
    multi_punctuation = bool(re.search(r"[?!.]{2,}", t))

    ko_laugh_count = len(re.findall(r"[ㅋㅎ]{2}", t))
    ko_cry_count = len(re.findall(r"[ㅠㅜ]{2}", t))
    ko_abbrev_present = bool(re.search(r"^[ㄱ-ㅎ]{2,4}$", t.strip())) if t.strip() else False
    ko_profanity_present = bool(
        re.search(r"ㅅㅂ|ㅁㅊ|ㅂㅅ|ㅈㄹ|씨발|시발|개새|미친", t)
    )
    ko_honorific_ending = bool(
        re.search(r"(요|습니다|세요|십시오|시죠)\s*[.?!]*$", t)
    )
    ko_casual_ending = bool(
        re.search(r"(임|음|ㅇㅇ|ㄴㄴ|ㄱㄱ|함|됨)\s*[.?!]*$", t)
    )

    upper_count = sum(1 for c in t if c.isupper())
    all_caps_ratio = upper_count / max(1, len(t))
    has_url = "[URL]" in t
    has_code = "[CODE]" in t
    emoji_count = len(re.findall(r"[\U0001F300-\U0001F9FF]", t))

    is_single_token = word_count == 1
    is_very_short = char_count <= 5
    is_empty_after_norm = len(t.strip()) == 0

    return SurfaceFeatures(
        char_count=char_count,
        word_count=word_count,
        sentence_count=sentence_count,
        question_mark_count=question_mark_count,
        exclamation_count=exclamation_count,
        ellipsis_present=ellipsis_present,
        multi_punctuation=multi_punctuation,
        ko_laugh_count=ko_laugh_count,
        ko_cry_count=ko_cry_count,
        ko_abbrev_present=ko_abbrev_present,
        ko_profanity_present=ko_profanity_present,
        ko_honorific_ending=ko_honorific_ending,
        ko_casual_ending=ko_casual_ending,
        all_caps_ratio=all_caps_ratio,
        has_url=has_url,
        has_code=has_code,
        emoji_count=emoji_count,
        is_single_token=is_single_token,
        is_very_short=is_very_short,
        is_empty_after_norm=is_empty_after_norm,
    )


# ═══════════ G.3 SpanHint 8 types ═══════════

SPAN_PATTERNS = {
    "QUESTION": r"[?？]|뭐야|왜|어떻게|언제|어디|누가|몇|뭘|뭘까",
    "PROFANITY": r"ㅅㅂ|ㅁㅊ|ㅂㅅ|ㅈㄹ|씨발|시발|개새끼|미친놈|미친년|병신|지랄",
    "COMMAND": r"해라|하세요|해줘|해주세요|하십시오|해봐|해주라|하거라",
    "NEGATION": r"아니[야요]?|ㄴㄴ|안 |못 |없[어다]|말[아아라]|하지 ?마",
    "AFFIRMATION": r"ㅇㅇ|ㅇㅋ|ㄱㄱ|맞[아다]|그래|그렇[지다]|응|네|넵|예",
    "GREETING": r"안녕|하이|헬로|반갑|좋은 아침|좋은 저녁|잘 가|바이|수고",
    "THANKS": r"고마[워운]|감사|ㄱㅅ|땡큐|쌩유|thank",
    "APOLOGY": r"미안|죄송|사과|sorry|ㅁㅇ",
}


def extract_span_hints(normalized_text: str) -> list[SpanHint]:
    """Extract span hints for 8 types using regex pattern matching."""
    hints: list[SpanHint] = []
    for hint_type, pattern in SPAN_PATTERNS.items():
        for m in re.finditer(pattern, normalized_text, re.IGNORECASE):
            hints.append(
                SpanHint(
                    hint_type=hint_type,
                    span_start=m.start(),
                    span_end=m.end(),
                    matched_text=m.group(),
                )
            )
    return hints


# ═══════════ L0 Processor ═══════════

def process_l0_norm(
    turn_id: str,
    raw_text: str,
    metadata: Optional[dict] = None,
) -> L0NormOutput:
    """
    Process a single turn through L0-Norm.
    Never raises exceptions. Empty input → empty output.
    """
    try:
        normalized = normalize(raw_text)
        features = extract_surface_features(normalized)
        hints = extract_span_hints(normalized)
        is_empty = len(normalized.strip()) == 0

        return L0NormOutput(
            turn_id=turn_id,
            raw_text=raw_text,
            normalized_text=normalized,
            surface_features=features,
            span_hints=hints,
            is_empty_after_norm=is_empty,
            metadata=metadata,
        )
    except Exception:
        return L0NormOutput(
            turn_id=turn_id,
            raw_text=raw_text,
            normalized_text="",
            surface_features=SurfaceFeatures(is_empty_after_norm=True),
            span_hints=[],
            is_empty_after_norm=True,
            metadata=metadata,
        )
