"""
EXODIA v4.0 — LSM Engine (Language Style Matching).
순수 Python. LLM 금지. 결정론적.
구현 기준: v4.0 Spec Section 12.

LSM은 기능어(function words) 사용 패턴의 유사도를 측정한다.
Ireland et al. (2011) 기반. 9개 카테고리.
"""
from __future__ import annotations

from typing import Optional

from exodia.constants import LSM_EPSILON, LSM_CATEGORIES, LSM_CATEGORY_COUNT
from exodia.models.outputs import LSMFeatures, MorphologyOutput, PragmaticsOutput


class LSMEngine:
    """LSM 엔진 — 기능어 패턴 유사도 계산.

    Pipeline에서 두 가지 방식으로 사용:
    1. extract_rates(): 단일 세션의 기능어 rate 추출 (SessionProfile에 저장)
    2. compute_similarity(): 두 세션의 rate를 비교하여 LSM score 산출

    Spec Section 12.4:
        LSM_category_k = 1 - |rate_A_k - rate_B_k| / (rate_A_k + rate_B_k + LSM_EPSILON)
        LSM_score = mean([LSM_category_k for k in 1..9])
        Friction_LSM = 1 - LSM_score
    """

    def extract_rates(
        self,
        morphology_outputs: list[MorphologyOutput],
        pragmatics_outputs: list[PragmaticsOutput],
    ) -> LSMFeatures:
        """단일 세션의 기능어 카테고리 rate 추출.

        Spec Section 12.5: rate_k = count(tokens in category_k) / total_token_count
        L0 Morphology의 POS tagging + L2 Pragmatics 사용.

        Args:
            morphology_outputs: 세션 내 모든 턴의 L0 Morphology 출력
            pragmatics_outputs: 세션 내 모든 턴의 L2 Pragmatics 출력

        Returns:
            LSMFeatures with category_rates populated
        """
        if not morphology_outputs:
            return LSMFeatures()

        # POS distribution 집계 (전체 세션)
        total_tokens = 0
        aggregated_pos: dict[str, float] = {}

        for morph in morphology_outputs:
            n_tokens = morph.token_count
            total_tokens += n_tokens
            for pos, ratio in morph.pos_distribution.items():
                count_approx = ratio * n_tokens
                aggregated_pos[pos] = aggregated_pos.get(pos, 0.0) + count_approx

        if total_tokens == 0:
            return LSMFeatures()

        # 카테고리별 rate 추출
        # POS 매핑 (Mecab-Ko POS tags → LSM categories)
        # Reference: Spec Section 12.3
        category_rates: dict[str, float] = {}

        # 1. Pronouns (대명사) — NP (대명사)
        category_rates["pronouns"] = aggregated_pos.get("NP", 0.0) / total_tokens

        # 2. Articles (조사/관형사) — JKS, JKC, JKG, JKO, JKB, JKV, JKQ, JX, JC, MM
        articles_tags = ["JKS", "JKC", "JKG", "JKO", "JKB", "JKV", "JKQ", "JX", "JC", "MM"]
        articles_count = sum(aggregated_pos.get(tag, 0.0) for tag in articles_tags)
        category_rates["articles"] = articles_count / total_tokens

        # 3. Prepositions (부사) — MAG, MAJ
        prep_tags = ["MAG", "MAJ"]
        prep_count = sum(aggregated_pos.get(tag, 0.0) for tag in prep_tags)
        category_rates["prepositions"] = prep_count / total_tokens

        # 4. Auxiliary verbs (보조용언) — VX
        category_rates["auxiliary_verbs"] = aggregated_pos.get("VX", 0.0) / total_tokens

        # 5. Negations (부정 표현) — count from pragmatics negation_type
        negation_count = sum(
            1.0 for p in pragmatics_outputs
            if p.negation_type in ("short", "long", "both")
        )
        category_rates["negations"] = negation_count / max(len(pragmatics_outputs), 1)

        # 6. Conjunctions (접속사) — MAJ
        category_rates["conjunctions"] = aggregated_pos.get("MAJ", 0.0) / total_tokens

        # 7. Quantifiers (수량사) — NR (수사), SN (숫자)
        quant_tags = ["NR", "SN"]
        quant_count = sum(aggregated_pos.get(tag, 0.0) for tag in quant_tags)
        category_rates["quantifiers"] = quant_count / total_tokens

        # 8. Interjections (감탄사) — IC
        category_rates["interjections"] = aggregated_pos.get("IC", 0.0) / total_tokens

        # 9. Formality (경어/반말 비율) — from pragmatics formality_level
        formality_values = [
            p.formality_level for p in pragmatics_outputs
            if p.formality_level is not None
        ]
        category_rates["formality"] = (
            sum(formality_values) / len(formality_values)
            if formality_values else 0.5  # neutral default
        )

        return LSMFeatures(
            category_rates=category_rates,
            lsm_score=0.0,  # score는 comparison 시 산출
            friction_lsm=0.0,
        )

    def compute_similarity(
        self,
        features_a: LSMFeatures,
        features_b: LSMFeatures,
    ) -> LSMFeatures:
        """두 세션의 LSM 유사도 계산.

        Spec Section 12.4:
            LSM_category_k = 1 - |rate_A_k - rate_B_k| / (rate_A_k + rate_B_k + LSM_EPSILON)
            LSM_score = mean([LSM_category_k for k in categories])
            Friction_LSM = 1 - LSM_score

        Returns:
            LSMFeatures with category_similarities, lsm_score, friction_lsm populated
        """
        rates_a = features_a.category_rates
        rates_b = features_b.category_rates

        if not rates_a or not rates_b:
            return LSMFeatures(lsm_score=0.5, friction_lsm=0.5)

        category_similarities: dict[str, float] = {}
        valid_similarities: list[float] = []

        for category in LSM_CATEGORIES:
            rate_a = rates_a.get(category, 0.0)
            rate_b = rates_b.get(category, 0.0)

            # Spec formula: 1 - |rate_A - rate_B| / (rate_A + rate_B + EPSILON)
            similarity = 1.0 - abs(rate_a - rate_b) / (rate_a + rate_b + LSM_EPSILON)
            similarity = max(0.0, min(1.0, similarity))

            category_similarities[category] = similarity
            valid_similarities.append(similarity)

        # Overall LSM score = mean of all category similarities
        lsm_score = (
            sum(valid_similarities) / len(valid_similarities)
            if valid_similarities else 0.0
        )
        friction_lsm = 1.0 - lsm_score

        return LSMFeatures(
            category_rates={},  # comparison output에서는 rates 미포함
            category_similarities=category_similarities,
            lsm_score=lsm_score,
            friction_lsm=friction_lsm,
        )

    def compute_single_session_lsm(
        self,
        features: LSMFeatures,
    ) -> float:
        """단일 세션의 LSM score 반환 (UserProfile 저장용).

        단독 세션에서는 comparison이 없으므로 rate 기반 대표값 반환.
        이 값은 나중에 다른 유저와 비교 시 사용됨.
        """
        if not features.category_rates:
            return 0.0
        # 단일 세션의 "자기 기능어 밀도" — rate 평균값 저장
        rates = list(features.category_rates.values())
        return sum(rates) / len(rates) if rates else 0.0
