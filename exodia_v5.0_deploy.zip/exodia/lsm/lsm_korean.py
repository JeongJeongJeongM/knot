"""
EXODIA v5.0 — Korean-optimized LSM Engine.
12 categories: 9 base (fixed) + 3 new (EF, EC, emotional markers).
Deterministic. No LLM.
"""
from __future__ import annotations

from typing import Optional
import math
from exodia.constants import LSM_EPSILON
from exodia.models.outputs import LSMFeatures, MorphologyOutput, PragmaticsOutput

# v5.0 Korean LSM Categories (12)
KOREAN_LSM_CATEGORIES = [
    "pronouns",              # 1. NP
    "particles",             # 2. JK* (renamed from "articles")
    "adverbs",               # 3. MAG only (MAJ removed — was double-mapped)
    "auxiliary_verbs",       # 4. VX
    "negations",             # 5. pragmatics negation patterns
    "conjunctions",          # 6. MAJ only (separated from adverbs)
    "quantifiers",           # 7. NR, SN
    "interjections",         # 8. IC
    "formality",             # 9. L2 formality_level
    "sentence_endings",      # 10. [NEW] EF — 종결어미
    "connective_endings",    # 11. [NEW] EC — 연결어미
    "emotional_markers",     # 12. [NEW] ㅋㅋ, ㅠㅠ, emoji
]
KOREAN_LSM_CATEGORY_COUNT = 12

# Categories that use rate-based similarity (standard LSM formula)
RATE_BASED_CATEGORIES = [
    "pronouns", "particles", "adverbs", "auxiliary_verbs", "negations",
    "conjunctions", "quantifiers", "interjections", "formality", "emotional_markers",
]

# Categories that use distribution-based similarity (JSD)
DISTRIBUTION_BASED_CATEGORIES = [
    "sentence_endings", "connective_endings",
]


class KoreanLSMEngine:
    """Korean-optimized LSM Engine (v5.0).

    Changes from v4.0 LSMEngine:
    - 9 → 12 categories
    - "articles" → "particles" (linguistically accurate)
    - MAJ no longer double-mapped (removed from adverbs)
    - New: EF (sentence_endings), EC (connective_endings), emotional_markers
    - Distribution-based similarity for EF/EC (JSD instead of rate diff)
    """

    def extract_rates(
        self,
        morphology_outputs: list[MorphologyOutput],
        pragmatics_outputs: list[PragmaticsOutput],
    ) -> LSMFeatures:
        """Extract 12 category rates from a single session."""
        if not morphology_outputs:
            return LSMFeatures()

        # Aggregate POS distribution across all turns
        total_tokens = 0
        aggregated_pos: dict[str, float] = {}

        for morph in morphology_outputs:
            n_tokens = morph.token_count
            total_tokens += n_tokens
            for pos, ratio in morph.pos_distribution.items():
                count_approx = ratio * n_tokens
                aggregated_pos[pos] = aggregated_pos.get(pos, 0.0) + count_approx

        if total_tokens == 0:
            return LSMFeatures()

        category_rates: dict[str, float] = {}

        # 1. Pronouns — NP
        category_rates["pronouns"] = aggregated_pos.get("NP", 0.0) / total_tokens

        # 2. Particles (was "articles") — JK* tags only (no JX, JC, MM)
        particle_tags = ["JKS", "JKC", "JKG", "JKO", "JKB", "JKV", "JKQ"]
        particle_count = sum(aggregated_pos.get(tag, 0.0) for tag in particle_tags)
        category_rates["particles"] = particle_count / total_tokens

        # 3. Adverbs — MAG only (MAJ removed — v5.0 fix)
        category_rates["adverbs"] = aggregated_pos.get("MAG", 0.0) / total_tokens

        # 4. Auxiliary Verbs — VX
        category_rates["auxiliary_verbs"] = aggregated_pos.get("VX", 0.0) / total_tokens

        # 5. Negations — from pragmatics (turn-based, normalized)
        negation_count = sum(
            1.0 for p in pragmatics_outputs
            if p.negation_type in ("short", "long", "both")
        )
        # Normalize: negation_count / total_turns, scaled to be comparable with token rates
        n_turns = max(len(pragmatics_outputs), 1)
        category_rates["negations"] = negation_count / n_turns

        # 6. Conjunctions — MAJ only (separated from adverbs)
        category_rates["conjunctions"] = aggregated_pos.get("MAJ", 0.0) / total_tokens

        # 7. Quantifiers — NR + SN
        quant_tags = ["NR", "SN"]
        quant_count = sum(aggregated_pos.get(tag, 0.0) for tag in quant_tags)
        category_rates["quantifiers"] = quant_count / total_tokens

        # 8. Interjections — IC
        category_rates["interjections"] = aggregated_pos.get("IC", 0.0) / total_tokens

        # 9. Formality — from pragmatics formality_level
        formality_values = [
            p.formality_level for p in pragmatics_outputs
            if p.formality_level is not None
        ]
        category_rates["formality"] = (
            sum(formality_values) / len(formality_values)
            if formality_values else 0.5
        )

        # 10. Sentence Endings (EF) — distribution
        ef_dist = self._extract_ef_distribution(aggregated_pos, total_tokens)
        category_rates["sentence_endings"] = sum(ef_dist.values())  # total rate
        # Store distribution separately for JSD computation

        # 11. Connective Endings (EC) — distribution
        ec_dist = self._extract_ec_distribution(aggregated_pos, total_tokens)
        category_rates["connective_endings"] = sum(ec_dist.values())  # total rate

        # 12. Emotional Markers — ㅋㅋ, ㅠㅠ, emoji from surface features
        emotional_count = self._count_emotional_markers(morphology_outputs)
        category_rates["emotional_markers"] = emotional_count / total_tokens

        return LSMFeatures(
            category_rates=category_rates,
            category_distributions={
                "sentence_endings": ef_dist,
                "connective_endings": ec_dist,
            },
            lsm_score=0.0,
            friction_lsm=0.0,
        )

    def compute_similarity(
        self,
        features_a: LSMFeatures,
        features_b: LSMFeatures,
    ) -> LSMFeatures:
        """Compute 12-category LSM similarity between two sessions."""
        rates_a = features_a.category_rates
        rates_b = features_b.category_rates

        if not rates_a or not rates_b:
            return LSMFeatures(lsm_score=0.5, friction_lsm=0.5)

        category_similarities: dict[str, float] = {}
        valid_similarities: list[float] = []

        # Rate-based categories (standard LSM formula)
        for category in RATE_BASED_CATEGORIES:
            rate_a = rates_a.get(category, 0.0)
            rate_b = rates_b.get(category, 0.0)
            similarity = 1.0 - abs(rate_a - rate_b) / (rate_a + rate_b + LSM_EPSILON)
            similarity = max(0.0, min(1.0, similarity))
            category_similarities[category] = similarity
            valid_similarities.append(similarity)

        # Distribution-based categories (JSD)
        dist_a = features_a.category_distributions or {}
        dist_b = features_b.category_distributions or {}

        for category in DISTRIBUTION_BASED_CATEGORIES:
            da = dist_a.get(category, {})
            db = dist_b.get(category, {})
            if da and db:
                jsd = self._jsd_sqrt(da, db)
                similarity = max(0.0, 1.0 - jsd)
            else:
                similarity = 0.5  # no data → neutral
            category_similarities[category] = similarity
            valid_similarities.append(similarity)

        lsm_score = (
            sum(valid_similarities) / len(valid_similarities)
            if valid_similarities else 0.0
        )
        friction_lsm = 1.0 - lsm_score

        return LSMFeatures(
            category_similarities=category_similarities,
            lsm_score=lsm_score,
            friction_lsm=friction_lsm,
        )

    def compute_single_session_lsm(self, features: LSMFeatures) -> float:
        """Single session LSM representative value (for UserProfile storage)."""
        if not features.category_rates:
            return 0.0
        rates = list(features.category_rates.values())
        return sum(rates) / len(rates) if rates else 0.0

    # ─── Private helpers ───

    def _extract_ef_distribution(
        self, aggregated_pos: dict[str, float], total_tokens: int
    ) -> dict[str, float]:
        """Extract sentence-final ending (EF) distribution.

        Since Mecab-Ko groups all sentence-final endings under 'EF',
        we use the total EF count and create a simplified distribution.
        In Phase 2, this will be expanded with sub-type classification.
        """
        ef_count = aggregated_pos.get("EF", 0.0)
        if total_tokens == 0 or ef_count == 0:
            return {"declarative": 0.0, "interrogative": 0.0, "imperative": 0.0, "exclamatory": 0.0}

        # Phase 1: uniform distribution assumption (to be refined with data)
        ef_rate = ef_count / total_tokens
        return {
            "declarative": ef_rate * 0.5,   # estimated majority
            "interrogative": ef_rate * 0.25,
            "imperative": ef_rate * 0.15,
            "exclamatory": ef_rate * 0.10,
        }

    def _extract_ec_distribution(
        self, aggregated_pos: dict[str, float], total_tokens: int
    ) -> dict[str, float]:
        """Extract connective ending (EC) distribution.

        Phase 1: simplified distribution from total EC count.
        """
        ec_count = aggregated_pos.get("EC", 0.0)
        if total_tokens == 0 or ec_count == 0:
            return {"causal": 0.0, "contrastive": 0.0, "concessive": 0.0, "selective": 0.0}

        ec_rate = ec_count / total_tokens
        return {
            "causal": ec_rate * 0.35,
            "contrastive": ec_rate * 0.30,
            "concessive": ec_rate * 0.20,
            "selective": ec_rate * 0.15,
        }

    def _count_emotional_markers(
        self, morphology_outputs: list[MorphologyOutput]
    ) -> float:
        """Count emotional markers (laugh, cry, emoji).

        Uses IC (interjections) + emoji_density as proxy.
        In Phase 2, dedicated ㅋㅋ/ㅠㅠ detection will be added.
        """
        total = 0.0
        for morph in morphology_outputs:
            # emoji_density is already a ratio, convert to count approx
            total += morph.emoji_density * morph.token_count
            # IC tokens that are emotional (ㅋ, ㅎ, ㅠ, ㅜ counted in repetition_score)
            total += morph.repetition_score * morph.token_count * 0.5
        return total

    @staticmethod
    def _jsd_sqrt(p: dict[str, float], q: dict[str, float]) -> float:
        """Square root of Jensen-Shannon Divergence, range [0, 1]."""
        all_keys = set(p.keys()) | set(q.keys())
        if not all_keys:
            return 0.0

        eps = 1e-12
        jsd = 0.0

        for key in all_keys:
            p_val = max(p.get(key, 0.0), eps)
            q_val = max(q.get(key, 0.0), eps)
            m_val = (p_val + q_val) / 2.0

            if p_val > eps:
                jsd += 0.5 * p_val * math.log(p_val / m_val)
            if q_val > eps:
                jsd += 0.5 * q_val * math.log(q_val / m_val)

        return max(0.0, min(1.0, math.sqrt(max(0.0, jsd))))
