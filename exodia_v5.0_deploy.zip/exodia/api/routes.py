"""EXODIA v3.0 — FastAPI Routes.

Endpoints:
  POST /analyze          — single session → Profile
  POST /analyze/batch    — multiple sessions → list[Profile]
  POST /compare          — two profiles → L5Output
  POST /consistency      — multi-session → ConsistencyOutput
  GET  /health           — liveness probe
  GET  /version          — engine version info
"""

from __future__ import annotations

import logging
import os
from typing import Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from exodia import __version__
from exodia.api.pipeline import ExodiaPipeline
from exodia.labeling.l25_worker import ClaudeClient
from exodia.models.inputs import ConversationSession
from exodia.models.outputs import (
    ConsistencyOutput,
    EngineError,
    L1Output,
    L2Output,
    L5Output,
    Profile,
    SessionProfile,
    UserProfile,
)

logger = logging.getLogger(__name__)

app = FastAPI(
    title="EXODIA Engine",
    version=__version__,
    description="Behavioral Analysis Engine for Compatibility Matching — v3.0",
)


def _create_default_pipeline() -> ExodiaPipeline:
    """환경변수에서 API 키를 읽어 LLM 클라이언트 주입."""
    api_key = os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("LLM_API_KEY")
    allow_no_llm = os.environ.get("EXODIA_ALLOW_NO_LLM", "0") == "1"
    model = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-20250514")

    llm_client = None
    if api_key:
        llm_client = ClaudeClient(api_key=api_key, model_id=model)
        logger.info("LLM client initialized from environment")
    elif allow_no_llm:
        logger.warning(
            "No LLM API key found. EXODIA_ALLOW_NO_LLM=1 이므로 "
            "L2.5가 전 턴 UNKNOWN을 반환합니다. 개발/테스트 전용."
        )
    else:
        raise RuntimeError(
            "LLM API key required. Set ANTHROPIC_API_KEY or LLM_API_KEY. "
            "For dev/test without LLM, set EXODIA_ALLOW_NO_LLM=1."
        )
    return ExodiaPipeline(llm_client=llm_client)


_pipeline = _create_default_pipeline()


def set_pipeline(pipeline: ExodiaPipeline) -> None:
    """Replace the global pipeline (for DI in tests / startup)."""
    global _pipeline
    _pipeline = pipeline


# ═══════════ Request / Response schemas ═══════════


class AnalyzeRequest(BaseModel):
    session: ConversationSession
    purpose_distribution: Optional[dict[str, float]] = None


class BatchAnalyzeRequest(BaseModel):
    sessions: list[ConversationSession]
    purpose_distributions: Optional[list[dict[str, float]]] = None


class CompareRequest(BaseModel):
    profile_a: UserProfile
    profile_b: UserProfile


class ConsistencyRequest(BaseModel):
    user_id: str
    session_profiles: list[SessionProfile]
    l2_outputs: list[L2Output]
    all_l1_outputs: list[list[L1Output]]


class HealthResponse(BaseModel):
    status: str = "ok"
    engine_version: str = __version__


class VersionResponse(BaseModel):
    engine_version: str = __version__
    spec_version: str = "3.2.0"


# ═══════════ Endpoints ═══════════


@app.get("/health", response_model=HealthResponse)
def health():
    return HealthResponse()


@app.get("/version", response_model=VersionResponse)
def version():
    return VersionResponse()


@app.post("/analyze")
def analyze(req: AnalyzeRequest) -> Profile | EngineError:
    result = _pipeline.run_session(
        session=req.session,
        purpose_distribution=req.purpose_distribution,
    )
    if isinstance(result, EngineError):
        raise HTTPException(status_code=422, detail=result.model_dump())
    return result


@app.post("/analyze/batch")
def analyze_batch(req: BatchAnalyzeRequest) -> list[Profile | EngineError]:
    return _pipeline.run_full(
        sessions=req.sessions,
        purpose_distributions=req.purpose_distributions,
    )


@app.post("/compare")
def compare(req: CompareRequest) -> L5Output | EngineError:
    result = _pipeline.run_comparison(req.profile_a, req.profile_b)
    if isinstance(result, EngineError):
        raise HTTPException(status_code=422, detail=result.model_dump())
    return result


@app.post("/consistency")
def consistency(req: ConsistencyRequest) -> ConsistencyOutput:
    return _pipeline.run_consistency(
        user_id=req.user_id,
        session_profiles=req.session_profiles,
        l2_outputs=req.l2_outputs,
        all_l1_outputs=req.all_l1_outputs,
    )
