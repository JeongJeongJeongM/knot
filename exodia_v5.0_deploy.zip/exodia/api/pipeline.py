"""EXODIA v3.0 — Pipeline Orchestrator.

Wires all layers (L0-Norm → NLP Kernel → L2.5 → L3 → Integrity → Risk →
NLPAggregate → L4 → L5 → L6 → L3.5) into a coherent execution graph.

Single session analysis:  run_session()
Two-profile comparison:   run_comparison()
Multi-session consistency: run_consistency()
Full pipeline:            run_full()
"""

from __future__ import annotations

import hashlib
import logging
from datetime import datetime, timezone
from typing import Optional

from exodia.comparison.l6_compare import MatchingBlockedError, compute_l5_comparison
from exodia.consistency.l35_audit import compute_consistency
from exodia.constants import MAX_TURNS_PER_SESSION, MIN_TURNS_FOR_ANALYSIS, VALID_SPEAKERS
from exodia.integrity.gate import compute_integrity
from exodia.integrity.risk_flags import compute_risk_flags
from exodia.kernel.aggregate import compute_nlp_aggregate
from exodia.kernel.l0_morphology import process_morphology
from exodia.kernel.l1_syntax import process_syntax
from exodia.kernel.l2_pragmatics import process_pragmatics
from exodia.labeling.l25_worker import InMemoryCache, L25Worker, LLMClient
from exodia.models.inputs import ConversationSession
from exodia.models.outputs import (
    EngineError,
    IntegrityOutput,
    L0NormOutput,
    L1Output,
    L2Output,
    L3Output,
    L4Output,
    L5Output,
    MorphologyOutput,
    NLPAggregate,
    PipelineMetadata,
    PragmaticsOutput,
    Profile,
    RiskReport,
    SessionProfile,
    SyntaxOutput,
    UserProfile,
)
from exodia.preprocess.l0_norm import process_l0_norm
from exodia.projection.l5_projection import compute_l4_projection
from exodia.stats.l3_stats import compute_l2
from exodia.synthesis.l4_synthesis import compute_l3_synthesis

logger = logging.getLogger(__name__)


def _preprocess_turns(session: ConversationSession) -> list:
    """E-04: 최근 1000턴 트렁케이트, E-05: VALID_SPEAKERS만 유지."""
    filtered = [
        t for t in session.turns
        if t.metadata is not None and t.metadata.speaker in VALID_SPEAKERS
    ]
    if len(filtered) > MAX_TURNS_PER_SESSION:
        filtered = filtered[-MAX_TURNS_PER_SESSION:]
    return filtered


def _input_hash(session: ConversationSession) -> str:
    raw = f"{session.session_id}:{len(session.turns)}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def _now() -> datetime:
    return datetime.now(timezone.utc)


class ExodiaPipeline:
    """Stateful pipeline with injectable LLM client and cache backends."""

    def __init__(
        self,
        llm_client: Optional[LLMClient] = None,
        redis_cache=None,
        postgres_cache=None,
    ) -> None:
        self._l25_worker: Optional[L25Worker] = None
        if llm_client is not None:
            self._l25_worker = L25Worker(
                llm_client,
                redis_cache=redis_cache,
                postgres_cache=postgres_cache,
            )

    # ─────────────────────────────────────────────
    # Stage 1 — L0-Norm  (deterministic)
    # ─────────────────────────────────────────────

    @staticmethod
    def _run_l0_norm(turns: list) -> list[L0NormOutput]:
        return [
            process_l0_norm(
                turn_id=t.turn_id,
                raw_text=t.raw_text,
                metadata=t.metadata.model_dump() if t.metadata else None,
            )
            for t in turns
        ]

    # ─────────────────────────────────────────────
    # Stage 2 — NLP Kernel  (deterministic)
    # ─────────────────────────────────────────────

    @staticmethod
    def _run_nlp_kernel(
        l0_outputs: list[L0NormOutput],
    ) -> tuple[list[MorphologyOutput], list[SyntaxOutput], list[PragmaticsOutput]]:
        morphs: list[MorphologyOutput] = []
        syntaxes: list[SyntaxOutput] = []
        pragmatics: list[PragmaticsOutput] = []

        for l0 in l0_outputs:
            text = l0.normalized_text
            m = process_morphology(text)
            s = process_syntax(text)
            p = process_pragmatics(text, morph=m, syntax=s)
            morphs.append(m)
            syntaxes.append(s)
            pragmatics.append(p)

        return morphs, syntaxes, pragmatics

    # ─────────────────────────────────────────────
    # Stage 3 — L2.5 Labeling  (LLM, cached)
    # ─────────────────────────────────────────────

    def _run_l25(self, l0_outputs: list[L0NormOutput]) -> list[L1Output]:
        if self._l25_worker is None:
            return [
                L1Output(turn_id=l0.turn_id, primary_id=0, primary_label="UNKNOWN")
                for l0 in l0_outputs
            ]
        return [self._l25_worker.process_l25(l0) for l0 in l0_outputs]

    # ─────────────────────────────────────────────
    # Stage 4 — L3 Stats  (deterministic)
    # ─────────────────────────────────────────────

    @staticmethod
    def _run_l3_stats(
        session_id: str,
        l1_outputs: list[L1Output],
        turns: list,
    ) -> L2Output:
        speakers = [t.metadata.speaker for t in turns]
        latencies = [
            float(t.metadata.reply_latency_ms)
            if t.metadata.reply_latency_ms is not None
            else None
            for t in turns
        ]
        return compute_l2(
            session_id=session_id,
            l1_outputs=l1_outputs,
            speakers=speakers,
            reply_latencies_ms=latencies,
        )

    # ─────────────────────────────────────────────
    # Stage 5 — Integrity + Risk  (deterministic)
    # ─────────────────────────────────────────────

    @staticmethod
    def _run_integrity(
        l2_output: L2Output,
        client_signals,
        turn_count: int,
    ) -> IntegrityOutput:
        return compute_integrity(
            l2_output=l2_output,
            client_signals=client_signals,
            turn_count=turn_count,
        )

    @staticmethod
    def _run_risk_flags(
        l2_output: L2Output,
        integrity: IntegrityOutput,
        nlp_agg: Optional[NLPAggregate],
    ) -> RiskReport:
        return compute_risk_flags(
            l2_output=l2_output,
            integrity=integrity,
            nlp_aggregate=nlp_agg,
        )

    # ─────────────────────────────────────────────
    # Single session analysis
    # ─────────────────────────────────────────────

    def run_session(
        self,
        session: ConversationSession,
        purpose_distribution: Optional[dict[str, float]] = None,
    ) -> Profile | EngineError:
        """Full single-session pipeline → Profile."""
        try:
            valid_turns = _preprocess_turns(session)
            turn_count = len(valid_turns)
            filtered_hash = hashlib.sha256(
                f"{session.session_id}:{turn_count}".encode()
            ).hexdigest()[:16]

            if turn_count < MIN_TURNS_FOR_ANALYSIS:
                return EngineError(
                    error_code="INSUFFICIENT_TURNS",
                    error_stage="VALIDATION",
                    message=f"Need >= {MIN_TURNS_FOR_ANALYSIS} valid turns, got {turn_count}",
                    input_hash=filtered_hash,
                )

            l0_outputs = self._run_l0_norm(valid_turns)
            morphs, syntaxes, pragmatics_list = self._run_nlp_kernel(l0_outputs)
            l1_outputs = self._run_l25(l0_outputs)
            l2_output = self._run_l3_stats(session.session_id, l1_outputs, valid_turns)

            nlp_agg = compute_nlp_aggregate(morphs, syntaxes, pragmatics_list)

            integrity = self._run_integrity(l2_output, session.client_signals, turn_count)
            risk_report = self._run_risk_flags(l2_output, integrity, nlp_agg)

            l3_output = compute_l3_synthesis(
                session_id=session.session_id,
                l2_output=l2_output,
                nlp_aggregate=nlp_agg,
                risk_report=risk_report,
                turn_count=turn_count,
            )

            if l3_output.status == "BLOCKED":
                l4_output = None
            else:
                l4_output = compute_l4_projection(
                    session_id=session.session_id,
                    l3_output=l3_output,
                    purpose_distribution=purpose_distribution or {},
                )

            return Profile(
                session_id=session.session_id,
                user_id=session.user_id,
                l2=l2_output,
                l3=l3_output,
                l4=l4_output,
                integrity=integrity,
                risk_report=risk_report,
                nlp_aggregate=nlp_agg,
                metadata=PipelineMetadata(
                    input_hash=filtered_hash,
                    computed_at=_now(),
                ),
            )
        except Exception as exc:
            logger.exception("Pipeline error for session=%s", session.session_id)
            return EngineError(
                error_code="COMPUTATION_ERROR",
                error_stage="PIPELINE",
                message=str(exc),
                input_hash=_input_hash(session),
            )

    # ─────────────────────────────────────────────
    # Two-profile comparison
    # ─────────────────────────────────────────────

    def run_comparison(
        self,
        profile_a: Profile | UserProfile,
        profile_b: Profile | UserProfile,
    ) -> L5Output | EngineError:
        """Compare two profiles → L5Output."""
        try:
            return compute_l5_comparison(profile_a, profile_b)
        except MatchingBlockedError as exc:
            return EngineError(
                error_code="INVARIANT_VIOLATION",
                error_stage="L6_COMPARISON",
                message=str(exc),
            )
        except Exception as exc:
            logger.exception("Comparison error")
            return EngineError(
                error_code="COMPUTATION_ERROR",
                error_stage="L6_COMPARISON",
                message=str(exc),
            )

    # ─────────────────────────────────────────────
    # Multi-session consistency (L3.5)
    # ─────────────────────────────────────────────

    @staticmethod
    def run_consistency(
        user_id: str,
        session_profiles: list[SessionProfile],
        l2_outputs: list[L2Output],
        all_l1_outputs: list[list[L1Output]],
    ):
        """Cross-session consistency audit → ConsistencyOutput."""
        return compute_consistency(
            user_id=user_id,
            session_profiles=session_profiles,
            l2_outputs=l2_outputs,
            all_l1_outputs=all_l1_outputs,
        )

    # ─────────────────────────────────────────────
    # Full pipeline (multi-session → user profile + compare)
    # ─────────────────────────────────────────────

    def run_full(
        self,
        sessions: list[ConversationSession],
        purpose_distributions: Optional[list[dict[str, float]]] = None,
    ) -> list[Profile | EngineError]:
        """Run single-session pipeline for each session in batch."""
        results: list[Profile | EngineError] = []
        for idx, session in enumerate(sessions):
            pd = (
                purpose_distributions[idx]
                if purpose_distributions and idx < len(purpose_distributions)
                else None
            )
            results.append(self.run_session(session, purpose_distribution=pd))
        return results
