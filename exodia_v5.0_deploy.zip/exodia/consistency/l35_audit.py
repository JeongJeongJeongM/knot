"""
EXODIA v3.0 — L3.5 Consistency Audit.
순수 Python. LLM 금지. 결정론적.
구현 기준: PART 8.
ddof=0, float64, epsilon=1e-12.
"""
from __future__ import annotations

import math
from datetime import datetime
from typing import Optional

from exodia.constants import (
    C1_INTENSITY_WEIGHT,
    C1_NORMALIZATION_CEILING,
    C1_STRUCTURAL_WEIGHT,
    C2_COMPARISON_PAIRS,
    C2_NORMALIZATION_CEILING,
    C3_MIN_VALUE_DECLARATIONS,
    C3_NORMALIZATION_CEILING,
    C4_CROSS_CEILING,
    C4_CROSS_WEIGHT,
    C4_WITHIN_CEILING,
    C4_WITHIN_WEIGHT,
    CONSISTENCY_RISK_LEVELS,
    CONSISTENCY_WEIGHTS,
    MIN_SESSIONS_FOR_HIGH,
    MIN_SESSIONS_FOR_L35,
    VALUE_TO_BEHAVIOR_MAP,
)
from exodia.models.outputs import (
    ConsistencyEvidence,
    ConsistencyOutput,
    L1Output,
    L2Output,
    SessionProfile,
)

_INTENSITY_KEYS = ["A1", "A2", "A3", "A4", "A5", "A6"]
_STRUCTURAL_KEYS = ["A7", "A8", "A9", "A10", "A11"]


def _std(values: list[float]) -> float:
    """Population std (ddof=0)."""
    n = len(values)
    if n < 1:
        return 0.0
    mean_v = sum(values) / n
    variance = sum((x - mean_v) ** 2 for x in values) / n
    return math.sqrt(variance)


def compute_consistency(
    user_id: str,
    session_profiles: list[SessionProfile],
    l2_outputs: list[L2Output],
    all_l1_outputs: list[list[L1Output]],
) -> ConsistencyOutput:
    """L3.5 교차 세션 일관성 감사.

    < 3 sessions → INSUFFICIENT, all C = None, risk_level = UNKNOWN.
    3~9 sessions → risk_level ceiling at MED (cannot be HIGH).
    ≥ 10 sessions → full precision.
    """
    session_count = len(session_profiles)

    if session_count < MIN_SESSIONS_FOR_L35:
        return ConsistencyOutput(
            user_id=user_id,
            session_count=session_count,
            status="INSUFFICIENT",
            risk_level="UNKNOWN",
        )

    # C1: PVI
    c1, per_axis_std, dominant_changes = _compute_c1_pvi(session_profiles)

    # C2: SOAI
    c2, soai_detail = _compute_c2_soai(l2_outputs)

    # C3: PAG (Fail-Closed: None if insufficient declarations)
    c3, pag_detail = _compute_c3_pag(all_l1_outputs)

    # C4: ET
    c4 = _compute_c4_et(l2_outputs, session_profiles)

    # Risk Score
    risk_score = _compute_risk_score(c1, c2, c3, c4)

    # Risk Level
    risk_level = _classify_risk(risk_score)

    # Session ceiling: 3~9 sessions → cannot be HIGH
    ceiling_applied = False
    if session_count < MIN_SESSIONS_FOR_HIGH and risk_level == "HIGH":
        risk_level = "MED"
        ceiling_applied = True

    return ConsistencyOutput(
        user_id=user_id,
        session_count=session_count,
        status="COMPUTED",
        c1_pvi=c1,
        c2_soai=c2,
        c3_pag=c3,
        c4_et=c4,
        risk_score=risk_score,
        risk_level=risk_level,
        evidence=ConsistencyEvidence(
            per_axis_std=per_axis_std,
            dominant_changes=dominant_changes,
            soai_detail=soai_detail,
            pag_detail=pag_detail,
            session_ceiling_applied=ceiling_applied,
        ),
    )


# ═══════════ C1: Pattern Variability Index (PVI) ═══════════


def _compute_c1_pvi(
    session_profiles: list[SessionProfile],
) -> tuple[float, Optional[dict[str, float]], Optional[dict[str, int]]]:
    """C1 PVI.

    Intensity: std of each axis score across sessions → mean / 0.35 normalization.
    Structural: dominant style change rate across sessions.
    C1 = 0.6 * min(1.0, intensity_pvi) + 0.4 * structural_vol.
    """
    # Intensity PVI
    axis_stds: dict[str, float] = {}
    for key in _INTENSITY_KEYS:
        values: list[float] = []
        for sp in session_profiles:
            axis = sp.l3.intensity_axes.get(key)
            if axis is not None:
                values.append(axis.score)
        if len(values) >= 2:
            axis_stds[key] = _std(values)

    if axis_stds:
        intensity_pvi = (
            sum(axis_stds.values()) / len(axis_stds) / C1_NORMALIZATION_CEILING
        )
    else:
        intensity_pvi = 0.0

    # Structural volatility: dominant style change rate
    dominant_changes: dict[str, int] = {}
    change_rates: list[float] = []

    for key in _STRUCTURAL_KEYS:
        dominants: list[str] = []
        for sp in session_profiles:
            axis = sp.l3.structural_axes.get(key)
            if axis is not None:
                dominants.append(axis.dominant)
        changes = sum(
            1 for i in range(len(dominants) - 1)
            if dominants[i] != dominants[i + 1]
        )
        dominant_changes[key] = changes
        if len(dominants) > 1:
            change_rates.append(changes / (len(dominants) - 1))

    structural_vol = (
        sum(change_rates) / len(change_rates) if change_rates else 0.0
    )

    c1 = (
        C1_INTENSITY_WEIGHT * min(1.0, intensity_pvi)
        + C1_STRUCTURAL_WEIGHT * structural_vol
    )
    c1 = min(1.0, max(0.0, c1))

    return (
        c1,
        axis_stds if axis_stds else None,
        dominant_changes if any(dominant_changes.values()) else None,
    )


# ═══════════ C2: Self-Other Asymmetry Index (SOAI) ═══════════


def _compute_c2_soai(
    l2_outputs: list[L2Output],
) -> tuple[float, Optional[dict[str, float]]]:
    """C2 SOAI.

    For each comparison pair:
      positive: max(0, self_rate - other_rate)
      negative: max(0, other_rate - self_rate)
    raw_soai = mean(asymmetries) → normalize by /0.3.
    """
    asymmetries: list[float] = []
    detail: dict[str, float] = {}

    for l2 in l2_outputs:
        dm = l2.direction_metrics
        self_rates = dm.rates_by_direction.get("self", {})
        other_rates = dm.rates_by_direction.get("other", {})

        for rate_name, direction in C2_COMPARISON_PAIRS:
            s = self_rates.get(rate_name, 0.0)
            o = other_rates.get(rate_name, 0.0)
            if direction == "positive":
                asym = max(0.0, s - o)
            else:
                asym = max(0.0, o - s)
            asymmetries.append(asym)
            detail[f"{l2.session_id}_{rate_name}"] = asym

    raw_soai = (sum(asymmetries) / len(asymmetries)) if asymmetries else 0.0
    c2 = min(1.0, raw_soai / C2_NORMALIZATION_CEILING)

    return c2, detail if detail else None


# ═══════════ C3: Principle-Action Gap (PAG) ═══════════


def _compute_c3_pag(
    all_l1_outputs: list[list[L1Output]],
) -> tuple[Optional[float], Optional[dict[str, float]]]:
    """C3 PAG.

    Need VALUE_DECLARATION >= 3, else return None (Fail-Closed).
    For each theme in VALUE_TO_BEHAVIOR_MAP:
      gap = max(0, declaration_intensity - behavior_rate).
    C3 = mean(gaps) / 0.25 normalization ceiling.
    """
    all_l1 = [l1 for session in all_l1_outputs for l1 in session]
    all_vd = [l1 for l1 in all_l1 if l1.mention_flags.VALUE_DECLARATION == 1]

    if len(all_vd) < C3_MIN_VALUE_DECLARATIONS:
        return None, None

    gaps: list[float] = []
    detail: dict[str, float] = {}

    for theme, mapping in sorted(VALUE_TO_BEHAVIOR_MAP.items()):
        decl_count = sum(
            1 for l1 in all_vd
            if l1.primary_id in mapping["declaration_labels"]
        )
        if decl_count == 0:
            continue

        behavior_count = sum(
            1 for l1 in all_l1
            if l1.primary_id in mapping["expected_behavior"]
        )
        behavior_rate = behavior_count / len(all_l1) if all_l1 else 0.0
        decl_intensity = decl_count / len(all_vd) if all_vd else 0.0
        gap = max(0.0, decl_intensity - behavior_rate)
        gaps.append(gap)
        detail[theme] = gap

    if not gaps:
        return None, None

    c3 = min(1.0, sum(gaps) / len(gaps) / C3_NORMALIZATION_CEILING)
    return c3, detail


# ═══════════ C4: Escalation Tendency (ET) ═══════════


def _compute_c4_et(
    l2_outputs: list[L2Output],
    session_profiles: list[SessionProfile],
) -> float:
    """C4 ET.

    Within-session: hostile rolling series late vs early.
    Cross-session: hostile_rate trend over sessions (sorted by time).
    C4 = 0.5 * within + 0.5 * cross.
    """
    # Within-session escalation
    within_ets: list[float] = []
    for l2 in l2_outputs:
        series = l2.timeseries.hostile_short_rolling
        if len(series) < 3:
            continue
        mid = len(series) // 2
        early_mean = sum(series[:mid]) / mid if mid > 0 else 0.0
        late_count = len(series) - mid
        late_mean = sum(series[mid:]) / late_count if late_count > 0 else 0.0
        within_ets.append(max(0.0, late_mean - early_mean))

    within_et = (
        (sum(within_ets) / len(within_ets) / C4_WITHIN_CEILING)
        if within_ets else 0.0
    )

    # Cross-session escalation
    sorted_sp = sorted(
        session_profiles,
        key=lambda sp: sp.computed_at or datetime.min,
    )
    hostile_rates = [
        sp.l2_direction.rates_by_direction.get("other", {}).get(
            "hostile_rate", 0.0
        )
        for sp in sorted_sp
    ]

    cross_et = 0.0
    if len(hostile_rates) >= 3:
        mid = len(hostile_rates) // 2
        early_mean = sum(hostile_rates[:mid]) / mid if mid > 0 else 0.0
        late_count = len(hostile_rates) - mid
        late_mean = (
            sum(hostile_rates[mid:]) / late_count if late_count > 0 else 0.0
        )
        cross_et = min(
            1.0, max(0.0, late_mean - early_mean) / C4_CROSS_CEILING
        )

    c4 = C4_WITHIN_WEIGHT * min(1.0, within_et) + C4_CROSS_WEIGHT * cross_et
    return min(1.0, max(0.0, c4))


# ═══════════ Risk Score / Level ═══════════


def _compute_risk_score(
    c1: float,
    c2: float,
    c3: Optional[float],
    c4: float,
) -> float:
    """Weighted sum of C1~C4. C3 None → redistribute weights proportionally."""
    scores: dict[str, float] = {"C1_pvi": c1, "C2_soai": c2, "C4_et": c4}
    weights = dict(CONSISTENCY_WEIGHTS)

    if c3 is not None:
        scores["C3_pag"] = c3
    else:
        removed_weight = weights.pop("C3_pag", 0.0)
        remaining_total = sum(weights.values())
        if remaining_total > 0:
            for k in weights:
                weights[k] = weights[k] / remaining_total

    risk_score = sum(
        scores.get(k, 0.0) * weights.get(k, 0.0) for k in weights
    )
    return min(1.0, max(0.0, risk_score))


def _classify_risk(risk_score: float) -> str:
    """LOW(0.00~0.30), MED(0.31~0.60), HIGH(0.61~1.00)."""
    for level, (low, _high) in sorted(
        CONSISTENCY_RISK_LEVELS.items(), key=lambda x: -x[1][0],
    ):
        if risk_score >= low:
            return level
    return "LOW"
