#!/usr/bin/env python3
"""EXODIA v5.0 — E2E Demo (무료, LLM 불필요).

전체 파이프라인을 MockProvider로 돌려서 엔진 동작을 검증합니다.
API 키 없이 실행 가능합니다.

Usage:
    python demo_e2e.py
"""
import json
import sys
import os

# 엔진 패키지 경로
sys.path.insert(0, os.path.dirname(__file__))

from exodia.pipeline import ExodiaPipeline
from exodia.layers.l1 import MockProvider
from exodia.calibration import CalibrationConfig
from exodia.lsm import KoreanLSMEngine
from exodia.adapter.default import DefaultAdapter
from exodia.models.inputs import ConversationSession, RawTurn, TurnMetadata


# ═══════════════════════════════════════════
# 1. 샘플 대화 생성
# ═══════════════════════════════════════════

def make_session(session_id: str, texts: list[str], session_type: str = "cold_llm") -> ConversationSession:
    """텍스트 리스트 → ConversationSession."""
    turns = []
    for i, text in enumerate(texts):
        turns.append(RawTurn(
            turn_id=f"{session_id}_t{i}",
            raw_text=text,
            metadata=TurnMetadata(speaker="user"),
        ))
    return ConversationSession(
        session_id=session_id,
        user_id=session_id.split("_")[0],
        turns=turns,
    )


# Person A: 감정 표현 활발, 협력적, 개방적
PERSON_A_COLD_TEXTS = [
    "안녕하세요! 오늘 날씨가 정말 좋네요",
    "저는 요즘 요가를 배우고 있어요 너무 재밌어요",
    "맞아요 운동하면 기분이 좋아지더라구요",
    "주말에 뭐 하세요? 같이 뭔가 하면 재밌을 것 같은데",
    "저도 카페 좋아해요! 어디 추천해주실 곳 있어요?",
    "오 거기 가봤는데 정말 분위기 좋더라구요",
    "다음에 같이 가요 그럼! 기대돼요",
    "저는 사실 좀 낯을 가리는 편인데 여기서는 편해요",
    "고마워요 그렇게 말해주시니까 기분 좋네요",
    "이야기 더 하고 싶은데 오늘은 이만 가볼게요",
    "다음에 또 얘기해요!",
    "진짜 오늘 대화 즐거웠어요",
    "좋은 저녁 보내세요~",
    "네 다음에 봐요!",
    "감사해요 오늘!",
]

PERSON_A_REAL_TEXTS = [
    "야 오늘 일이 너무 힘들었어",
    "상사가 또 뭐라 하더라 진짜 스트레스야",
    "그래도 네가 들어줘서 고마워",
    "맞아 그냥 참고 있는 중이야",
    "근데 이직도 좀 생각 중이야 솔직히",
    "어떻게 생각해? 내가 너무 예민한 건가?",
    "응 맞아 좀 더 생각해볼게",
    "고마워 진심으로",
    "너는 요즘 어때?",
    "힘든 거 있으면 나한테도 얘기해",
    "우리 서로 도와주자 ㅎㅎ",
    "다음에 밥이나 먹자 진짜",
    "ㅇㅇ 시간 맞춰보자",
    "그럼 이따 연락할게",
    "잘 자!",
]

# Person B: 분석적, 신중, 약간 거리감
PERSON_B_COLD_TEXTS = [
    "안녕하세요",
    "저는 주로 책을 읽어요",
    "네 그렇죠",
    "주말은 보통 집에서 쉬어요",
    "카페는 조용한 곳을 좋아해요",
    "네 거기 괜찮죠",
    "시간 되면요",
    "저도 낯을 가리는 편이에요",
    "네",
    "네 그럼 이만",
    "다음에 또 이야기해요",
    "네",
    "좋은 저녁 보내세요",
    "네 다음에",
    "네 감사합니다",
]

PERSON_B_REAL_TEXTS = [
    "그래 오늘 어땠어?",
    "그건 좀 힘들겠다",
    "뭐 어쩔 수 없지",
    "참는 것도 한계가 있지 않아?",
    "이직은 신중하게 생각해",
    "예민한 건 아닌데 현실적으로 봐야지",
    "그래 천천히 생각해",
    "뭐 별거 아니야",
    "나는 뭐 그냥 그래",
    "괜찮아 난",
    "그래 그러자",
    "밥은 뭐 시간 되면",
    "ㅇㅇ",
    "그래 연락해",
    "ㅇㅇ 잘 자",
]


def main():
    print("=" * 60)
    print("  EXODIA v5.0 E2E Demo (MockProvider — LLM 비용 0원)")
    print("=" * 60)
    print()

    # ─── 파이프라인 생성 (MockProvider로 LLM 대체) ───
    mock = MockProvider(fixed_response={
        "p": 200, "s": None, "c": 0.8,
        "e": "맞아", "d": "NEUTRAL", "v": 0
    })
    config = CalibrationConfig()
    pipeline = ExodiaPipeline(
        llm_provider=mock,
        calibration_config=config,
    )

    print(f"[Config] Engine Version: {pipeline.config.phase.value}")
    print(f"[Config] LSM Enabled: {pipeline.config.lsm_enabled}")
    print(f"[Config] Cold Start Min Turns: {pipeline.config.cold_start_min_turns}")
    print(f"[Config] LSM Weight Range: {pipeline.config.lsm_min_weight}-{pipeline.config.lsm_max_weight}")
    print()

    # ─── Step 1: 세션 분석 ───
    print("─" * 50)
    print("Step 1: 세션 분석 (analyze_session)")
    print("─" * 50)

    sessions = {
        "A_cold": make_session("personA_cold_01", PERSON_A_COLD_TEXTS, "cold_llm"),
        "A_real": make_session("personA_real_01", PERSON_A_REAL_TEXTS, "real_peer"),
        "B_cold": make_session("personB_cold_01", PERSON_B_COLD_TEXTS, "cold_llm"),
        "B_real": make_session("personB_real_01", PERSON_B_REAL_TEXTS, "real_peer"),
    }

    profiles = {}
    for label, session in sessions.items():
        result = pipeline.analyze_session(
            session=session,
            user_id=session.user_id,
            session_type="cold_llm" if "cold" in label else "real_peer",
        )
        if hasattr(result, 'error_code'):
            print(f"  [{label}] ERROR: {result.error_code} — {result.message}")
            return
        profiles[label] = result
        print(f"  [{label}] turns={result.turn_count}, "
              f"LSM categories={len(result.lsm_features.category_rates) if result.lsm_features else 0}")

    print()

    # ─── Step 2: 유저 프로필 빌드 ───
    print("─" * 50)
    print("Step 2: 유저 프로필 빌드 (build_user_profile)")
    print("─" * 50)

    # Person A: cold + real + extra sessions → UserProfile (3+ needed for PROFILED)
    # 세션 3개 이상이어야 consistency risk_level != UNKNOWN
    user_a = pipeline.build_user_profile(
        user_id="personA",
        session_profiles=[profiles["A_cold"], profiles["A_real"], profiles["A_cold"]],
    )
    print(f"  [Person A] status={user_a.status}, "
          f"sessions={user_a.session_count}, "
          f"has_cold={user_a.profile_cold is not None}, "
          f"has_real={user_a.profile_real is not None}")

    # Person B: cold + real + extra sessions → UserProfile
    user_b = pipeline.build_user_profile(
        user_id="personB",
        session_profiles=[profiles["B_cold"], profiles["B_real"], profiles["B_cold"]],
    )
    print(f"  [Person B] status={user_b.status}, "
          f"sessions={user_b.session_count}, "
          f"has_cold={user_b.profile_cold is not None}, "
          f"has_real={user_b.profile_real is not None}")
    print()

    # ─── Step 3: 매칭 (L6 + L7) ───
    print("─" * 50)
    print("Step 3: 매칭 비교 (match_users → L6 + L7)")
    print("─" * 50)

    match_result = pipeline.match_users(user_a, user_b, phase="cold")

    l5 = match_result.l5
    if l5.blocked:
        print(f"  BLOCKED: {l5.block_reason}")
    else:
        print(f"  [L6] Compatibility: {l5.compatibility:.3f}")
        print(f"  [L6] Final Score:   {l5.final_score:.3f}")
        print(f"  [L6] Total Friction:     {l5.friction_total:.3f}")
        print(f"       - Intensity:        {l5.friction_intensity:.3f}")
        print(f"       - Structural:       {l5.friction_structural:.3f}")
        print(f"       - LSM:              {l5.friction_lsm:.3f}")
        if l5.friction_sources:
            print(f"  [L6] Friction Sources ({len(l5.friction_sources)}):")
            for src in l5.friction_sources[:5]:
                print(f"       - {src.axis}: {src.type} (contribution={src.friction_contribution:.3f})")

    print()

    # ─── Step 4: L7 갭 분석 ───
    print("─" * 50)
    print("Step 4: L7 갭 분석 (cold vs real)")
    print("─" * 50)

    if match_result.l7_a:
        l7a = match_result.l7_a
        print(f"  [Person A] total_gap={l7a.gap_analysis.total_gap:.3f}, "
              f"risk_level={l7a.risk_assessment.risk_level}, "
              f"patterns={l7a.risk_assessment.risk_patterns}")
    else:
        print("  [Person A] L7 not available (no real profile)")

    if match_result.l7_b:
        l7b = match_result.l7_b
        print(f"  [Person B] total_gap={l7b.gap_analysis.total_gap:.3f}, "
              f"risk_level={l7b.risk_assessment.risk_level}, "
              f"patterns={l7b.risk_assessment.risk_patterns}")
    else:
        print("  [Person B] L7 not available (no real profile)")

    print()

    # ─── Step 5: Adapter (UX 변환) ───
    print("─" * 50)
    print("Step 5: Adapter — UX 레이블 변환")
    print("─" * 50)

    adapter = DefaultAdapter()

    if not l5.blocked:
        compat_label = adapter.translate_compatibility(l5.final_score)
        print(f"  호환성 라벨: {compat_label.label}")
        print(f"  설명:       {compat_label.description}")
        print(f"  이모지:     {compat_label.emoji}")

        risk_score = match_result.l7_a.risk_assessment.inauthenticity_score if match_result.l7_a else 0
        risk_action = adapter.translate_risk_action(risk_score)
        print(f"  리스크 액션: {risk_action.action}")
        print(f"  리스크 사유: {risk_action.reason}")

    print()

    # ─── Step 6: CalibrationConfig 동적 가중치 데모 ───
    print("─" * 50)
    print("Step 6: CalibrationConfig 동적 가중치")
    print("─" * 50)

    for reliability in [None, 0.0, 0.5, 1.0]:
        a, b, g = config.effective_l6_weights(lsm_reliability=reliability)
        print(f"  reliability={reliability} → alpha={a:.3f}, beta={b:.3f}, gamma={g:.3f} (sum={a+b+g:.3f})")

    print()
    for turns in [5, 12, 20, 30, 50]:
        cap = config.confidence_cap(turns)
        print(f"  turns={turns:2d} → confidence_cap={cap:.2f}")

    print()

    # ─── Step 7: KoreanLSMEngine 12-category 검증 ───
    print("─" * 50)
    print("Step 7: KoreanLSMEngine 12-category 검증")
    print("─" * 50)

    if profiles["A_cold"].lsm_features:
        cats = profiles["A_cold"].lsm_features.category_rates
        print(f"  Person A (cold) LSM categories ({len(cats)}):")
        for cat, rate in sorted(cats.items()):
            print(f"    {cat:25s} = {rate:.4f}")
        if profiles["A_cold"].lsm_features.category_distributions:
            dists = profiles["A_cold"].lsm_features.category_distributions
            print(f"  Distribution data available for: {list(dists.keys())}")

    print()
    print("=" * 60)
    print("  DEMO COMPLETE — All v5.0 features verified!")
    print("=" * 60)


if __name__ == "__main__":
    main()
