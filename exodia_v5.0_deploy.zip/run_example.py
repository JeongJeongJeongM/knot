#!/usr/bin/env python3
"""EXODIA pipeline example run."""
import sys
sys.path.insert(0, "src")

from exodia.pipeline import run

# Example: Normal case (P.T6 emotion/relationship)
turns = [
    {"turn_id": 0, "speaker": "SELF", "text_raw": "오늘까지 해야 하는데 진짜 짜증나 어떡해?"},
    {"turn_id": 1, "speaker": "OTHER", "text_raw": "힘들겠다 ㅠㅠ"},
    {"turn_id": 2, "speaker": "SELF", "text_raw": "응 진짜 스트레스야"},
    {"turn_id": 3, "speaker": "OTHER", "text_raw": "그래서 어떻게 할 거야?"},
    {"turn_id": 4, "speaker": "SELF", "text_raw": "일단 해볼게"},
    {"turn_id": 5, "speaker": "OTHER", "text_raw": "맞아 그렇게 해봐"},
    {"turn_id": 6, "speaker": "SELF", "text_raw": "고마워"},
    {"turn_id": 7, "speaker": "OTHER", "text_raw": "뭘"},
    {"turn_id": 8, "speaker": "SELF", "text_raw": "진짜 도움이 됐어"},
    {"turn_id": 9, "speaker": "OTHER", "text_raw": "다행이네"},
    {"turn_id": 10, "speaker": "SELF", "text_raw": "응"},
    {"turn_id": 11, "speaker": "OTHER", "text_raw": "그럼 이렇게 하자"},
]

result = run(turns, session_id="example", purpose_id="P.T6", n_min=10)
print("=== EXODIA Result ===")
print("State:", result["state"])
print("Axes:", result["axes"])
print("ADP:", result["comparison"]["adp"])
print("Stability:", result["stability"])
print("Triggered:", result.get("triggered_hypotheses", []))
