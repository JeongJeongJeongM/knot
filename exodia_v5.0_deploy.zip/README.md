# EXODIA Engine v1.0.0

**Spec Version: 2.0.4 (LOCKED)**

AI 대화 로그에서 행동 패턴을 결정론적으로 분석하여 호환성 매칭을 수행하는 엔진.

## 아키텍처

```
ConversationSession
       │
       ▼
  ┌─── L0 ───┐   정규화, 표면 피처, 스팬 힌트 (Pure Python + Regex)
  │           │
  └─── L1 ───┘   LLM 기반 86개 라벨 분류 (유일한 LLM 호출 레이어)
       │
       ▼
  ┌─── L2 ───┐   세션 통계 집계, 전이 행렬, 시계열
  │           │
  ├ Integrity ┤   데이터 신뢰도 게이트 (Stage 1: 입력 지문, Stage 2: 대화 호혜성)
  │           │
  └─── L3 ───┘   11개 행동 축 합성 (6 Intensity + 5 Structural)
       │
       ▼
  ┌─ L3.5 ──┐    크로스 세션 일관성 감사 (PVI, SOAI, PAG, ET)
  │          │
  └─── L4 ──┘    PCR 기대치 대비 투영 (Delta, Bias, ADP)
       │
       ▼
      L5         두 UserProfile 비교 → Friction, Compatibility, Stability Bonus
```

## 핵심 원칙

- **결정론적**: 동일 입력 → 동일 출력 (float64, epsilon=1e-12, sorted dict, temperature=0)
- **LLM 최소화**: L1에서만 LLM 호출, 나머지 전부 순수 함수
- **Fail-safe**: 데이터 부족 시 UNKNOWN/기본값 반환, 예외 전파 없음
- **O(N*K + K^2)**: N=턴 수, K=라벨 수, 최대 1000턴 제한

## 설치

```bash
cd exodia
pip install -r requirements.txt
```

## 의존성

- `pydantic>=2.6.0` — 스키마 검증
- `anthropic>=0.39.0` — L1 LLM 호출 (Claude Sonnet)
- `pytest>=8.0.0` — 테스트

## 사용법

### 세션 분석

```python
from exodia.pipeline import analyze_session
from exodia.schemas import ConversationTurn, ConversationSession
from exodia.layers.l1 import MockProvider

# 대화 턴 구성
turns = [
    ConversationTurn(turn_id="t0", speaker="A", raw_text="오늘까지 해야 하는데 진짜 짜증나"),
    ConversationTurn(turn_id="t1", speaker="B", raw_text="힘들겠다 ㅠㅠ 괜찮아?"),
    ConversationTurn(turn_id="t2", speaker="A", raw_text="응 고마워 그래도 해볼게"),
    # ... 최소 10턴 권장
]

session = ConversationSession(
    session_id="sess_001",
    turns=turns,
    target_speaker="A"
)

# MockProvider로 테스트 (실제 환경에서는 AnthropicProvider 사용)
provider = MockProvider()
result = analyze_session(session, llm_provider=provider)
# result: SessionProfile (L2 + Integrity + L3 결과 포함)
```

### 유저 프로필 빌드

```python
from exodia.pipeline import build_user_profile

# 여러 세션을 분석한 결과들
session_profiles = [result1, result2, result3]
user_profile = build_user_profile(
    user_id="user_001",
    session_profiles=session_profiles
)
# user_profile: UserProfile (L3.5 일관성 감사 + L4 투영 포함)
```

### 두 유저 매칭

```python
from exodia.pipeline import match_users

match_result = match_users(user_profile_a, user_profile_b)
# match_result: MatchResult (Friction, Compatibility, Gate 결과)
print(f"호환성: {match_result.compatibility:.2f}")
print(f"마찰: {match_result.total_friction:.2f}")
print(f"게이트 통과: {match_result.gate_passed}")
```

## 프로젝트 구조

```
exodia/
├── __init__.py          # 패키지 초기화, 버전 정보
├── config.py            # 모든 상수/가중치/임계값 (런타임 불변)
├── schemas.py           # Pydantic v2 데이터 스키마
├── pipeline.py          # 파이프라인 오케스트레이터
├── requirements.txt     # Python 의존성
├── layers/
│   ├── __init__.py
│   ├── l0.py            # 정규화, 표면 피처, 스팬 힌트
│   ├── l1.py            # LLM 라벨링 (86개 라벨, 캐시, 재시도)
│   ├── l2.py            # 세션 통계 집계, 전이 행렬
│   ├── integrity.py     # 데이터 신뢰도 게이트
│   ├── l3.py            # 11개 행동 축 합성
│   ├── l3_5.py          # 크로스 세션 일관성 감사
│   ├── l4.py            # PCR 기대치 대비 투영
│   └── l5.py            # 유저 비교, 마찰/호환성 계산
└── tests/
    ├── __init__.py
    ├── conftest.py      # 공통 pytest fixtures
    ├── test_l0.py       # L0 테스트 (30개)
    ├── test_l1.py       # L1 테스트 (19개)
    ├── test_l2.py       # L2 테스트 (7개)
    ├── test_integrity.py # Integrity 테스트 (3개)
    ├── test_l3.py       # L3 테스트 (3개)
    ├── test_l3_5.py     # L3.5 테스트 (3개)
    ├── test_l4.py       # L4 테스트 (2개)
    ├── test_l5.py       # L5 테스트 (5개)
    └── test_pipeline.py # 파이프라인 통합 테스트 (5개)
```

## 테스트

```bash
python -m pytest exodia/tests/ -v
```

## 스펙 참조

`EXODIA_v2_0_4_UNIFIED_SPEC_LOCKED.MD` 기준 구현.
모든 상수는 `config.py`에서 스펙 섹션 번호와 함께 주석 처리됨.
